var rf=Object.defineProperty;var of=(i,t,e)=>t in i?rf(i,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):i[t]=e;var q=(i,t,e)=>of(i,typeof t!="symbol"?t+"":t,e);(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))n(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&n(o)}).observe(document,{childList:!0,subtree:!0});function e(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function n(s){if(s.ep)return;s.ep=!0;const r=e(s);fetch(s.href,r)}})();const af="modulepreload",cf=function(i,t){return new URL(i,t).href},Gc={},er=function(t,e,n){let s=Promise.resolve();if(e&&e.length>0){let o=function(h){return Promise.all(h.map(u=>Promise.resolve(u).then(f=>({status:"fulfilled",value:f}),f=>({status:"rejected",reason:f}))))};const a=document.getElementsByTagName("link"),c=document.querySelector("meta[property=csp-nonce]"),l=(c==null?void 0:c.nonce)||(c==null?void 0:c.getAttribute("nonce"));s=o(e.map(h=>{if(h=cf(h,n),h in Gc)return;Gc[h]=!0;const u=h.endsWith(".css"),f=u?'[rel="stylesheet"]':"";if(!!n)for(let _=a.length-1;_>=0;_--){const p=a[_];if(p.href===h&&(!u||p.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${h}"]${f}`))return;const g=document.createElement("link");if(g.rel=u?"stylesheet":af,u||(g.as="script"),g.crossOrigin="",g.href=h,l&&g.setAttribute("nonce",l),document.head.appendChild(g),u)return new Promise((_,p)=>{g.addEventListener("load",_),g.addEventListener("error",()=>p(new Error(`Unable to preload CSS for ${h}`)))})}))}function r(o){const a=new Event("vite:preloadError",{cancelable:!0});if(a.payload=o,window.dispatchEvent(a),!a.defaultPrevented)throw o}return s.then(o=>{for(const a of o||[])a.status==="rejected"&&r(a.reason);return t().catch(r)})};/*! Capacitor: https://capacitorjs.com/ - MIT License */var hs;(function(i){i.Unimplemented="UNIMPLEMENTED",i.Unavailable="UNAVAILABLE"})(hs||(hs={}));class go extends Error{constructor(t,e,n){super(t),this.message=t,this.code=e,this.data=n}}const lf=i=>{var t,e;return i!=null&&i.androidBridge?"android":!((e=(t=i==null?void 0:i.webkit)===null||t===void 0?void 0:t.messageHandlers)===null||e===void 0)&&e.bridge?"ios":"web"},hf=i=>{const t=i.CapacitorCustomPlatform||null,e=i.Capacitor||{},n=e.Plugins=e.Plugins||{},s=()=>t!==null?t.name:lf(i),r=()=>s()!=="web",o=u=>{const f=l.get(u);return!!(f!=null&&f.platforms.has(s())||a(u))},a=u=>{var f;return(f=e.PluginHeaders)===null||f===void 0?void 0:f.find(m=>m.name===u)},c=u=>i.console.error(u),l=new Map,h=(u,f={})=>{const m=l.get(u);if(m)return console.warn(`Capacitor plugin "${u}" already registered. Cannot register plugins twice.`),m.proxy;const g=s(),_=a(u);let p;const d=async()=>(!p&&g in f?p=typeof f[g]=="function"?p=await f[g]():p=f[g]:t!==null&&!p&&"web"in f&&(p=typeof f.web=="function"?p=await f.web():p=f.web),p),y=(M,x)=>{var v,E;if(_){const P=_==null?void 0:_.methods.find(L=>x===L.name);if(P)return P.rtype==="promise"?L=>e.nativePromise(u,x.toString(),L):(L,N)=>e.nativeCallback(u,x.toString(),L,N);if(M)return(v=M[x])===null||v===void 0?void 0:v.bind(M)}else{if(M)return(E=M[x])===null||E===void 0?void 0:E.bind(M);throw new go(`"${u}" plugin is not implemented on ${g}`,hs.Unimplemented)}},b=M=>{let x;const v=(...E)=>{const P=d().then(L=>{const N=y(L,M);if(N){const F=N(...E);return x=F==null?void 0:F.remove,F}else throw new go(`"${u}.${M}()" is not implemented on ${g}`,hs.Unimplemented)});return M==="addListener"&&(P.remove=async()=>x()),P};return v.toString=()=>`${M.toString()}() { [capacitor code] }`,Object.defineProperty(v,"name",{value:M,writable:!1,configurable:!1}),v},w=b("addListener"),C=b("removeListener"),A=(M,x)=>{const v=w({eventName:M},x),E=async()=>{const L=await v;C({eventName:M,callbackId:L},x)},P=new Promise(L=>v.then(()=>L({remove:E})));return P.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await E()},P},S=new Proxy({},{get(M,x){switch(x){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return _?A:w;case"removeListener":return C;default:return b(x)}}});return n[u]=S,l.set(u,{name:u,proxy:S,platforms:new Set([...Object.keys(f),..._?[g]:[]])}),S};return e.convertFileSrc||(e.convertFileSrc=u=>u),e.getPlatform=s,e.handleError=c,e.isNativePlatform=r,e.isPluginAvailable=o,e.registerPlugin=h,e.Exception=go,e.DEBUG=!!e.DEBUG,e.isLoggingEnabled=!!e.isLoggingEnabled,e},uf=i=>i.Capacitor=hf(i),Ci=uf(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),Di=Ci.registerPlugin;class Dh{constructor(){this.listeners={},this.retainedEventArguments={},this.windowListeners={}}addListener(t,e){let n=!1;this.listeners[t]||(this.listeners[t]=[],n=!0),this.listeners[t].push(e);const r=this.windowListeners[t];r&&!r.registered&&this.addWindowListener(r),n&&this.sendRetainedArgumentsForEvent(t);const o=async()=>this.removeListener(t,e);return Promise.resolve({remove:o})}async removeAllListeners(){this.listeners={};for(const t in this.windowListeners)this.removeWindowListener(this.windowListeners[t]);this.windowListeners={}}notifyListeners(t,e,n){const s=this.listeners[t];if(!s){if(n){let r=this.retainedEventArguments[t];r||(r=[]),r.push(e),this.retainedEventArguments[t]=r}return}s.forEach(r=>r(e))}hasListeners(t){var e;return!!(!((e=this.listeners[t])===null||e===void 0)&&e.length)}registerWindowListener(t,e){this.windowListeners[e]={registered:!1,windowEventName:t,pluginEventName:e,handler:n=>{this.notifyListeners(e,n)}}}unimplemented(t="not implemented"){return new Ci.Exception(t,hs.Unimplemented)}unavailable(t="not available"){return new Ci.Exception(t,hs.Unavailable)}async removeListener(t,e){const n=this.listeners[t];if(!n)return;const s=n.indexOf(e);this.listeners[t].splice(s,1),this.listeners[t].length||this.removeWindowListener(this.windowListeners[t])}addWindowListener(t){window.addEventListener(t.windowEventName,t.handler),t.registered=!0}removeWindowListener(t){t&&(window.removeEventListener(t.windowEventName,t.handler),t.registered=!1)}sendRetainedArgumentsForEvent(t){const e=this.retainedEventArguments[t];e&&(delete this.retainedEventArguments[t],e.forEach(n=>{this.notifyListeners(t,n)}))}}const Hc=i=>encodeURIComponent(i).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),Vc=i=>i.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class ff extends Dh{async getCookies(){const t=document.cookie,e={};return t.split(";").forEach(n=>{if(n.length<=0)return;let[s,r]=n.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");s=Vc(s).trim(),r=Vc(r).trim(),e[s]=r}),e}async setCookie(t){try{const e=Hc(t.key),n=Hc(t.value),s=t.expires?`; expires=${t.expires.replace("expires=","")}`:"",r=(t.path||"/").replace("path=",""),o=t.url!=null&&t.url.length>0?`domain=${t.url}`:"";document.cookie=`${e}=${n||""}${s}; path=${r}; ${o};`}catch(e){return Promise.reject(e)}}async deleteCookie(t){try{document.cookie=`${t.key}=; Max-Age=0`}catch(e){return Promise.reject(e)}}async clearCookies(){try{const t=document.cookie.split(";")||[];for(const e of t)document.cookie=e.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(t){return Promise.reject(t)}}async clearAllCookies(){try{await this.clearCookies()}catch(t){return Promise.reject(t)}}}Di("CapacitorCookies",{web:()=>new ff});const df=async i=>new Promise((t,e)=>{const n=new FileReader;n.onload=()=>{const s=n.result;t(s.indexOf(",")>=0?s.split(",")[1]:s)},n.onerror=s=>e(s),n.readAsDataURL(i)}),pf=(i={})=>{const t=Object.keys(i);return Object.keys(i).map(s=>s.toLocaleLowerCase()).reduce((s,r,o)=>(s[r]=i[t[o]],s),{})},mf=(i,t=!0)=>i?Object.entries(i).reduce((n,s)=>{const[r,o]=s;let a,c;return Array.isArray(o)?(c="",o.forEach(l=>{a=t?encodeURIComponent(l):l,c+=`${r}=${a}&`}),c.slice(0,-1)):(a=t?encodeURIComponent(o):o,c=`${r}=${a}`),`${n}&${c}`},"").substr(1):null,gf=(i,t={})=>{const e=Object.assign({method:i.method||"GET",headers:i.headers},t),s=pf(i.headers)["content-type"]||"";if(typeof i.data=="string")e.body=i.data;else if(s.includes("application/x-www-form-urlencoded")){const r=new URLSearchParams;for(const[o,a]of Object.entries(i.data||{}))r.set(o,a);e.body=r.toString()}else if(s.includes("multipart/form-data")||i.data instanceof FormData){const r=new FormData;if(i.data instanceof FormData)i.data.forEach((a,c)=>{r.append(c,a)});else for(const a of Object.keys(i.data))r.append(a,i.data[a]);e.body=r;const o=new Headers(e.headers);o.delete("content-type"),e.headers=o}else(s.includes("application/json")||typeof i.data=="object")&&(e.body=JSON.stringify(i.data));return e};class _f extends Dh{async request(t){const e=gf(t,t.webFetchExtra),n=mf(t.params,t.shouldEncodeUrlParams),s=n?`${t.url}?${n}`:t.url,r=await fetch(s,e),o=r.headers.get("content-type")||"";let{responseType:a="text"}=r.ok?t:{};o.includes("application/json")&&(a="json");let c,l;switch(a){case"arraybuffer":case"blob":l=await r.blob(),c=await df(l);break;case"json":c=await r.json();break;case"document":case"text":default:c=await r.text()}const h={};return r.headers.forEach((u,f)=>{h[f]=u}),{data:c,headers:h,status:r.status,url:r.url}}async get(t){return this.request(Object.assign(Object.assign({},t),{method:"GET"}))}async post(t){return this.request(Object.assign(Object.assign({},t),{method:"POST"}))}async put(t){return this.request(Object.assign(Object.assign({},t),{method:"PUT"}))}async patch(t){return this.request(Object.assign(Object.assign({},t),{method:"PATCH"}))}async delete(t){return this.request(Object.assign(Object.assign({},t),{method:"DELETE"}))}}Di("CapacitorHttp",{web:()=>new _f});const ra=Di("App",{web:()=>er(()=>import("./web-3sp75PJm.js"),[],import.meta.url).then(i=>new i.AppWeb)});let ke=null,Ih=!1;function Uh(i){Ih=i}function Nh(){if(!ke)try{ke=new AudioContext}catch{return}ke.state==="suspended"&&ke.resume()}function Ne(i,t,e,n="sine",s=.2,r){if(!ke)return;const o=ke.currentTime+t,a=ke.createOscillator(),c=ke.createGain();a.type=n,a.frequency.setValueAtTime(i,o),r&&a.frequency.exponentialRampToValueAtTime(r,o+e),c.gain.setValueAtTime(1e-4,o),c.gain.exponentialRampToValueAtTime(s,o+.01),c.gain.exponentialRampToValueAtTime(1e-4,o+e),a.connect(c).connect(ke.destination),a.start(o),a.stop(o+e+.05)}function Wc(i,t=.25){if(!ke)return;const e=Math.floor(ke.sampleRate*i),n=ke.createBuffer(1,e,ke.sampleRate),s=n.getChannelData(0);for(let a=0;a<e;a++)s[a]=(Math.random()*2-1)*(1-a/e);const r=ke.createBufferSource(),o=ke.createGain();o.gain.value=t,r.buffer=n,r.connect(o).connect(ke.destination),r.start()}function Fh(i){if(!(Ih||!ke))switch(i){case"coin":Ne(988,0,.08,"square",.08),Ne(1319,.07,.15,"square",.08);break;case"bell":Ne(2093,0,.35,"sine",.18),Ne(2093,.18,.5,"sine",.18);break;case"crash":Wc(.3,.3),Ne(160,0,.3,"sawtooth",.12,60);break;case"trick":Ne(500,0,.18,"triangle",.12,1e3);break;case"land":Ne(220,0,.1,"triangle",.1);break;case"good":[523,659,784].forEach((t,e)=>Ne(t,e*.07,.15,"triangle",.14));break;case"violation":Ne(180,0,.25,"square",.1),Ne(140,.22,.3,"square",.1);break;case"checkpoint":case"lap":Ne(660,0,.1,"triangle",.14),Ne(880,.1,.18,"triangle",.14);break;case"bump":Ne(120,0,.12,"sine",.25,70);break;case"horn":Ne(415,0,.35,"square",.07),Ne(523,0,.35,"square",.05);break;case"splash":Wc(.35,.35),Ne(300,0,.25,"sine",.1,90);break;case"finish":[523,659,784,1047].forEach((t,e)=>Ne(t,e*.12,.3,"triangle",.16));break}}const xf=[{id:"allround",name:"All-round",emoji:"🛞",stars:0,good:"A bit of everything"},{id:"knobby",name:"Knobby",emoji:"🪨",stars:3,good:"Grips in mud, slower on roads"},{id:"slick",name:"Slick",emoji:"💨",stars:5,good:"Fast on roads and ramps, slides in mud"}],vf=[{id:"standard",name:"Standard",emoji:"🚲",stars:0,good:"Easy to ride"},{id:"mountain",name:"Mountain",emoji:"⛰️",stars:4,good:"Soft landings, bumps rocks"},{id:"bmx",name:"BMX",emoji:"🌀",stars:8,good:"Faster flips and tricks"}],Oh=[{id:"none",name:"No pet",emoji:"🚫",stars:0,good:"Ride solo"},{id:"dog",name:"Sheru the dog",emoji:"🐶",stars:0,good:"Runs beside you, grabs nearby coins"},{id:"parrot",name:"Mithu the parrot",emoji:"🦜",stars:6,good:"Rides on your handlebar, grabs coins"},{id:"bunny",name:"Coco the bunny",emoji:"🐰",stars:12,good:"Hops along, grabs coins from further away"}],ic={speed:1,dirtSpeed:1,mud:1,spin:1,trickTime:1,landing:0,rocks:0,magnet:0,petName:""};function Mf(i,t,e){const n={...ic};return i==="knobby"&&Object.assign(n,{speed:.94,dirtSpeed:1,mud:.4}),i==="slick"&&Object.assign(n,{speed:1.1,dirtSpeed:.97,mud:1.6}),t==="bmx"&&Object.assign(n,{spin:1.3,trickTime:.8}),t==="mountain"&&Object.assign(n,{landing:.25,rocks:2}),e!=="none"&&(n.magnet=e==="bunny"?1.6:1.35,n.petName=Oh.find(s=>s.id===e).name.split(" ")[0]),n}const ie=3.5,zr=1.75,_o=3,Xc=8,Rn=1e3,Be=4;function yf(i){return()=>{i=i+1831565813|0;let t=Math.imul(i^i>>>15,1|i);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}const cr=["#f4a261","#e9c46a","#e5e5e5","#a8dadc","#f6bd60","#cdb4db","#ffafcc","#bde0fe","#d4a373","#b7e4c7","#f28482"],ss=["#e63946","#457b9d","#2a9d8f","#f1faee","#ffb703","#6d6875","#264653"],Gr=2.2,oa=.9;function Sf(i){const t=i==="right"?1:-1,e=yf(7),n=[160,370,580,800].map(g=>({s:g,zebraS:g-Be-2.5,stopS:g-Be-5})),s=[265,690].map(g=>({s:g})),r=[95,470,885],o=(g,_)=>n.some(p=>g>p.stopS-_&&g<p.s+Be+_)||s.some(p=>Math.abs(g-p.s)<_+2),a=[215,330,430,640,735,855].map((g,_)=>({s:g,x:t*(ie-1.1),hs:Gr,hx:oa,color:ss[_%ss.length]})),c=[];for(const g of[40,115,230,300,410,500,620,720,840,905])for(let _=0;_<5;_++){const p=g+_*5;if(o(p,3))continue;const d=a.some(y=>p>y.s-y.hs-8&&p<y.s+y.hs+2);c.push({s:p,x:t*(d?.75:zr)})}const l=[],h=[];let u=-40;for(const g of n)h.push([u,g.s-Be-9]),u=g.s+Be+3;h.push([u,Rn+60]);for(const g of[-1,1])for(const[_,p]of h){let d=_;for(;d<p-6;){const y=Math.min(p-d,9+e()*10),b=10+e()*8,w=Math.max(0,1-Math.abs(d-500)/500);l.push({s:d+y/2,x:g*(Xc+b/2),len:y-.6,depth:b,height:7+e()*12+w*e()*28,color:cr[Math.floor(e()*cr.length)],cross:!1}),d+=y}}for(const g of n)for(const _ of[-1,1])for(const p of[-1,1]){let d=Xc+20;for(;d<90;){const y=10+e()*10,b=10+e()*4;l.push({s:g.s+p*(Be+3+b/2),x:_*(d+y/2),len:y-.6,depth:b,height:8+e()*18,color:cr[Math.floor(e()*cr.length)],cross:!0}),d+=y}}const f=[],m=[];for(let g=8;g<Rn+40;g+=14)o(g,4)||f.push({s:g,x:-5.8},{s:g+7,x:5.8});for(let g=20;g<Rn+40;g+=32)o(g,3)||m.push({s:g,x:-4},{s:g,x:4});return{side:i,sign:t,intersections:n,zebras:s,bumps:r,parked:a,coins:c,buildings:l,trees:f,lamps:m,checkpoints:[6,...n.map(g=>g.s+Be+8)],finishS:Rn-40,stickers:[{id:"auto",s:185,d:t*.4,lift:.9},{id:"cab",s:525,d:t*3,lift:.9},{id:"signal",s:905,d:t*.3,lift:.9}]}}const wf=3,bf=8.5,Ef=7,Tf=.01,Af=.45,Rf=2.2,$c=ie-.4,qc=.85,Cf=.35,xo=9,Pf=10,Lf=2,Df=7,If=45,Uf=1.7,Yc=6,Nf=42,Ff=1.6;class Of{constructor(t,e=ic,n=[]){q(this,"layout");q(this,"sign");q(this,"player");q(this,"time",0);q(this,"score",0);q(this,"crashes",0);q(this,"violations",0);q(this,"checkpoint");q(this,"coins");q(this,"lights");q(this,"peds");q(this,"cars",[]);q(this,"finished",!1);q(this,"finishedFor",0);q(this,"result",null);q(this,"sounds",[]);q(this,"message",null);q(this,"messageColor","#fff");q(this,"messageT",0);q(this,"hint",null);q(this,"hintT",0);q(this,"wrongSideT",0);q(this,"rightSideT",0);q(this,"wrongFlagged",!1);q(this,"nextCarS",120);q(this,"gear");q(this,"mistakes",{redLight:0,zebra:0,wrongSide:0});q(this,"stickerGot");q(this,"stickerFinds",[]);q(this,"voice",[]);q(this,"petSaidAt",-10);q(this,"petGrabAt",-10);this.gear=e,this.layout=Sf(t),this.stickerGot=this.layout.stickers.map(s=>n.includes(s.id)),this.sign=this.layout.sign,this.checkpoint=this.layout.checkpoints[0],this.player=this.spawn(this.checkpoint),this.coins=this.layout.coins.map(()=>!1),this.lights=this.layout.intersections.map(()=>({phase:"green",t:0,triggered:!1,waited:!1,crossSpawned:0})),this.peds=this.layout.zebras.map((s,r)=>({t:-1,x:0,from:r%2?1:-1,done:!1,waited:!1}))}get coinCount(){return this.coins.filter(Boolean).length}get totalCoins(){return this.layout.coins.length}get laneX(){return this.sign*zr}spawn(t){return{s:t,x:this.sign*zr,heading:0,speed:0,crank:0,crashed:!1,crashT:0,bumpT:0}}say(t,e="#ffffff",n=2){this.message=t,this.messageColor=e,this.messageT=n}ringBell(){this.sounds.push("bell")}update(t,e){this.messageT>0&&(this.messageT-=t)<=0&&(this.message=null),this.hintT>0&&(this.hintT-=t)<=0&&(this.hint=null),this.finished?(this.finishedFor+=t,e={up:!1,down:!0,left:!1,right:!1}):this.time+=t;const n=this.player;if(n.crashed){n.crashT+=t,n.crashT>Ff&&(this.player=this.spawn(this.checkpoint),this.cars=this.cars.filter(r=>Math.abs(r.s-this.checkpoint)>40)),this.updateTraffic(t);return}const s=n.s;this.move(t,e),this.updateLights(t,s),this.updatePedestrians(t,s),this.updateTraffic(t),this.checkCollisions(e),this.checkWrongSide(t),this.collectCoins();for(const r of this.layout.bumps)s<r&&n.s>=r&&(n.bumpT=.35,this.sounds.push("bump"),n.speed>6&&this.say("Slow down at speed breakers!","#fde68a"));for(const r of this.layout.checkpoints)r>this.checkpoint&&n.s>=r&&(this.checkpoint=r);!this.finished&&n.s>=this.layout.finishS&&this.finish()}move(t,e){const n=this.player;let s=-.15*Math.sign(n.speed)-Tf*n.speed*n.speed;e.up&&n.speed<bf*this.gear.speed&&(s+=wf),n.speed+=s*t,e.down&&(n.speed-=Ef*t),n.speed<.05&&!e.up&&(n.speed=Math.max(0,n.speed)),n.speed=Math.max(0,n.speed);const o=((e.right?1:0)-(e.left?1:0))*Af-n.heading;n.heading+=Math.sign(o)*Math.min(Math.abs(o),Rf*t),n.s+=n.speed*Math.cos(n.heading)*t,n.x+=n.speed*Math.sin(n.heading)*t,Math.abs(n.x)>$c&&(n.x=Math.sign(n.x)*$c,n.heading*=.5,n.speed>2&&(n.speed*=.6,this.sounds.push("bump"),this.say("Careful, that's the kerb!","#fde68a",1.2))),n.crank+=n.speed*t/.33,n.bumpT>0&&(n.bumpT-=t)}updateLights(t,e){const n=this.player;this.layout.intersections.forEach((s,r)=>{const o=this.lights[r];if(!o.triggered&&n.s>s.stopS-If&&n.s<s.stopS&&(o.triggered=!0,o.phase="yellow",this.voice.push("lightAhead"),o.t=0),o.phase!=="green"){if(o.t+=t,o.phase==="yellow"&&o.t>=Lf)o.phase="red",o.t=0,o.crossSpawned=0;else if(o.phase==="red"){if(o.crossSpawned<2&&o.t>.2+o.crossSpawned*1.4){const a=o.crossSpawned%2?-1:1,c=-a*this.sign*2;this.cars.push({s:s.s+c,x:-a*35,axis:"cross",dir:a,speed:Pf,color:ss[(r+o.crossSpawned)%ss.length],honked:!1}),o.crossSpawned++}o.t>=Df&&(o.phase="green",o.waited&&(this.score+=100,this.say("Great stop! 👍","#bbf7d0"),this.sounds.push("good"),this.voice.push("greatStop")))}}o.phase==="red"&&n.s<s.stopS&&s.stopS-n.s<12&&n.speed<.3&&(o.waited=!0),e<s.stopS&&n.s>=s.stopS&&o.phase==="red"&&!this.finished&&(this.violations++,o.waited=!1,this.say("Red light! Always stop at the line.","#fecaca",2.5),this.sounds.push("violation"),this.voice.push("redLight"),this.mistakes.redLight++)})}updatePedestrians(t,e){const n=this.player;this.layout.zebras.forEach((s,r)=>{const o=this.peds[r];o.t<0&&n.s>s.s-Nf&&n.s<s.s&&(o.t=0,o.x=o.from*Yc),o.t>=0&&!o.done&&(o.t+=t,o.x-=o.from*Uf*t,Math.abs(o.x)<ie+.3&&n.s<s.s&&s.s-n.s<12&&n.speed<.3&&(o.waited=!0),Math.abs(o.x)>Yc&&(o.done=!0,o.waited&&(this.score+=100,this.say("Thanks for waiting! 😊","#bbf7d0"),this.sounds.push("good"))));const a=o.t>=0&&!o.done&&Math.abs(o.x)<ie+.3;e<s.s-1.5&&n.s>=s.s-1.5&&a&&!this.finished&&(this.violations++,o.waited=!1,this.say("Stop for people on the zebra crossing!","#fecaca",2.5),this.sounds.push("violation"),this.voice.push("zebra"),this.mistakes.zebra++)})}oncomingStop(t){let e=null;return this.layout.intersections.forEach((n,s)=>{const r=n.s+Be+5;this.lights[s].phase!=="green"&&t.s>r&&t.s-r<40&&(e=Math.max(e??-1/0,r))}),this.layout.zebras.forEach((n,s)=>{const r=this.peds[s],o=n.s+3;r.t>=0&&!r.done&&t.s>o&&t.s-o<30&&(e=Math.max(e??-1/0,o))}),e}updateTraffic(t){const e=this.player;this.nextCarS<e.s+90&&(this.nextCarS=e.s+150),e.s+150>=this.nextCarS&&this.nextCarS<this.layout.finishS+60&&(this.layout.intersections.every(s=>Math.abs(s.s-this.nextCarS)>12)&&this.cars.push({s:this.nextCarS,x:-this.sign*zr,axis:"main",dir:-1,speed:xo,color:ss[Math.floor(this.nextCarS)%ss.length],honked:!1}),this.nextCarS+=55+this.nextCarS*7%40);for(const n of this.cars)if(n.axis==="main"){const s=this.oncomingStop(n);let r=xo;s!==null&&(r=Math.max(0,Math.min(xo,(n.s-s-Gr)*1.2)));for(const o of this.cars)o!==n&&o.axis==="main"&&o.s<n.s&&n.s-o.s<12&&(r=Math.min(r,Math.max(0,(n.s-o.s-6)*1.5)));n.speed+=Math.max(-8*t,Math.min(3*t,r-n.speed)),n.s+=n.dir*n.speed*t}else n.x+=n.dir*n.speed*t;this.cars=this.cars.filter(n=>n.axis==="main"?n.s>e.s-30:Math.abs(n.x)<75)}overlaps(t,e,n,s){const r=this.player;return Math.abs(r.s-t)<n+qc&&Math.abs(r.x-e)<s+Cf}checkCollisions(t){const e=this.player;for(const n of this.layout.parked)this.overlaps(n.s,n.x,n.hs,n.hx)&&(e.s=Math.min(e.s,n.s-n.hs-qc-.05),e.speed>1.5&&(this.sounds.push("bump"),this.say("Steer around parked cars!","#fde68a")),e.speed=0,t.up&&!t.left&&!t.right&&(e.x-=Math.sign(e.x)*1.2*(1/60)),this.hintT<=0&&(this.hint=this.sign<0?"Press ▶ to steer around the parked car":"Press ◀ to steer around the parked car",this.hintT=2.5));for(const n of this.cars){const[s,r]=n.axis==="main"?[Gr,oa]:[oa,Gr];if(this.overlaps(n.s,n.x,s,r)){e.crashed=!0,e.crashT=0,this.crashes++,this.sounds.push("horn","crash"),this.voice.push("crash"),this.say(n.axis==="main"?"Oops! Stay in your own lane.":"Oops! Wait for the green light.","#fecaca",2.2);return}n.axis==="main"&&!n.honked&&n.s>e.s&&n.s-e.s<25&&Math.abs(n.x-e.x)<1.6&&(n.honked=!0,this.sounds.push("horn"))}}checkWrongSide(t){const e=this.player;e.x*this.sign<-.4&&e.speed>1?(this.wrongSideT+=t,this.rightSideT=0,this.wrongSideT>1.2&&!this.wrongFlagged&&(this.wrongFlagged=!0,this.violations++,this.sounds.push("violation"),this.say(this.sign<0?"Keep left! In India we ride on the left.":"Keep right! In the US we ride on the right.","#fecaca",2.8),this.voice.push(this.sign<0?"keepLeft":"keepRight"),this.mistakes.wrongSide++)):(this.wrongSideT=0,this.rightSideT+=t,this.rightSideT>.8&&(this.wrongFlagged=!1))}collectCoins(){const t=this.player,e=Math.max(1,this.gear.magnet),n=Math.max(.9,this.gear.magnet);this.layout.coins.forEach((s,r)=>{if(this.coins[r])return;const o=Math.abs(s.s-t.s),a=Math.abs(s.x-t.x);if(o<e&&a<n){const c=o>=1||a>=.9;if(c&&this.time-this.petGrabAt<3)return;this.coins[r]=!0,this.score+=50,this.sounds.push("coin"),c&&(this.petGrabAt=this.time,this.time-this.petSaidAt>8&&(this.petSaidAt=this.time,this.say(`${this.gear.petName} grabbed a coin! 🐾`,"#fef3c7",1.2)))}}),this.layout.stickers.forEach((s,r)=>{!this.stickerGot[r]&&Math.abs(s.s-t.s)<1&&Math.abs(s.d-t.x)<.9&&(this.stickerGot[r]=!0,this.stickerFinds.push(s.id),this.sounds.push("good"),this.voice.push("sticker"))})}finish(){this.finished=!0,this.sounds.push("finish"),this.voice.push("finish");const t=this.coinCount===this.layout.coins.length,e=this.violations===0&&this.crashes===0;this.result={stars:1+(t?1:0)+(e?1:0),time:this.time,coins:this.coinCount,totalCoins:this.layout.coins.length,score:this.score,crashes:this.crashes,violations:this.violations}}}/**
 * @license
 * Copyright 2010-2024 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const sc="170",kf=0,jc=1,Bf=2,kh=1,Bh=2,Hn=3,li=0,Qe=1,ze=2,ai=0,as=1,aa=2,Kc=3,Zc=4,zf=5,wi=100,Gf=101,Hf=102,Vf=103,Wf=104,Xf=200,$f=201,qf=202,Yf=203,ca=204,la=205,jf=206,Kf=207,Zf=208,Jf=209,Qf=210,td=211,ed=212,nd=213,id=214,ha=0,ua=1,fa=2,us=3,da=4,pa=5,ma=6,ga=7,rc=0,sd=1,rd=2,ci=0,od=1,ad=2,cd=3,ld=4,hd=5,ud=6,fd=7,zh=300,fs=301,ds=302,_a=303,xa=304,ro=306,ps=1e3,Ti=1001,va=1002,tn=1003,dd=1004,lr=1005,Sn=1006,vo=1007,Ai=1008,$n=1009,Gh=1010,Hh=1011,Ks=1012,oc=1013,Pi=1014,Cn=1015,nr=1016,ac=1017,cc=1018,ms=1020,Vh=35902,Wh=1021,Xh=1022,wn=1023,$h=1024,qh=1025,cs=1026,gs=1027,lc=1028,hc=1029,Yh=1030,uc=1031,fc=1033,Hr=33776,Vr=33777,Wr=33778,Xr=33779,Ma=35840,ya=35841,Sa=35842,wa=35843,ba=36196,Ea=37492,Ta=37496,Aa=37808,Ra=37809,Ca=37810,Pa=37811,La=37812,Da=37813,Ia=37814,Ua=37815,Na=37816,Fa=37817,Oa=37818,ka=37819,Ba=37820,za=37821,$r=36492,Ga=36494,Ha=36495,jh=36283,Va=36284,Wa=36285,Xa=36286,pd=3200,md=3201,Kh=0,gd=1,oi="",Te="srgb",Ss="srgb-linear",oo="linear",ae="srgb",Oi=7680,Jc=519,_d=512,xd=513,vd=514,Zh=515,Md=516,yd=517,Sd=518,wd=519,$a=35044,Qc="300 es",Vn=2e3,Kr=2001;class ws{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;const n=this._listeners;return n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;const s=this._listeners[t];if(s!==void 0){const r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;const n=this._listeners[t.type];if(n!==void 0){t.target=this;const s=n.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,t);t.target=null}}}const He=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let tl=1234567;const $s=Math.PI/180,_s=180/Math.PI;function Wn(){const i=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(He[i&255]+He[i>>8&255]+He[i>>16&255]+He[i>>24&255]+"-"+He[t&255]+He[t>>8&255]+"-"+He[t>>16&15|64]+He[t>>24&255]+"-"+He[e&63|128]+He[e>>8&255]+"-"+He[e>>16&255]+He[e>>24&255]+He[n&255]+He[n>>8&255]+He[n>>16&255]+He[n>>24&255]).toLowerCase()}function Ye(i,t,e){return Math.max(t,Math.min(e,i))}function dc(i,t){return(i%t+t)%t}function bd(i,t,e,n,s){return n+(i-t)*(s-n)/(e-t)}function Ed(i,t,e){return i!==t?(e-i)/(t-i):0}function qs(i,t,e){return(1-e)*i+e*t}function Td(i,t,e,n){return qs(i,t,1-Math.exp(-e*n))}function Ad(i,t=1){return t-Math.abs(dc(i,t*2)-t)}function Rd(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*(3-2*i))}function Cd(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*i*(i*(i*6-15)+10))}function Pd(i,t){return i+Math.floor(Math.random()*(t-i+1))}function Ld(i,t){return i+Math.random()*(t-i)}function Dd(i){return i*(.5-Math.random())}function Id(i){i!==void 0&&(tl=i);let t=tl+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function Ud(i){return i*$s}function Nd(i){return i*_s}function Fd(i){return(i&i-1)===0&&i!==0}function Od(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function kd(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function Bd(i,t,e,n,s){const r=Math.cos,o=Math.sin,a=r(e/2),c=o(e/2),l=r((t+n)/2),h=o((t+n)/2),u=r((t-n)/2),f=o((t-n)/2),m=r((n-t)/2),g=o((n-t)/2);switch(s){case"XYX":i.set(a*h,c*u,c*f,a*l);break;case"YZY":i.set(c*f,a*h,c*u,a*l);break;case"ZXZ":i.set(c*u,c*f,a*h,a*l);break;case"XZX":i.set(a*h,c*g,c*m,a*l);break;case"YXY":i.set(c*m,a*h,c*g,a*l);break;case"ZYZ":i.set(c*g,c*m,a*h,a*l);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function yn(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function se(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}const Jh={DEG2RAD:$s,RAD2DEG:_s,generateUUID:Wn,clamp:Ye,euclideanModulo:dc,mapLinear:bd,inverseLerp:Ed,lerp:qs,damp:Td,pingpong:Ad,smoothstep:Rd,smootherstep:Cd,randInt:Pd,randFloat:Ld,randFloatSpread:Dd,seededRandom:Id,degToRad:Ud,radToDeg:Nd,isPowerOfTwo:Fd,ceilPowerOfTwo:Od,floorPowerOfTwo:kd,setQuaternionFromProperEuler:Bd,normalize:se,denormalize:yn};class Ft{constructor(t=0,e=0){Ft.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const e=this.x,n=this.y,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6],this.y=s[1]*e+s[4]*n+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Ye(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){const n=Math.cos(e),s=Math.sin(e),r=this.x-t.x,o=this.y-t.y;return this.x=r*n-o*s+t.x,this.y=r*s+o*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class zt{constructor(t,e,n,s,r,o,a,c,l){zt.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,o,a,c,l)}set(t,e,n,s,r,o,a,c,l){const h=this.elements;return h[0]=t,h[1]=s,h[2]=a,h[3]=e,h[4]=r,h[5]=c,h[6]=n,h[7]=o,h[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,s=e.elements,r=this.elements,o=n[0],a=n[3],c=n[6],l=n[1],h=n[4],u=n[7],f=n[2],m=n[5],g=n[8],_=s[0],p=s[3],d=s[6],y=s[1],b=s[4],w=s[7],C=s[2],A=s[5],S=s[8];return r[0]=o*_+a*y+c*C,r[3]=o*p+a*b+c*A,r[6]=o*d+a*w+c*S,r[1]=l*_+h*y+u*C,r[4]=l*p+h*b+u*A,r[7]=l*d+h*w+u*S,r[2]=f*_+m*y+g*C,r[5]=f*p+m*b+g*A,r[8]=f*d+m*w+g*S,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],c=t[6],l=t[7],h=t[8];return e*o*h-e*a*l-n*r*h+n*a*c+s*r*l-s*o*c}invert(){const t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],c=t[6],l=t[7],h=t[8],u=h*o-a*l,f=a*c-h*r,m=l*r-o*c,g=e*u+n*f+s*m;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const _=1/g;return t[0]=u*_,t[1]=(s*l-h*n)*_,t[2]=(a*n-s*o)*_,t[3]=f*_,t[4]=(h*e-s*c)*_,t[5]=(s*r-a*e)*_,t[6]=m*_,t[7]=(n*c-l*e)*_,t[8]=(o*e-n*r)*_,this}transpose(){let t;const e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,s,r,o,a){const c=Math.cos(r),l=Math.sin(r);return this.set(n*c,n*l,-n*(c*o+l*a)+o+t,-s*l,s*c,-s*(-l*o+c*a)+a+e,0,0,1),this}scale(t,e){return this.premultiply(Mo.makeScale(t,e)),this}rotate(t){return this.premultiply(Mo.makeRotation(-t)),this}translate(t,e){return this.premultiply(Mo.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){const e=this.elements,n=t.elements;for(let s=0;s<9;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}}const Mo=new zt;function Qh(i){for(let t=i.length-1;t>=0;--t)if(i[t]>=65535)return!0;return!1}function Zr(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function zd(){const i=Zr("canvas");return i.style.display="block",i}const el={};function Gs(i){i in el||(el[i]=!0,console.warn(i))}function Gd(i,t,e){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(t,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:n()}}setTimeout(r,e)})}function Hd(i){const t=i.elements;t[2]=.5*t[2]+.5*t[3],t[6]=.5*t[6]+.5*t[7],t[10]=.5*t[10]+.5*t[11],t[14]=.5*t[14]+.5*t[15]}function Vd(i){const t=i.elements;t[11]===-1?(t[10]=-t[10]-1,t[14]=-t[14]):(t[10]=-t[10],t[14]=-t[14]+1)}const Kt={enabled:!0,workingColorSpace:Ss,spaces:{},convert:function(i,t,e){return this.enabled===!1||t===e||!t||!e||(this.spaces[t].transfer===ae&&(i.r=Xn(i.r),i.g=Xn(i.g),i.b=Xn(i.b)),this.spaces[t].primaries!==this.spaces[e].primaries&&(i.applyMatrix3(this.spaces[t].toXYZ),i.applyMatrix3(this.spaces[e].fromXYZ)),this.spaces[e].transfer===ae&&(i.r=ls(i.r),i.g=ls(i.g),i.b=ls(i.b))),i},fromWorkingColorSpace:function(i,t){return this.convert(i,this.workingColorSpace,t)},toWorkingColorSpace:function(i,t){return this.convert(i,t,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===oi?oo:this.spaces[i].transfer},getLuminanceCoefficients:function(i,t=this.workingColorSpace){return i.fromArray(this.spaces[t].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,t,e){return i.copy(this.spaces[t].toXYZ).multiply(this.spaces[e].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace}};function Xn(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function ls(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}const nl=[.64,.33,.3,.6,.15,.06],il=[.2126,.7152,.0722],sl=[.3127,.329],rl=new zt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),ol=new zt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);Kt.define({[Ss]:{primaries:nl,whitePoint:sl,transfer:oo,toXYZ:rl,fromXYZ:ol,luminanceCoefficients:il,workingColorSpaceConfig:{unpackColorSpace:Te},outputColorSpaceConfig:{drawingBufferColorSpace:Te}},[Te]:{primaries:nl,whitePoint:sl,transfer:ae,toXYZ:rl,fromXYZ:ol,luminanceCoefficients:il,outputColorSpaceConfig:{drawingBufferColorSpace:Te}}});let ki;class Wd{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{ki===void 0&&(ki=Zr("canvas")),ki.width=t.width,ki.height=t.height;const n=ki.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),e=ki}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const e=Zr("canvas");e.width=t.width,e.height=t.height;const n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);const s=n.getImageData(0,0,t.width,t.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=Xn(r[o]/255)*255;return n.putImageData(s,0,0),e}else if(t.data){const e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(Xn(e[n]/255)*255):e[n]=Xn(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let Xd=0;class tu{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Xd++}),this.uuid=Wn(),this.data=t,this.dataReady=!0,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,a=s.length;o<a;o++)s[o].isDataTexture?r.push(yo(s[o].image)):r.push(yo(s[o]))}else r=yo(s);n.url=r}return e||(t.images[this.uuid]=n),n}}function yo(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?Wd.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let $d=0;class Xe extends ws{constructor(t=Xe.DEFAULT_IMAGE,e=Xe.DEFAULT_MAPPING,n=Ti,s=Ti,r=Sn,o=Ai,a=wn,c=$n,l=Xe.DEFAULT_ANISOTROPY,h=oi){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:$d++}),this.uuid=Wn(),this.name="",this.source=new tu(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=l,this.format=a,this.internalFormat=null,this.type=c,this.offset=new Ft(0,0),this.repeat=new Ft(1,1),this.center=new Ft(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new zt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==zh)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case ps:t.x=t.x-Math.floor(t.x);break;case Ti:t.x=t.x<0?0:1;break;case va:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case ps:t.y=t.y-Math.floor(t.y);break;case Ti:t.y=t.y<0?0:1;break;case va:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}Xe.DEFAULT_IMAGE=null;Xe.DEFAULT_MAPPING=zh;Xe.DEFAULT_ANISOTROPY=1;class Se{constructor(t=0,e=0,n=0,s=1){Se.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,s){return this.x=t,this.y=e,this.z=n,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const e=this.x,n=this.y,s=this.z,r=this.w,o=t.elements;return this.x=o[0]*e+o[4]*n+o[8]*s+o[12]*r,this.y=o[1]*e+o[5]*n+o[9]*s+o[13]*r,this.z=o[2]*e+o[6]*n+o[10]*s+o[14]*r,this.w=o[3]*e+o[7]*n+o[11]*s+o[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,s,r;const c=t.elements,l=c[0],h=c[4],u=c[8],f=c[1],m=c[5],g=c[9],_=c[2],p=c[6],d=c[10];if(Math.abs(h-f)<.01&&Math.abs(u-_)<.01&&Math.abs(g-p)<.01){if(Math.abs(h+f)<.1&&Math.abs(u+_)<.1&&Math.abs(g+p)<.1&&Math.abs(l+m+d-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;const b=(l+1)/2,w=(m+1)/2,C=(d+1)/2,A=(h+f)/4,S=(u+_)/4,M=(g+p)/4;return b>w&&b>C?b<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(b),s=A/n,r=S/n):w>C?w<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(w),n=A/s,r=M/s):C<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(C),n=S/r,s=M/r),this.set(n,s,r,e),this}let y=Math.sqrt((p-g)*(p-g)+(u-_)*(u-_)+(f-h)*(f-h));return Math.abs(y)<.001&&(y=1),this.x=(p-g)/y,this.y=(u-_)/y,this.z=(f-h)/y,this.w=Math.acos((l+m+d-1)/2),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class qd extends ws{constructor(t=1,e=1,n={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new Se(0,0,t,e),this.scissorTest=!1,this.viewport=new Se(0,0,t,e);const s={width:t,height:e,depth:1};n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Sn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},n);const r=new Xe(s,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace);r.flipY=!1,r.generateMipmaps=n.generateMipmaps,r.internalFormat=n.internalFormat,this.textures=[];const o=n.count;for(let a=0;a<o;a++)this.textures[a]=r.clone(),this.textures[a].isRenderTargetTexture=!0;this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=t,this.textures[s].image.height=e,this.textures[s].image.depth=n;this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let n=0,s=t.textures.length;n<s;n++)this.textures[n]=t.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0;const e=Object.assign({},t.texture.image);return this.texture.source=new tu(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Li extends qd{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}}class eu extends Xe{constructor(t=null,e=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=tn,this.minFilter=tn,this.wrapR=Ti,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class Yd extends Xe{constructor(t=null,e=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=tn,this.minFilter=tn,this.wrapR=Ti,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Un{constructor(t=0,e=0,n=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=s}static slerpFlat(t,e,n,s,r,o,a){let c=n[s+0],l=n[s+1],h=n[s+2],u=n[s+3];const f=r[o+0],m=r[o+1],g=r[o+2],_=r[o+3];if(a===0){t[e+0]=c,t[e+1]=l,t[e+2]=h,t[e+3]=u;return}if(a===1){t[e+0]=f,t[e+1]=m,t[e+2]=g,t[e+3]=_;return}if(u!==_||c!==f||l!==m||h!==g){let p=1-a;const d=c*f+l*m+h*g+u*_,y=d>=0?1:-1,b=1-d*d;if(b>Number.EPSILON){const C=Math.sqrt(b),A=Math.atan2(C,d*y);p=Math.sin(p*A)/C,a=Math.sin(a*A)/C}const w=a*y;if(c=c*p+f*w,l=l*p+m*w,h=h*p+g*w,u=u*p+_*w,p===1-a){const C=1/Math.sqrt(c*c+l*l+h*h+u*u);c*=C,l*=C,h*=C,u*=C}}t[e]=c,t[e+1]=l,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,n,s,r,o){const a=n[s],c=n[s+1],l=n[s+2],h=n[s+3],u=r[o],f=r[o+1],m=r[o+2],g=r[o+3];return t[e]=a*g+h*u+c*m-l*f,t[e+1]=c*g+h*f+l*u-a*m,t[e+2]=l*g+h*m+a*f-c*u,t[e+3]=h*g-a*u-c*f-l*m,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,s){return this._x=t,this._y=e,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){const n=t._x,s=t._y,r=t._z,o=t._order,a=Math.cos,c=Math.sin,l=a(n/2),h=a(s/2),u=a(r/2),f=c(n/2),m=c(s/2),g=c(r/2);switch(o){case"XYZ":this._x=f*h*u+l*m*g,this._y=l*m*u-f*h*g,this._z=l*h*g+f*m*u,this._w=l*h*u-f*m*g;break;case"YXZ":this._x=f*h*u+l*m*g,this._y=l*m*u-f*h*g,this._z=l*h*g-f*m*u,this._w=l*h*u+f*m*g;break;case"ZXY":this._x=f*h*u-l*m*g,this._y=l*m*u+f*h*g,this._z=l*h*g+f*m*u,this._w=l*h*u-f*m*g;break;case"ZYX":this._x=f*h*u-l*m*g,this._y=l*m*u+f*h*g,this._z=l*h*g-f*m*u,this._w=l*h*u+f*m*g;break;case"YZX":this._x=f*h*u+l*m*g,this._y=l*m*u+f*h*g,this._z=l*h*g-f*m*u,this._w=l*h*u-f*m*g;break;case"XZY":this._x=f*h*u-l*m*g,this._y=l*m*u-f*h*g,this._z=l*h*g+f*m*u,this._w=l*h*u+f*m*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){const n=e/2,s=Math.sin(n);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){const e=t.elements,n=e[0],s=e[4],r=e[8],o=e[1],a=e[5],c=e[9],l=e[2],h=e[6],u=e[10],f=n+a+u;if(f>0){const m=.5/Math.sqrt(f+1);this._w=.25/m,this._x=(h-c)*m,this._y=(r-l)*m,this._z=(o-s)*m}else if(n>a&&n>u){const m=2*Math.sqrt(1+n-a-u);this._w=(h-c)/m,this._x=.25*m,this._y=(s+o)/m,this._z=(r+l)/m}else if(a>u){const m=2*Math.sqrt(1+a-n-u);this._w=(r-l)/m,this._x=(s+o)/m,this._y=.25*m,this._z=(c+h)/m}else{const m=2*Math.sqrt(1+u-n-a);this._w=(o-s)/m,this._x=(r+l)/m,this._y=(c+h)/m,this._z=.25*m}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<Number.EPSILON?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Ye(this.dot(t),-1,1)))}rotateTowards(t,e){const n=this.angleTo(t);if(n===0)return this;const s=Math.min(1,e/n);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){const n=t._x,s=t._y,r=t._z,o=t._w,a=e._x,c=e._y,l=e._z,h=e._w;return this._x=n*h+o*a+s*l-r*c,this._y=s*h+o*c+r*a-n*l,this._z=r*h+o*l+n*c-s*a,this._w=o*h-n*a-s*c-r*l,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);const n=this._x,s=this._y,r=this._z,o=this._w;let a=o*t._w+n*t._x+s*t._y+r*t._z;if(a<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,a=-a):this.copy(t),a>=1)return this._w=o,this._x=n,this._y=s,this._z=r,this;const c=1-a*a;if(c<=Number.EPSILON){const m=1-e;return this._w=m*o+e*this._w,this._x=m*n+e*this._x,this._y=m*s+e*this._y,this._z=m*r+e*this._z,this.normalize(),this}const l=Math.sqrt(c),h=Math.atan2(l,a),u=Math.sin((1-e)*h)/l,f=Math.sin(e*h)/l;return this._w=o*u+this._w*f,this._x=n*u+this._x*f,this._y=s*u+this._y*f,this._z=r*u+this._z*f,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){const t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(t),s*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class I{constructor(t=0,e=0,n=0){I.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(al.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(al.setFromAxisAngle(t,e))}applyMatrix3(t){const e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*s,this.y=r[1]*e+r[4]*n+r[7]*s,this.z=r[2]*e+r[5]*n+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const e=this.x,n=this.y,s=this.z,r=t.elements,o=1/(r[3]*e+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*s+r[12])*o,this.y=(r[1]*e+r[5]*n+r[9]*s+r[13])*o,this.z=(r[2]*e+r[6]*n+r[10]*s+r[14])*o,this}applyQuaternion(t){const e=this.x,n=this.y,s=this.z,r=t.x,o=t.y,a=t.z,c=t.w,l=2*(o*s-a*n),h=2*(a*e-r*s),u=2*(r*n-o*e);return this.x=e+c*l+o*u-a*h,this.y=n+c*h+a*l-r*u,this.z=s+c*u+r*h-o*l,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*s,this.y=r[1]*e+r[5]*n+r[9]*s,this.z=r[2]*e+r[6]*n+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){const n=t.x,s=t.y,r=t.z,o=e.x,a=e.y,c=e.z;return this.x=s*c-r*a,this.y=r*o-n*c,this.z=n*a-s*o,this}projectOnVector(t){const e=t.lengthSq();if(e===0)return this.set(0,0,0);const n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return So.copy(this).projectOnVector(t),this.sub(So)}reflect(t){return this.sub(So.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Ye(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y,s=this.z-t.z;return e*e+n*n+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){const s=Math.sin(e)*t;return this.x=s*Math.sin(n),this.y=Math.cos(e)*t,this.z=s*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){const e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const So=new I,al=new Un;class Ii{constructor(t=new I(1/0,1/0,1/0),e=new I(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(gn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(gn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){const n=gn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);const n=t.geometry;if(n!==void 0){const r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)t.isMesh===!0?t.getVertexPosition(o,gn):gn.fromBufferAttribute(r,o),gn.applyMatrix4(t.matrixWorld),this.expandByPoint(gn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),hr.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),hr.copy(n.boundingBox)),hr.applyMatrix4(t.matrixWorld),this.union(hr)}const s=t.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,gn),gn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Cs),ur.subVectors(this.max,Cs),Bi.subVectors(t.a,Cs),zi.subVectors(t.b,Cs),Gi.subVectors(t.c,Cs),Kn.subVectors(zi,Bi),Zn.subVectors(Gi,zi),pi.subVectors(Bi,Gi);let e=[0,-Kn.z,Kn.y,0,-Zn.z,Zn.y,0,-pi.z,pi.y,Kn.z,0,-Kn.x,Zn.z,0,-Zn.x,pi.z,0,-pi.x,-Kn.y,Kn.x,0,-Zn.y,Zn.x,0,-pi.y,pi.x,0];return!wo(e,Bi,zi,Gi,ur)||(e=[1,0,0,0,1,0,0,0,1],!wo(e,Bi,zi,Gi,ur))?!1:(fr.crossVectors(Kn,Zn),e=[fr.x,fr.y,fr.z],wo(e,Bi,zi,Gi,ur))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,gn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(gn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(On[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),On[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),On[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),On[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),On[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),On[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),On[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),On[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(On),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}}const On=[new I,new I,new I,new I,new I,new I,new I,new I],gn=new I,hr=new Ii,Bi=new I,zi=new I,Gi=new I,Kn=new I,Zn=new I,pi=new I,Cs=new I,ur=new I,fr=new I,mi=new I;function wo(i,t,e,n,s){for(let r=0,o=i.length-3;r<=o;r+=3){mi.fromArray(i,r);const a=s.x*Math.abs(mi.x)+s.y*Math.abs(mi.y)+s.z*Math.abs(mi.z),c=t.dot(mi),l=e.dot(mi),h=n.dot(mi);if(Math.max(-Math.max(c,l,h),Math.min(c,l,h))>a)return!1}return!0}const jd=new Ii,Ps=new I,bo=new I;class Ui{constructor(t=new I,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){const n=this.center;e!==void 0?n.copy(e):jd.setFromPoints(t).getCenter(n);let s=0;for(let r=0,o=t.length;r<o;r++)s=Math.max(s,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){const n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Ps.subVectors(t,this.center);const e=Ps.lengthSq();if(e>this.radius*this.radius){const n=Math.sqrt(e),s=(n-this.radius)*.5;this.center.addScaledVector(Ps,s/n),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(bo.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Ps.copy(t.center).add(bo)),this.expandByPoint(Ps.copy(t.center).sub(bo))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}}const kn=new I,Eo=new I,dr=new I,Jn=new I,To=new I,pr=new I,Ao=new I;class pc{constructor(t=new I,e=new I(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,kn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);const n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const e=kn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(kn.copy(this.origin).addScaledVector(this.direction,e),kn.distanceToSquared(t))}distanceSqToSegment(t,e,n,s){Eo.copy(t).add(e).multiplyScalar(.5),dr.copy(e).sub(t).normalize(),Jn.copy(this.origin).sub(Eo);const r=t.distanceTo(e)*.5,o=-this.direction.dot(dr),a=Jn.dot(this.direction),c=-Jn.dot(dr),l=Jn.lengthSq(),h=Math.abs(1-o*o);let u,f,m,g;if(h>0)if(u=o*c-a,f=o*a-c,g=r*h,u>=0)if(f>=-g)if(f<=g){const _=1/h;u*=_,f*=_,m=u*(u+o*f+2*a)+f*(o*u+f+2*c)+l}else f=r,u=Math.max(0,-(o*f+a)),m=-u*u+f*(f+2*c)+l;else f=-r,u=Math.max(0,-(o*f+a)),m=-u*u+f*(f+2*c)+l;else f<=-g?(u=Math.max(0,-(-o*r+a)),f=u>0?-r:Math.min(Math.max(-r,-c),r),m=-u*u+f*(f+2*c)+l):f<=g?(u=0,f=Math.min(Math.max(-r,-c),r),m=f*(f+2*c)+l):(u=Math.max(0,-(o*r+a)),f=u>0?r:Math.min(Math.max(-r,-c),r),m=-u*u+f*(f+2*c)+l);else f=o>0?-r:r,u=Math.max(0,-(o*f+a)),m=-u*u+f*(f+2*c)+l;return n&&n.copy(this.origin).addScaledVector(this.direction,u),s&&s.copy(Eo).addScaledVector(dr,f),m}intersectSphere(t,e){kn.subVectors(t.center,this.origin);const n=kn.dot(this.direction),s=kn.dot(kn)-n*n,r=t.radius*t.radius;if(s>r)return null;const o=Math.sqrt(r-s),a=n-o,c=n+o;return c<0?null:a<0?this.at(c,e):this.at(a,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){const n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){const e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,s,r,o,a,c;const l=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,f=this.origin;return l>=0?(n=(t.min.x-f.x)*l,s=(t.max.x-f.x)*l):(n=(t.max.x-f.x)*l,s=(t.min.x-f.x)*l),h>=0?(r=(t.min.y-f.y)*h,o=(t.max.y-f.y)*h):(r=(t.max.y-f.y)*h,o=(t.min.y-f.y)*h),n>o||r>s||((r>n||isNaN(n))&&(n=r),(o<s||isNaN(s))&&(s=o),u>=0?(a=(t.min.z-f.z)*u,c=(t.max.z-f.z)*u):(a=(t.max.z-f.z)*u,c=(t.min.z-f.z)*u),n>c||a>s)||((a>n||n!==n)&&(n=a),(c<s||s!==s)&&(s=c),s<0)?null:this.at(n>=0?n:s,e)}intersectsBox(t){return this.intersectBox(t,kn)!==null}intersectTriangle(t,e,n,s,r){To.subVectors(e,t),pr.subVectors(n,t),Ao.crossVectors(To,pr);let o=this.direction.dot(Ao),a;if(o>0){if(s)return null;a=1}else if(o<0)a=-1,o=-o;else return null;Jn.subVectors(this.origin,t);const c=a*this.direction.dot(pr.crossVectors(Jn,pr));if(c<0)return null;const l=a*this.direction.dot(To.cross(Jn));if(l<0||c+l>o)return null;const h=-a*Jn.dot(Ao);return h<0?null:this.at(h/o,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Wt{constructor(t,e,n,s,r,o,a,c,l,h,u,f,m,g,_,p){Wt.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,o,a,c,l,h,u,f,m,g,_,p)}set(t,e,n,s,r,o,a,c,l,h,u,f,m,g,_,p){const d=this.elements;return d[0]=t,d[4]=e,d[8]=n,d[12]=s,d[1]=r,d[5]=o,d[9]=a,d[13]=c,d[2]=l,d[6]=h,d[10]=u,d[14]=f,d[3]=m,d[7]=g,d[11]=_,d[15]=p,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Wt().fromArray(this.elements)}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){const e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){const e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){const e=this.elements,n=t.elements,s=1/Hi.setFromMatrixColumn(t,0).length(),r=1/Hi.setFromMatrixColumn(t,1).length(),o=1/Hi.setFromMatrixColumn(t,2).length();return e[0]=n[0]*s,e[1]=n[1]*s,e[2]=n[2]*s,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*o,e[9]=n[9]*o,e[10]=n[10]*o,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){const e=this.elements,n=t.x,s=t.y,r=t.z,o=Math.cos(n),a=Math.sin(n),c=Math.cos(s),l=Math.sin(s),h=Math.cos(r),u=Math.sin(r);if(t.order==="XYZ"){const f=o*h,m=o*u,g=a*h,_=a*u;e[0]=c*h,e[4]=-c*u,e[8]=l,e[1]=m+g*l,e[5]=f-_*l,e[9]=-a*c,e[2]=_-f*l,e[6]=g+m*l,e[10]=o*c}else if(t.order==="YXZ"){const f=c*h,m=c*u,g=l*h,_=l*u;e[0]=f+_*a,e[4]=g*a-m,e[8]=o*l,e[1]=o*u,e[5]=o*h,e[9]=-a,e[2]=m*a-g,e[6]=_+f*a,e[10]=o*c}else if(t.order==="ZXY"){const f=c*h,m=c*u,g=l*h,_=l*u;e[0]=f-_*a,e[4]=-o*u,e[8]=g+m*a,e[1]=m+g*a,e[5]=o*h,e[9]=_-f*a,e[2]=-o*l,e[6]=a,e[10]=o*c}else if(t.order==="ZYX"){const f=o*h,m=o*u,g=a*h,_=a*u;e[0]=c*h,e[4]=g*l-m,e[8]=f*l+_,e[1]=c*u,e[5]=_*l+f,e[9]=m*l-g,e[2]=-l,e[6]=a*c,e[10]=o*c}else if(t.order==="YZX"){const f=o*c,m=o*l,g=a*c,_=a*l;e[0]=c*h,e[4]=_-f*u,e[8]=g*u+m,e[1]=u,e[5]=o*h,e[9]=-a*h,e[2]=-l*h,e[6]=m*u+g,e[10]=f-_*u}else if(t.order==="XZY"){const f=o*c,m=o*l,g=a*c,_=a*l;e[0]=c*h,e[4]=-u,e[8]=l*h,e[1]=f*u+_,e[5]=o*h,e[9]=m*u-g,e[2]=g*u-m,e[6]=a*h,e[10]=_*u+f}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(Kd,t,Zd)}lookAt(t,e,n){const s=this.elements;return rn.subVectors(t,e),rn.lengthSq()===0&&(rn.z=1),rn.normalize(),Qn.crossVectors(n,rn),Qn.lengthSq()===0&&(Math.abs(n.z)===1?rn.x+=1e-4:rn.z+=1e-4,rn.normalize(),Qn.crossVectors(n,rn)),Qn.normalize(),mr.crossVectors(rn,Qn),s[0]=Qn.x,s[4]=mr.x,s[8]=rn.x,s[1]=Qn.y,s[5]=mr.y,s[9]=rn.y,s[2]=Qn.z,s[6]=mr.z,s[10]=rn.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,s=e.elements,r=this.elements,o=n[0],a=n[4],c=n[8],l=n[12],h=n[1],u=n[5],f=n[9],m=n[13],g=n[2],_=n[6],p=n[10],d=n[14],y=n[3],b=n[7],w=n[11],C=n[15],A=s[0],S=s[4],M=s[8],x=s[12],v=s[1],E=s[5],P=s[9],L=s[13],N=s[2],F=s[6],U=s[10],O=s[14],k=s[3],K=s[7],Y=s[11],it=s[15];return r[0]=o*A+a*v+c*N+l*k,r[4]=o*S+a*E+c*F+l*K,r[8]=o*M+a*P+c*U+l*Y,r[12]=o*x+a*L+c*O+l*it,r[1]=h*A+u*v+f*N+m*k,r[5]=h*S+u*E+f*F+m*K,r[9]=h*M+u*P+f*U+m*Y,r[13]=h*x+u*L+f*O+m*it,r[2]=g*A+_*v+p*N+d*k,r[6]=g*S+_*E+p*F+d*K,r[10]=g*M+_*P+p*U+d*Y,r[14]=g*x+_*L+p*O+d*it,r[3]=y*A+b*v+w*N+C*k,r[7]=y*S+b*E+w*F+C*K,r[11]=y*M+b*P+w*U+C*Y,r[15]=y*x+b*L+w*O+C*it,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[4],s=t[8],r=t[12],o=t[1],a=t[5],c=t[9],l=t[13],h=t[2],u=t[6],f=t[10],m=t[14],g=t[3],_=t[7],p=t[11],d=t[15];return g*(+r*c*u-s*l*u-r*a*f+n*l*f+s*a*m-n*c*m)+_*(+e*c*m-e*l*f+r*o*f-s*o*m+s*l*h-r*c*h)+p*(+e*l*u-e*a*m-r*o*u+n*o*m+r*a*h-n*l*h)+d*(-s*a*h-e*c*u+e*a*f+s*o*u-n*o*f+n*c*h)}transpose(){const t=this.elements;let e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){const s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=n),this}invert(){const t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],o=t[4],a=t[5],c=t[6],l=t[7],h=t[8],u=t[9],f=t[10],m=t[11],g=t[12],_=t[13],p=t[14],d=t[15],y=u*p*l-_*f*l+_*c*m-a*p*m-u*c*d+a*f*d,b=g*f*l-h*p*l-g*c*m+o*p*m+h*c*d-o*f*d,w=h*_*l-g*u*l+g*a*m-o*_*m-h*a*d+o*u*d,C=g*u*c-h*_*c-g*a*f+o*_*f+h*a*p-o*u*p,A=e*y+n*b+s*w+r*C;if(A===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const S=1/A;return t[0]=y*S,t[1]=(_*f*r-u*p*r-_*s*m+n*p*m+u*s*d-n*f*d)*S,t[2]=(a*p*r-_*c*r+_*s*l-n*p*l-a*s*d+n*c*d)*S,t[3]=(u*c*r-a*f*r-u*s*l+n*f*l+a*s*m-n*c*m)*S,t[4]=b*S,t[5]=(h*p*r-g*f*r+g*s*m-e*p*m-h*s*d+e*f*d)*S,t[6]=(g*c*r-o*p*r-g*s*l+e*p*l+o*s*d-e*c*d)*S,t[7]=(o*f*r-h*c*r+h*s*l-e*f*l-o*s*m+e*c*m)*S,t[8]=w*S,t[9]=(g*u*r-h*_*r-g*n*m+e*_*m+h*n*d-e*u*d)*S,t[10]=(o*_*r-g*a*r+g*n*l-e*_*l-o*n*d+e*a*d)*S,t[11]=(h*a*r-o*u*r-h*n*l+e*u*l+o*n*m-e*a*m)*S,t[12]=C*S,t[13]=(h*_*s-g*u*s+g*n*f-e*_*f-h*n*p+e*u*p)*S,t[14]=(g*a*s-o*_*s-g*n*c+e*_*c+o*n*p-e*a*p)*S,t[15]=(o*u*s-h*a*s+h*n*c-e*u*c-o*n*f+e*a*f)*S,this}scale(t){const e=this.elements,n=t.x,s=t.y,r=t.z;return e[0]*=n,e[4]*=s,e[8]*=r,e[1]*=n,e[5]*=s,e[9]*=r,e[2]*=n,e[6]*=s,e[10]*=r,e[3]*=n,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){const t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,s))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){const e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){const n=Math.cos(e),s=Math.sin(e),r=1-n,o=t.x,a=t.y,c=t.z,l=r*o,h=r*a;return this.set(l*o+n,l*a-s*c,l*c+s*a,0,l*a+s*c,h*a+n,h*c-s*o,0,l*c-s*a,h*c+s*o,r*c*c+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,s,r,o){return this.set(1,n,r,0,t,1,o,0,e,s,1,0,0,0,0,1),this}compose(t,e,n){const s=this.elements,r=e._x,o=e._y,a=e._z,c=e._w,l=r+r,h=o+o,u=a+a,f=r*l,m=r*h,g=r*u,_=o*h,p=o*u,d=a*u,y=c*l,b=c*h,w=c*u,C=n.x,A=n.y,S=n.z;return s[0]=(1-(_+d))*C,s[1]=(m+w)*C,s[2]=(g-b)*C,s[3]=0,s[4]=(m-w)*A,s[5]=(1-(f+d))*A,s[6]=(p+y)*A,s[7]=0,s[8]=(g+b)*S,s[9]=(p-y)*S,s[10]=(1-(f+_))*S,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,n){const s=this.elements;let r=Hi.set(s[0],s[1],s[2]).length();const o=Hi.set(s[4],s[5],s[6]).length(),a=Hi.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),t.x=s[12],t.y=s[13],t.z=s[14],_n.copy(this);const l=1/r,h=1/o,u=1/a;return _n.elements[0]*=l,_n.elements[1]*=l,_n.elements[2]*=l,_n.elements[4]*=h,_n.elements[5]*=h,_n.elements[6]*=h,_n.elements[8]*=u,_n.elements[9]*=u,_n.elements[10]*=u,e.setFromRotationMatrix(_n),n.x=r,n.y=o,n.z=a,this}makePerspective(t,e,n,s,r,o,a=Vn){const c=this.elements,l=2*r/(e-t),h=2*r/(n-s),u=(e+t)/(e-t),f=(n+s)/(n-s);let m,g;if(a===Vn)m=-(o+r)/(o-r),g=-2*o*r/(o-r);else if(a===Kr)m=-o/(o-r),g=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return c[0]=l,c[4]=0,c[8]=u,c[12]=0,c[1]=0,c[5]=h,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=m,c[14]=g,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(t,e,n,s,r,o,a=Vn){const c=this.elements,l=1/(e-t),h=1/(n-s),u=1/(o-r),f=(e+t)*l,m=(n+s)*h;let g,_;if(a===Vn)g=(o+r)*u,_=-2*u;else if(a===Kr)g=r*u,_=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return c[0]=2*l,c[4]=0,c[8]=0,c[12]=-f,c[1]=0,c[5]=2*h,c[9]=0,c[13]=-m,c[2]=0,c[6]=0,c[10]=_,c[14]=-g,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(t){const e=this.elements,n=t.elements;for(let s=0;s<16;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}}const Hi=new I,_n=new Wt,Kd=new I(0,0,0),Zd=new I(1,1,1),Qn=new I,mr=new I,rn=new I,cl=new Wt,ll=new Un;class Dn{constructor(t=0,e=0,n=0,s=Dn.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,s=this._order){return this._x=t,this._y=e,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){const s=t.elements,r=s[0],o=s[4],a=s[8],c=s[1],l=s[5],h=s[9],u=s[2],f=s[6],m=s[10];switch(e){case"XYZ":this._y=Math.asin(Ye(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,m),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(f,l),this._z=0);break;case"YXZ":this._x=Math.asin(-Ye(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,m),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(Ye(f,-1,1)),Math.abs(f)<.9999999?(this._y=Math.atan2(-u,m),this._z=Math.atan2(-o,l)):(this._y=0,this._z=Math.atan2(c,r));break;case"ZYX":this._y=Math.asin(-Ye(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(f,m),this._z=Math.atan2(c,r)):(this._x=0,this._z=Math.atan2(-o,l));break;case"YZX":this._z=Math.asin(Ye(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-h,l),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(a,m));break;case"XZY":this._z=Math.asin(-Ye(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(f,l),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-h,m),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return cl.makeRotationFromQuaternion(t),this.setFromRotationMatrix(cl,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return ll.setFromEuler(this),this.setFromQuaternion(ll,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Dn.DEFAULT_ORDER="XYZ";class nu{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let Jd=0;const hl=new I,Vi=new Un,Bn=new Wt,gr=new I,Ls=new I,Qd=new I,tp=new Un,ul=new I(1,0,0),fl=new I(0,1,0),dl=new I(0,0,1),pl={type:"added"},ep={type:"removed"},Wi={type:"childadded",child:null},Ro={type:"childremoved",child:null};class we extends ws{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Jd++}),this.uuid=Wn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=we.DEFAULT_UP.clone();const t=new I,e=new Dn,n=new Un,s=new I(1,1,1);function r(){n.setFromEuler(e,!1)}function o(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new Wt},normalMatrix:{value:new zt}}),this.matrix=new Wt,this.matrixWorld=new Wt,this.matrixAutoUpdate=we.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=we.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new nu,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return Vi.setFromAxisAngle(t,e),this.quaternion.multiply(Vi),this}rotateOnWorldAxis(t,e){return Vi.setFromAxisAngle(t,e),this.quaternion.premultiply(Vi),this}rotateX(t){return this.rotateOnAxis(ul,t)}rotateY(t){return this.rotateOnAxis(fl,t)}rotateZ(t){return this.rotateOnAxis(dl,t)}translateOnAxis(t,e){return hl.copy(t).applyQuaternion(this.quaternion),this.position.add(hl.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(ul,t)}translateY(t){return this.translateOnAxis(fl,t)}translateZ(t){return this.translateOnAxis(dl,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(Bn.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?gr.copy(t):gr.set(t,e,n);const s=this.parent;this.updateWorldMatrix(!0,!1),Ls.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Bn.lookAt(Ls,gr,this.up):Bn.lookAt(gr,Ls,this.up),this.quaternion.setFromRotationMatrix(Bn),s&&(Bn.extractRotation(s.matrixWorld),Vi.setFromRotationMatrix(Bn),this.quaternion.premultiply(Vi.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(pl),Wi.child=t,this.dispatchEvent(Wi),Wi.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(ep),Ro.child=t,this.dispatchEvent(Ro),Ro.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),Bn.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),Bn.multiply(t.parent.matrixWorld)),t.applyMatrix4(Bn),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(pl),Wi.child=t,this.dispatchEvent(Wi),Wi.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,s=this.children.length;n<s;n++){const o=this.children[n].getObjectByProperty(t,e);if(o!==void 0)return o}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);const s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ls,t,Qd),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ls,tp,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);const e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverseVisible(t)}traverseAncestors(t){const e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e){const n=this.parent;if(t===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),e===!0){const s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(t){const e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(t),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(a,c){return a[c.uuid]===void 0&&(a[c.uuid]=c.toJSON(t)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);const a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){const c=a.shapes;if(Array.isArray(c))for(let l=0,h=c.length;l<h;l++){const u=c[l];r(t.shapes,u)}else r(t.shapes,c)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const a=[];for(let c=0,l=this.material.length;c<l;c++)a.push(r(t.materials,this.material[c]));s.material=a}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let a=0;a<this.children.length;a++)s.children.push(this.children[a].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let a=0;a<this.animations.length;a++){const c=this.animations[a];s.animations.push(r(t.animations,c))}}if(e){const a=o(t.geometries),c=o(t.materials),l=o(t.textures),h=o(t.images),u=o(t.shapes),f=o(t.skeletons),m=o(t.animations),g=o(t.nodes);a.length>0&&(n.geometries=a),c.length>0&&(n.materials=c),l.length>0&&(n.textures=l),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),f.length>0&&(n.skeletons=f),m.length>0&&(n.animations=m),g.length>0&&(n.nodes=g)}return n.object=s,n;function o(a){const c=[];for(const l in a){const h=a[l];delete h.metadata,c.push(h)}return c}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){const s=t.children[n];this.add(s.clone())}return this}}we.DEFAULT_UP=new I(0,1,0);we.DEFAULT_MATRIX_AUTO_UPDATE=!0;we.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const xn=new I,zn=new I,Co=new I,Gn=new I,Xi=new I,$i=new I,ml=new I,Po=new I,Lo=new I,Do=new I,Io=new Se,Uo=new Se,No=new Se;class dn{constructor(t=new I,e=new I,n=new I){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,s){s.subVectors(n,e),xn.subVectors(t,e),s.cross(xn);const r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,n,s,r){xn.subVectors(s,e),zn.subVectors(n,e),Co.subVectors(t,e);const o=xn.dot(xn),a=xn.dot(zn),c=xn.dot(Co),l=zn.dot(zn),h=zn.dot(Co),u=o*l-a*a;if(u===0)return r.set(0,0,0),null;const f=1/u,m=(l*c-a*h)*f,g=(o*h-a*c)*f;return r.set(1-m-g,g,m)}static containsPoint(t,e,n,s){return this.getBarycoord(t,e,n,s,Gn)===null?!1:Gn.x>=0&&Gn.y>=0&&Gn.x+Gn.y<=1}static getInterpolation(t,e,n,s,r,o,a,c){return this.getBarycoord(t,e,n,s,Gn)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(r,Gn.x),c.addScaledVector(o,Gn.y),c.addScaledVector(a,Gn.z),c)}static getInterpolatedAttribute(t,e,n,s,r,o){return Io.setScalar(0),Uo.setScalar(0),No.setScalar(0),Io.fromBufferAttribute(t,e),Uo.fromBufferAttribute(t,n),No.fromBufferAttribute(t,s),o.setScalar(0),o.addScaledVector(Io,r.x),o.addScaledVector(Uo,r.y),o.addScaledVector(No,r.z),o}static isFrontFacing(t,e,n,s){return xn.subVectors(n,e),zn.subVectors(t,e),xn.cross(zn).dot(s)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,s){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,n,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return xn.subVectors(this.c,this.b),zn.subVectors(this.a,this.b),xn.cross(zn).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return dn.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return dn.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,s,r){return dn.getInterpolation(t,this.a,this.b,this.c,e,n,s,r)}containsPoint(t){return dn.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return dn.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){const n=this.a,s=this.b,r=this.c;let o,a;Xi.subVectors(s,n),$i.subVectors(r,n),Po.subVectors(t,n);const c=Xi.dot(Po),l=$i.dot(Po);if(c<=0&&l<=0)return e.copy(n);Lo.subVectors(t,s);const h=Xi.dot(Lo),u=$i.dot(Lo);if(h>=0&&u<=h)return e.copy(s);const f=c*u-h*l;if(f<=0&&c>=0&&h<=0)return o=c/(c-h),e.copy(n).addScaledVector(Xi,o);Do.subVectors(t,r);const m=Xi.dot(Do),g=$i.dot(Do);if(g>=0&&m<=g)return e.copy(r);const _=m*l-c*g;if(_<=0&&l>=0&&g<=0)return a=l/(l-g),e.copy(n).addScaledVector($i,a);const p=h*g-m*u;if(p<=0&&u-h>=0&&m-g>=0)return ml.subVectors(r,s),a=(u-h)/(u-h+(m-g)),e.copy(s).addScaledVector(ml,a);const d=1/(p+_+f);return o=_*d,a=f*d,e.copy(n).addScaledVector(Xi,o).addScaledVector($i,a)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}const iu={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},ti={h:0,s:0,l:0},_r={h:0,s:0,l:0};function Fo(i,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?i+(t-i)*6*e:e<1/2?t:e<2/3?i+(t-i)*6*(2/3-e):i}class _t{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){const s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Te){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Kt.toWorkingColorSpace(this,e),this}setRGB(t,e,n,s=Kt.workingColorSpace){return this.r=t,this.g=e,this.b=n,Kt.toWorkingColorSpace(this,s),this}setHSL(t,e,n,s=Kt.workingColorSpace){if(t=dc(t,1),e=Ye(e,0,1),n=Ye(n,0,1),e===0)this.r=this.g=this.b=n;else{const r=n<=.5?n*(1+e):n+e-n*e,o=2*n-r;this.r=Fo(o,r,t+1/3),this.g=Fo(o,r,t),this.b=Fo(o,r,t-1/3)}return Kt.toWorkingColorSpace(this,s),this}setStyle(t,e=Te){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r;const o=s[1],a=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){const r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(o===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Te){const n=iu[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Xn(t.r),this.g=Xn(t.g),this.b=Xn(t.b),this}copyLinearToSRGB(t){return this.r=ls(t.r),this.g=ls(t.g),this.b=ls(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Te){return Kt.fromWorkingColorSpace(Ve.copy(this),t),Math.round(Ye(Ve.r*255,0,255))*65536+Math.round(Ye(Ve.g*255,0,255))*256+Math.round(Ye(Ve.b*255,0,255))}getHexString(t=Te){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=Kt.workingColorSpace){Kt.fromWorkingColorSpace(Ve.copy(this),e);const n=Ve.r,s=Ve.g,r=Ve.b,o=Math.max(n,s,r),a=Math.min(n,s,r);let c,l;const h=(a+o)/2;if(a===o)c=0,l=0;else{const u=o-a;switch(l=h<=.5?u/(o+a):u/(2-o-a),o){case n:c=(s-r)/u+(s<r?6:0);break;case s:c=(r-n)/u+2;break;case r:c=(n-s)/u+4;break}c/=6}return t.h=c,t.s=l,t.l=h,t}getRGB(t,e=Kt.workingColorSpace){return Kt.fromWorkingColorSpace(Ve.copy(this),e),t.r=Ve.r,t.g=Ve.g,t.b=Ve.b,t}getStyle(t=Te){Kt.fromWorkingColorSpace(Ve.copy(this),t);const e=Ve.r,n=Ve.g,s=Ve.b;return t!==Te?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(t,e,n){return this.getHSL(ti),this.setHSL(ti.h+t,ti.s+e,ti.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(ti),t.getHSL(_r);const n=qs(ti.h,_r.h,e),s=qs(ti.s,_r.s,e),r=qs(ti.l,_r.l,e);return this.setHSL(n,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const e=this.r,n=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*s,this.g=r[1]*e+r[4]*n+r[7]*s,this.b=r[2]*e+r[5]*n+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Ve=new _t;_t.NAMES=iu;let np=0;class fi extends ws{static get type(){return"Material"}get type(){return this.constructor.type}set type(t){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:np++}),this.uuid=Wn(),this.name="",this.blending=as,this.side=li,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=ca,this.blendDst=la,this.blendEquation=wi,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new _t(0,0,0),this.blendAlpha=0,this.depthFunc=us,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Jc,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Oi,this.stencilZFail=Oi,this.stencilZPass=Oi,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const e in t){const n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}const s=this[e];if(s===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});const n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==as&&(n.blending=this.blending),this.side!==li&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==ca&&(n.blendSrc=this.blendSrc),this.blendDst!==la&&(n.blendDst=this.blendDst),this.blendEquation!==wi&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==us&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Jc&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Oi&&(n.stencilFail=this.stencilFail),this.stencilZFail!==Oi&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==Oi&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){const o=[];for(const a in r){const c=r[a];delete c.metadata,o.push(c)}return o}if(e){const r=s(t.textures),o=s(t.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const e=t.clippingPlanes;let n=null;if(e!==null){const s=e.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}}class cn extends fi{static get type(){return"MeshBasicMaterial"}constructor(t){super(),this.isMeshBasicMaterial=!0,this.color=new _t(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Dn,this.combine=rc,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const Ee=new I,xr=new Ft;class ve{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=$a,this.updateRanges=[],this.gpuType=Cn,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[n+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)xr.fromBufferAttribute(this,e),xr.applyMatrix3(t),this.setXY(e,xr.x,xr.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.applyMatrix3(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.applyMatrix4(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.applyNormalMatrix(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.transformDirection(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=yn(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=se(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=yn(e,this.array)),e}setX(t,e){return this.normalized&&(e=se(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=yn(e,this.array)),e}setY(t,e){return this.normalized&&(e=se(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=yn(e,this.array)),e}setZ(t,e){return this.normalized&&(e=se(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=yn(e,this.array)),e}setW(t,e){return this.normalized&&(e=se(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=se(e,this.array),n=se(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,s){return t*=this.itemSize,this.normalized&&(e=se(e,this.array),n=se(n,this.array),s=se(s,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t*=this.itemSize,this.normalized&&(e=se(e,this.array),n=se(n,this.array),s=se(s,this.array),r=se(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==$a&&(t.usage=this.usage),t}}class su extends ve{constructor(t,e,n){super(new Uint16Array(t),e,n)}}class ru extends ve{constructor(t,e,n){super(new Uint32Array(t),e,n)}}class re extends ve{constructor(t,e,n){super(new Float32Array(t),e,n)}}let ip=0;const un=new Wt,Oo=new we,qi=new I,on=new Ii,Ds=new Ii,De=new I;class Me extends ws{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:ip++}),this.uuid=Wn(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(Qh(t)?ru:su)(t,1):this.index=t,this}setIndirect(t){return this.indirect=t,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){const e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const r=new zt().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return un.makeRotationFromQuaternion(t),this.applyMatrix4(un),this}rotateX(t){return un.makeRotationX(t),this.applyMatrix4(un),this}rotateY(t){return un.makeRotationY(t),this.applyMatrix4(un),this}rotateZ(t){return un.makeRotationZ(t),this.applyMatrix4(un),this}translate(t,e,n){return un.makeTranslation(t,e,n),this.applyMatrix4(un),this}scale(t,e,n){return un.makeScale(t,e,n),this.applyMatrix4(un),this}lookAt(t){return Oo.lookAt(t),Oo.updateMatrix(),this.applyMatrix4(Oo.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(qi).negate(),this.translate(qi.x,qi.y,qi.z),this}setFromPoints(t){const e=this.getAttribute("position");if(e===void 0){const n=[];for(let s=0,r=t.length;s<r;s++){const o=t[s];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new re(n,3))}else{for(let n=0,s=e.count;n<s;n++){const r=t[n];e.setXYZ(n,r.x,r.y,r.z||0)}t.length>e.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Ii);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new I(-1/0,-1/0,-1/0),new I(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,s=e.length;n<s;n++){const r=e[n];on.setFromBufferAttribute(r),this.morphTargetsRelative?(De.addVectors(this.boundingBox.min,on.min),this.boundingBox.expandByPoint(De),De.addVectors(this.boundingBox.max,on.max),this.boundingBox.expandByPoint(De)):(this.boundingBox.expandByPoint(on.min),this.boundingBox.expandByPoint(on.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ui);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new I,1/0);return}if(t){const n=this.boundingSphere.center;if(on.setFromBufferAttribute(t),e)for(let r=0,o=e.length;r<o;r++){const a=e[r];Ds.setFromBufferAttribute(a),this.morphTargetsRelative?(De.addVectors(on.min,Ds.min),on.expandByPoint(De),De.addVectors(on.max,Ds.max),on.expandByPoint(De)):(on.expandByPoint(Ds.min),on.expandByPoint(Ds.max))}on.getCenter(n);let s=0;for(let r=0,o=t.count;r<o;r++)De.fromBufferAttribute(t,r),s=Math.max(s,n.distanceToSquared(De));if(e)for(let r=0,o=e.length;r<o;r++){const a=e[r],c=this.morphTargetsRelative;for(let l=0,h=a.count;l<h;l++)De.fromBufferAttribute(a,l),c&&(qi.fromBufferAttribute(t,l),De.add(qi)),s=Math.max(s,n.distanceToSquared(De))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=e.position,s=e.normal,r=e.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new ve(new Float32Array(4*n.count),4));const o=this.getAttribute("tangent"),a=[],c=[];for(let M=0;M<n.count;M++)a[M]=new I,c[M]=new I;const l=new I,h=new I,u=new I,f=new Ft,m=new Ft,g=new Ft,_=new I,p=new I;function d(M,x,v){l.fromBufferAttribute(n,M),h.fromBufferAttribute(n,x),u.fromBufferAttribute(n,v),f.fromBufferAttribute(r,M),m.fromBufferAttribute(r,x),g.fromBufferAttribute(r,v),h.sub(l),u.sub(l),m.sub(f),g.sub(f);const E=1/(m.x*g.y-g.x*m.y);isFinite(E)&&(_.copy(h).multiplyScalar(g.y).addScaledVector(u,-m.y).multiplyScalar(E),p.copy(u).multiplyScalar(m.x).addScaledVector(h,-g.x).multiplyScalar(E),a[M].add(_),a[x].add(_),a[v].add(_),c[M].add(p),c[x].add(p),c[v].add(p))}let y=this.groups;y.length===0&&(y=[{start:0,count:t.count}]);for(let M=0,x=y.length;M<x;++M){const v=y[M],E=v.start,P=v.count;for(let L=E,N=E+P;L<N;L+=3)d(t.getX(L+0),t.getX(L+1),t.getX(L+2))}const b=new I,w=new I,C=new I,A=new I;function S(M){C.fromBufferAttribute(s,M),A.copy(C);const x=a[M];b.copy(x),b.sub(C.multiplyScalar(C.dot(x))).normalize(),w.crossVectors(A,x);const E=w.dot(c[M])<0?-1:1;o.setXYZW(M,b.x,b.y,b.z,E)}for(let M=0,x=y.length;M<x;++M){const v=y[M],E=v.start,P=v.count;for(let L=E,N=E+P;L<N;L+=3)S(t.getX(L+0)),S(t.getX(L+1)),S(t.getX(L+2))}}computeVertexNormals(){const t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new ve(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let f=0,m=n.count;f<m;f++)n.setXYZ(f,0,0,0);const s=new I,r=new I,o=new I,a=new I,c=new I,l=new I,h=new I,u=new I;if(t)for(let f=0,m=t.count;f<m;f+=3){const g=t.getX(f+0),_=t.getX(f+1),p=t.getX(f+2);s.fromBufferAttribute(e,g),r.fromBufferAttribute(e,_),o.fromBufferAttribute(e,p),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),a.fromBufferAttribute(n,g),c.fromBufferAttribute(n,_),l.fromBufferAttribute(n,p),a.add(h),c.add(h),l.add(h),n.setXYZ(g,a.x,a.y,a.z),n.setXYZ(_,c.x,c.y,c.z),n.setXYZ(p,l.x,l.y,l.z)}else for(let f=0,m=e.count;f<m;f+=3)s.fromBufferAttribute(e,f+0),r.fromBufferAttribute(e,f+1),o.fromBufferAttribute(e,f+2),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),n.setXYZ(f+0,h.x,h.y,h.z),n.setXYZ(f+1,h.x,h.y,h.z),n.setXYZ(f+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)De.fromBufferAttribute(t,e),De.normalize(),t.setXYZ(e,De.x,De.y,De.z)}toNonIndexed(){function t(a,c){const l=a.array,h=a.itemSize,u=a.normalized,f=new l.constructor(c.length*h);let m=0,g=0;for(let _=0,p=c.length;_<p;_++){a.isInterleavedBufferAttribute?m=c[_]*a.data.stride+a.offset:m=c[_]*h;for(let d=0;d<h;d++)f[g++]=l[m++]}return new ve(f,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const e=new Me,n=this.index.array,s=this.attributes;for(const a in s){const c=s[a],l=t(c,n);e.setAttribute(a,l)}const r=this.morphAttributes;for(const a in r){const c=[],l=r[a];for(let h=0,u=l.length;h<u;h++){const f=l[h],m=t(f,n);c.push(m)}e.morphAttributes[a]=c}e.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let a=0,c=o.length;a<c;a++){const l=o[a];e.addGroup(l.start,l.count,l.materialIndex)}return e}toJSON(){const t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(t[l]=c[l]);return t}t.data={attributes:{}};const e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});const n=this.attributes;for(const c in n){const l=n[c];t.data.attributes[c]=l.toJSON(t.data)}const s={};let r=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],h=[];for(let u=0,f=l.length;u<f;u++){const m=l[u];h.push(m.toJSON(t.data))}h.length>0&&(s[c]=h,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(t.data.groups=JSON.parse(JSON.stringify(o)));const a=this.boundingSphere;return a!==null&&(t.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const e={};this.name=t.name;const n=t.index;n!==null&&this.setIndex(n.clone(e));const s=t.attributes;for(const l in s){const h=s[l];this.setAttribute(l,h.clone(e))}const r=t.morphAttributes;for(const l in r){const h=[],u=r[l];for(let f=0,m=u.length;f<m;f++)h.push(u[f].clone(e));this.morphAttributes[l]=h}this.morphTargetsRelative=t.morphTargetsRelative;const o=t.groups;for(let l=0,h=o.length;l<h;l++){const u=o[l];this.addGroup(u.start,u.count,u.materialIndex)}const a=t.boundingBox;a!==null&&(this.boundingBox=a.clone());const c=t.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const gl=new Wt,gi=new pc,vr=new Ui,_l=new I,Mr=new I,yr=new I,Sr=new I,ko=new I,wr=new I,xl=new I,br=new I;class tt extends we{constructor(t=new Me,e=new cn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){const a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(t,e){const n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;e.fromBufferAttribute(s,t);const a=this.morphTargetInfluences;if(r&&a){wr.set(0,0,0);for(let c=0,l=r.length;c<l;c++){const h=a[c],u=r[c];h!==0&&(ko.fromBufferAttribute(u,t),o?wr.addScaledVector(ko,h):wr.addScaledVector(ko.sub(e),h))}e.add(wr)}return e}raycast(t,e){const n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),vr.copy(n.boundingSphere),vr.applyMatrix4(r),gi.copy(t.ray).recast(t.near),!(vr.containsPoint(gi.origin)===!1&&(gi.intersectSphere(vr,_l)===null||gi.origin.distanceToSquared(_l)>(t.far-t.near)**2))&&(gl.copy(r).invert(),gi.copy(t.ray).applyMatrix4(gl),!(n.boundingBox!==null&&gi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,gi)))}_computeIntersections(t,e,n){let s;const r=this.geometry,o=this.material,a=r.index,c=r.attributes.position,l=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,f=r.groups,m=r.drawRange;if(a!==null)if(Array.isArray(o))for(let g=0,_=f.length;g<_;g++){const p=f[g],d=o[p.materialIndex],y=Math.max(p.start,m.start),b=Math.min(a.count,Math.min(p.start+p.count,m.start+m.count));for(let w=y,C=b;w<C;w+=3){const A=a.getX(w),S=a.getX(w+1),M=a.getX(w+2);s=Er(this,d,t,n,l,h,u,A,S,M),s&&(s.faceIndex=Math.floor(w/3),s.face.materialIndex=p.materialIndex,e.push(s))}}else{const g=Math.max(0,m.start),_=Math.min(a.count,m.start+m.count);for(let p=g,d=_;p<d;p+=3){const y=a.getX(p),b=a.getX(p+1),w=a.getX(p+2);s=Er(this,o,t,n,l,h,u,y,b,w),s&&(s.faceIndex=Math.floor(p/3),e.push(s))}}else if(c!==void 0)if(Array.isArray(o))for(let g=0,_=f.length;g<_;g++){const p=f[g],d=o[p.materialIndex],y=Math.max(p.start,m.start),b=Math.min(c.count,Math.min(p.start+p.count,m.start+m.count));for(let w=y,C=b;w<C;w+=3){const A=w,S=w+1,M=w+2;s=Er(this,d,t,n,l,h,u,A,S,M),s&&(s.faceIndex=Math.floor(w/3),s.face.materialIndex=p.materialIndex,e.push(s))}}else{const g=Math.max(0,m.start),_=Math.min(c.count,m.start+m.count);for(let p=g,d=_;p<d;p+=3){const y=p,b=p+1,w=p+2;s=Er(this,o,t,n,l,h,u,y,b,w),s&&(s.faceIndex=Math.floor(p/3),e.push(s))}}}}function sp(i,t,e,n,s,r,o,a){let c;if(t.side===Qe?c=n.intersectTriangle(o,r,s,!0,a):c=n.intersectTriangle(s,r,o,t.side===li,a),c===null)return null;br.copy(a),br.applyMatrix4(i.matrixWorld);const l=e.ray.origin.distanceTo(br);return l<e.near||l>e.far?null:{distance:l,point:br.clone(),object:i}}function Er(i,t,e,n,s,r,o,a,c,l){i.getVertexPosition(a,Mr),i.getVertexPosition(c,yr),i.getVertexPosition(l,Sr);const h=sp(i,t,e,n,Mr,yr,Sr,xl);if(h){const u=new I;dn.getBarycoord(xl,Mr,yr,Sr,u),s&&(h.uv=dn.getInterpolatedAttribute(s,a,c,l,u,new Ft)),r&&(h.uv1=dn.getInterpolatedAttribute(r,a,c,l,u,new Ft)),o&&(h.normal=dn.getInterpolatedAttribute(o,a,c,l,u,new I),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));const f={a,b:c,c:l,normal:new I,materialIndex:0};dn.getNormal(Mr,yr,Sr,f.normal),h.face=f,h.barycoord=u}return h}class Nt extends Me{constructor(t=1,e=1,n=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:s,heightSegments:r,depthSegments:o};const a=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);const c=[],l=[],h=[],u=[];let f=0,m=0;g("z","y","x",-1,-1,n,e,t,o,r,0),g("z","y","x",1,-1,n,e,-t,o,r,1),g("x","z","y",1,1,t,n,e,s,o,2),g("x","z","y",1,-1,t,n,-e,s,o,3),g("x","y","z",1,-1,t,e,n,s,r,4),g("x","y","z",-1,-1,t,e,-n,s,r,5),this.setIndex(c),this.setAttribute("position",new re(l,3)),this.setAttribute("normal",new re(h,3)),this.setAttribute("uv",new re(u,2));function g(_,p,d,y,b,w,C,A,S,M,x){const v=w/S,E=C/M,P=w/2,L=C/2,N=A/2,F=S+1,U=M+1;let O=0,k=0;const K=new I;for(let Y=0;Y<U;Y++){const it=Y*E-L;for(let ct=0;ct<F;ct++){const xt=ct*v-P;K[_]=xt*y,K[p]=it*b,K[d]=N,l.push(K.x,K.y,K.z),K[_]=0,K[p]=0,K[d]=A>0?1:-1,h.push(K.x,K.y,K.z),u.push(ct/S),u.push(1-Y/M),O+=1}}for(let Y=0;Y<M;Y++)for(let it=0;it<S;it++){const ct=f+it+F*Y,xt=f+it+F*(Y+1),$=f+(it+1)+F*(Y+1),et=f+(it+1)+F*Y;c.push(ct,xt,et),c.push(xt,$,et),k+=6}a.addGroup(m,k,x),m+=k,f+=O}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Nt(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}function xs(i){const t={};for(const e in i){t[e]={};for(const n in i[e]){const s=i[e][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=s.clone():Array.isArray(s)?t[e][n]=s.slice():t[e][n]=s}}return t}function qe(i){const t={};for(let e=0;e<i.length;e++){const n=xs(i[e]);for(const s in n)t[s]=n[s]}return t}function rp(i){const t=[];for(let e=0;e<i.length;e++)t.push(i[e].clone());return t}function ou(i){const t=i.getRenderTarget();return t===null?i.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Kt.workingColorSpace}const op={clone:xs,merge:qe};var ap=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,cp=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class hi extends fi{static get type(){return"ShaderMaterial"}constructor(t){super(),this.isShaderMaterial=!0,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=ap,this.fragmentShader=cp,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=xs(t.uniforms),this.uniformsGroups=rp(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){const e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(const s in this.uniforms){const o=this.uniforms[s].value;o&&o.isTexture?e.uniforms[s]={type:"t",value:o.toJSON(t).uuid}:o&&o.isColor?e.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?e.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?e.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?e.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?e.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?e.uniforms[s]={type:"m4",value:o.toArray()}:e.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;const n={};for(const s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}}class au extends we{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Wt,this.projectionMatrix=new Wt,this.projectionMatrixInverse=new Wt,this.coordinateSystem=Vn}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const ei=new I,vl=new Ft,Ml=new Ft;class je extends au{constructor(t=50,e=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const e=.5*this.getFilmHeight()/t;this.fov=_s*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan($s*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return _s*2*Math.atan(Math.tan($s*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){ei.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(ei.x,ei.y).multiplyScalar(-t/ei.z),ei.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(ei.x,ei.y).multiplyScalar(-t/ei.z)}getViewSize(t,e){return this.getViewBounds(t,vl,Ml),e.subVectors(Ml,vl)}setViewOffset(t,e,n,s,r,o){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let e=t*Math.tan($s*.5*this.fov)/this.zoom,n=2*e,s=this.aspect*n,r=-.5*s;const o=this.view;if(this.view!==null&&this.view.enabled){const c=o.fullWidth,l=o.fullHeight;r+=o.offsetX*s/c,e-=o.offsetY*n/l,s*=o.width/c,n*=o.height/l}const a=this.filmOffset;a!==0&&(r+=t*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-n,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}}const Yi=-90,ji=1;class lp extends we{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new je(Yi,ji,t,e);s.layers=this.layers,this.add(s);const r=new je(Yi,ji,t,e);r.layers=this.layers,this.add(r);const o=new je(Yi,ji,t,e);o.layers=this.layers,this.add(o);const a=new je(Yi,ji,t,e);a.layers=this.layers,this.add(a);const c=new je(Yi,ji,t,e);c.layers=this.layers,this.add(c);const l=new je(Yi,ji,t,e);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const t=this.coordinateSystem,e=this.children.concat(),[n,s,r,o,a,c]=e;for(const l of e)this.remove(l);if(t===Vn)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(t===Kr)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const l of e)this.add(l),l.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[r,o,a,c,l,h]=this.children,u=t.getRenderTarget(),f=t.getActiveCubeFace(),m=t.getActiveMipmapLevel(),g=t.xr.enabled;t.xr.enabled=!1;const _=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,s),t.render(e,r),t.setRenderTarget(n,1,s),t.render(e,o),t.setRenderTarget(n,2,s),t.render(e,a),t.setRenderTarget(n,3,s),t.render(e,c),t.setRenderTarget(n,4,s),t.render(e,l),n.texture.generateMipmaps=_,t.setRenderTarget(n,5,s),t.render(e,h),t.setRenderTarget(u,f,m),t.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class cu extends Xe{constructor(t,e,n,s,r,o,a,c,l,h){t=t!==void 0?t:[],e=e!==void 0?e:fs,super(t,e,n,s,r,o,a,c,l,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class hp extends Li{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;const n={width:t,height:t,depth:1},s=[n,n,n,n,n,n];this.texture=new cu(s,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:Sn}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Nt(5,5,5),r=new hi({name:"CubemapFromEquirect",uniforms:xs(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Qe,blending:ai});r.uniforms.tEquirect.value=e;const o=new tt(s,r),a=e.minFilter;return e.minFilter===Ai&&(e.minFilter=Sn),new lp(1,10,this).update(t,o),e.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(t,e,n,s){const r=t.getRenderTarget();for(let o=0;o<6;o++)t.setRenderTarget(this,o),t.clear(e,n,s);t.setRenderTarget(r)}}const Bo=new I,up=new I,fp=new zt;class yi{constructor(t=new I(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,s){return this.normal.set(t,e,n),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){const s=Bo.subVectors(n,e).cross(up.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){const n=t.delta(Bo),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;const r=-(t.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){const e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){const n=e||fp.getNormalMatrix(t),s=this.coplanarPoint(Bo).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}}const _i=new Ui,Tr=new I;class mc{constructor(t=new yi,e=new yi,n=new yi,s=new yi,r=new yi,o=new yi){this.planes=[t,e,n,s,r,o]}set(t,e,n,s,r,o){const a=this.planes;return a[0].copy(t),a[1].copy(e),a[2].copy(n),a[3].copy(s),a[4].copy(r),a[5].copy(o),this}copy(t){const e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=Vn){const n=this.planes,s=t.elements,r=s[0],o=s[1],a=s[2],c=s[3],l=s[4],h=s[5],u=s[6],f=s[7],m=s[8],g=s[9],_=s[10],p=s[11],d=s[12],y=s[13],b=s[14],w=s[15];if(n[0].setComponents(c-r,f-l,p-m,w-d).normalize(),n[1].setComponents(c+r,f+l,p+m,w+d).normalize(),n[2].setComponents(c+o,f+h,p+g,w+y).normalize(),n[3].setComponents(c-o,f-h,p-g,w-y).normalize(),n[4].setComponents(c-a,f-u,p-_,w-b).normalize(),e===Vn)n[5].setComponents(c+a,f+u,p+_,w+b).normalize();else if(e===Kr)n[5].setComponents(a,u,_,b).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),_i.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),_i.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(_i)}intersectsSprite(t){return _i.center.set(0,0,0),_i.radius=.7071067811865476,_i.applyMatrix4(t.matrixWorld),this.intersectsSphere(_i)}intersectsSphere(t){const e=this.planes,n=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(t){const e=this.planes;for(let n=0;n<6;n++){const s=e[n];if(Tr.x=s.normal.x>0?t.max.x:t.min.x,Tr.y=s.normal.y>0?t.max.y:t.min.y,Tr.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(Tr)<0)return!1}return!0}containsPoint(t){const e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function lu(){let i=null,t=!1,e=null,n=null;function s(r,o){e(r,o),n=i.requestAnimationFrame(s)}return{start:function(){t!==!0&&e!==null&&(n=i.requestAnimationFrame(s),t=!0)},stop:function(){i.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){i=r}}}function dp(i){const t=new WeakMap;function e(a,c){const l=a.array,h=a.usage,u=l.byteLength,f=i.createBuffer();i.bindBuffer(c,f),i.bufferData(c,l,h),a.onUploadCallback();let m;if(l instanceof Float32Array)m=i.FLOAT;else if(l instanceof Uint16Array)a.isFloat16BufferAttribute?m=i.HALF_FLOAT:m=i.UNSIGNED_SHORT;else if(l instanceof Int16Array)m=i.SHORT;else if(l instanceof Uint32Array)m=i.UNSIGNED_INT;else if(l instanceof Int32Array)m=i.INT;else if(l instanceof Int8Array)m=i.BYTE;else if(l instanceof Uint8Array)m=i.UNSIGNED_BYTE;else if(l instanceof Uint8ClampedArray)m=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+l);return{buffer:f,type:m,bytesPerElement:l.BYTES_PER_ELEMENT,version:a.version,size:u}}function n(a,c,l){const h=c.array,u=c.updateRanges;if(i.bindBuffer(l,a),u.length===0)i.bufferSubData(l,0,h);else{u.sort((m,g)=>m.start-g.start);let f=0;for(let m=1;m<u.length;m++){const g=u[f],_=u[m];_.start<=g.start+g.count+1?g.count=Math.max(g.count,_.start+_.count-g.start):(++f,u[f]=_)}u.length=f+1;for(let m=0,g=u.length;m<g;m++){const _=u[m];i.bufferSubData(l,_.start*h.BYTES_PER_ELEMENT,h,_.start,_.count)}c.clearUpdateRanges()}c.onUploadCallback()}function s(a){return a.isInterleavedBufferAttribute&&(a=a.data),t.get(a)}function r(a){a.isInterleavedBufferAttribute&&(a=a.data);const c=t.get(a);c&&(i.deleteBuffer(c.buffer),t.delete(a))}function o(a,c){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){const h=t.get(a);(!h||h.version<a.version)&&t.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}const l=t.get(a);if(l===void 0)t.set(a,e(a,c));else if(l.version<a.version){if(l.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(l.buffer,a,c),l.version=a.version}}return{get:s,remove:r,update:o}}class Ae extends Me{constructor(t=1,e=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:s};const r=t/2,o=e/2,a=Math.floor(n),c=Math.floor(s),l=a+1,h=c+1,u=t/a,f=e/c,m=[],g=[],_=[],p=[];for(let d=0;d<h;d++){const y=d*f-o;for(let b=0;b<l;b++){const w=b*u-r;g.push(w,-y,0),_.push(0,0,1),p.push(b/a),p.push(1-d/c)}}for(let d=0;d<c;d++)for(let y=0;y<a;y++){const b=y+l*d,w=y+l*(d+1),C=y+1+l*(d+1),A=y+1+l*d;m.push(b,w,A),m.push(w,C,A)}this.setIndex(m),this.setAttribute("position",new re(g,3)),this.setAttribute("normal",new re(_,3)),this.setAttribute("uv",new re(p,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Ae(t.width,t.height,t.widthSegments,t.heightSegments)}}var pp=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,mp=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,gp=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,_p=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,xp=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,vp=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Mp=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,yp=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Sp=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,wp=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,bp=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Ep=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Tp=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Ap=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Rp=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Cp=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Pp=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Lp=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Dp=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Ip=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Up=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Np=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Fp=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Op=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,kp=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Bp=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,zp=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Gp=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Hp=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Vp=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Wp="gl_FragColor = linearToOutputTexel( gl_FragColor );",Xp=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,$p=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,qp=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Yp=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,jp=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Kp=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Zp=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Jp=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Qp=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,tm=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,em=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,nm=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,im=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,sm=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,rm=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,om=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,am=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,cm=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,lm=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,hm=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,um=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,fm=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,dm=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,pm=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,mm=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,gm=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,_m=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,xm=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,vm=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Mm=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,ym=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Sm=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,wm=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,bm=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Em=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Tm=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Am=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Rm=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Cm=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Pm=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Lm=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Dm=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Im=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Um=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Nm=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Fm=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Om=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,km=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Bm=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,zm=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Gm=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Hm=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Vm=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Wm=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Xm=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,$m=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,qm=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Ym=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,jm=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,Km=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Zm=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Jm=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Qm=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,t0=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,e0=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,n0=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,i0=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,s0=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,r0=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,o0=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,a0=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,c0=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,l0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,h0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,u0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,f0=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const d0=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,p0=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,m0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,g0=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,_0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,x0=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,v0=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,M0=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,y0=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,S0=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,w0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,b0=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,E0=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,T0=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,A0=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,R0=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,C0=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,P0=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,L0=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,D0=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,I0=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,U0=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,N0=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,F0=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,O0=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,k0=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,B0=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,z0=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,G0=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,H0=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,V0=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,W0=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,X0=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,$0=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ht={alphahash_fragment:pp,alphahash_pars_fragment:mp,alphamap_fragment:gp,alphamap_pars_fragment:_p,alphatest_fragment:xp,alphatest_pars_fragment:vp,aomap_fragment:Mp,aomap_pars_fragment:yp,batching_pars_vertex:Sp,batching_vertex:wp,begin_vertex:bp,beginnormal_vertex:Ep,bsdfs:Tp,iridescence_fragment:Ap,bumpmap_pars_fragment:Rp,clipping_planes_fragment:Cp,clipping_planes_pars_fragment:Pp,clipping_planes_pars_vertex:Lp,clipping_planes_vertex:Dp,color_fragment:Ip,color_pars_fragment:Up,color_pars_vertex:Np,color_vertex:Fp,common:Op,cube_uv_reflection_fragment:kp,defaultnormal_vertex:Bp,displacementmap_pars_vertex:zp,displacementmap_vertex:Gp,emissivemap_fragment:Hp,emissivemap_pars_fragment:Vp,colorspace_fragment:Wp,colorspace_pars_fragment:Xp,envmap_fragment:$p,envmap_common_pars_fragment:qp,envmap_pars_fragment:Yp,envmap_pars_vertex:jp,envmap_physical_pars_fragment:om,envmap_vertex:Kp,fog_vertex:Zp,fog_pars_vertex:Jp,fog_fragment:Qp,fog_pars_fragment:tm,gradientmap_pars_fragment:em,lightmap_pars_fragment:nm,lights_lambert_fragment:im,lights_lambert_pars_fragment:sm,lights_pars_begin:rm,lights_toon_fragment:am,lights_toon_pars_fragment:cm,lights_phong_fragment:lm,lights_phong_pars_fragment:hm,lights_physical_fragment:um,lights_physical_pars_fragment:fm,lights_fragment_begin:dm,lights_fragment_maps:pm,lights_fragment_end:mm,logdepthbuf_fragment:gm,logdepthbuf_pars_fragment:_m,logdepthbuf_pars_vertex:xm,logdepthbuf_vertex:vm,map_fragment:Mm,map_pars_fragment:ym,map_particle_fragment:Sm,map_particle_pars_fragment:wm,metalnessmap_fragment:bm,metalnessmap_pars_fragment:Em,morphinstance_vertex:Tm,morphcolor_vertex:Am,morphnormal_vertex:Rm,morphtarget_pars_vertex:Cm,morphtarget_vertex:Pm,normal_fragment_begin:Lm,normal_fragment_maps:Dm,normal_pars_fragment:Im,normal_pars_vertex:Um,normal_vertex:Nm,normalmap_pars_fragment:Fm,clearcoat_normal_fragment_begin:Om,clearcoat_normal_fragment_maps:km,clearcoat_pars_fragment:Bm,iridescence_pars_fragment:zm,opaque_fragment:Gm,packing:Hm,premultiplied_alpha_fragment:Vm,project_vertex:Wm,dithering_fragment:Xm,dithering_pars_fragment:$m,roughnessmap_fragment:qm,roughnessmap_pars_fragment:Ym,shadowmap_pars_fragment:jm,shadowmap_pars_vertex:Km,shadowmap_vertex:Zm,shadowmask_pars_fragment:Jm,skinbase_vertex:Qm,skinning_pars_vertex:t0,skinning_vertex:e0,skinnormal_vertex:n0,specularmap_fragment:i0,specularmap_pars_fragment:s0,tonemapping_fragment:r0,tonemapping_pars_fragment:o0,transmission_fragment:a0,transmission_pars_fragment:c0,uv_pars_fragment:l0,uv_pars_vertex:h0,uv_vertex:u0,worldpos_vertex:f0,background_vert:d0,background_frag:p0,backgroundCube_vert:m0,backgroundCube_frag:g0,cube_vert:_0,cube_frag:x0,depth_vert:v0,depth_frag:M0,distanceRGBA_vert:y0,distanceRGBA_frag:S0,equirect_vert:w0,equirect_frag:b0,linedashed_vert:E0,linedashed_frag:T0,meshbasic_vert:A0,meshbasic_frag:R0,meshlambert_vert:C0,meshlambert_frag:P0,meshmatcap_vert:L0,meshmatcap_frag:D0,meshnormal_vert:I0,meshnormal_frag:U0,meshphong_vert:N0,meshphong_frag:F0,meshphysical_vert:O0,meshphysical_frag:k0,meshtoon_vert:B0,meshtoon_frag:z0,points_vert:G0,points_frag:H0,shadow_vert:V0,shadow_frag:W0,sprite_vert:X0,sprite_frag:$0},lt={common:{diffuse:{value:new _t(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new zt},alphaMap:{value:null},alphaMapTransform:{value:new zt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new zt}},envmap:{envMap:{value:null},envMapRotation:{value:new zt},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new zt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new zt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new zt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new zt},normalScale:{value:new Ft(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new zt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new zt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new zt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new zt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new _t(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new _t(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new zt},alphaTest:{value:0},uvTransform:{value:new zt}},sprite:{diffuse:{value:new _t(16777215)},opacity:{value:1},center:{value:new Ft(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new zt},alphaMap:{value:null},alphaMapTransform:{value:new zt},alphaTest:{value:0}}},An={basic:{uniforms:qe([lt.common,lt.specularmap,lt.envmap,lt.aomap,lt.lightmap,lt.fog]),vertexShader:Ht.meshbasic_vert,fragmentShader:Ht.meshbasic_frag},lambert:{uniforms:qe([lt.common,lt.specularmap,lt.envmap,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.fog,lt.lights,{emissive:{value:new _t(0)}}]),vertexShader:Ht.meshlambert_vert,fragmentShader:Ht.meshlambert_frag},phong:{uniforms:qe([lt.common,lt.specularmap,lt.envmap,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.fog,lt.lights,{emissive:{value:new _t(0)},specular:{value:new _t(1118481)},shininess:{value:30}}]),vertexShader:Ht.meshphong_vert,fragmentShader:Ht.meshphong_frag},standard:{uniforms:qe([lt.common,lt.envmap,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.roughnessmap,lt.metalnessmap,lt.fog,lt.lights,{emissive:{value:new _t(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ht.meshphysical_vert,fragmentShader:Ht.meshphysical_frag},toon:{uniforms:qe([lt.common,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.gradientmap,lt.fog,lt.lights,{emissive:{value:new _t(0)}}]),vertexShader:Ht.meshtoon_vert,fragmentShader:Ht.meshtoon_frag},matcap:{uniforms:qe([lt.common,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.fog,{matcap:{value:null}}]),vertexShader:Ht.meshmatcap_vert,fragmentShader:Ht.meshmatcap_frag},points:{uniforms:qe([lt.points,lt.fog]),vertexShader:Ht.points_vert,fragmentShader:Ht.points_frag},dashed:{uniforms:qe([lt.common,lt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ht.linedashed_vert,fragmentShader:Ht.linedashed_frag},depth:{uniforms:qe([lt.common,lt.displacementmap]),vertexShader:Ht.depth_vert,fragmentShader:Ht.depth_frag},normal:{uniforms:qe([lt.common,lt.bumpmap,lt.normalmap,lt.displacementmap,{opacity:{value:1}}]),vertexShader:Ht.meshnormal_vert,fragmentShader:Ht.meshnormal_frag},sprite:{uniforms:qe([lt.sprite,lt.fog]),vertexShader:Ht.sprite_vert,fragmentShader:Ht.sprite_frag},background:{uniforms:{uvTransform:{value:new zt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ht.background_vert,fragmentShader:Ht.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new zt}},vertexShader:Ht.backgroundCube_vert,fragmentShader:Ht.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ht.cube_vert,fragmentShader:Ht.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ht.equirect_vert,fragmentShader:Ht.equirect_frag},distanceRGBA:{uniforms:qe([lt.common,lt.displacementmap,{referencePosition:{value:new I},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ht.distanceRGBA_vert,fragmentShader:Ht.distanceRGBA_frag},shadow:{uniforms:qe([lt.lights,lt.fog,{color:{value:new _t(0)},opacity:{value:1}}]),vertexShader:Ht.shadow_vert,fragmentShader:Ht.shadow_frag}};An.physical={uniforms:qe([An.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new zt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new zt},clearcoatNormalScale:{value:new Ft(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new zt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new zt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new zt},sheen:{value:0},sheenColor:{value:new _t(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new zt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new zt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new zt},transmissionSamplerSize:{value:new Ft},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new zt},attenuationDistance:{value:0},attenuationColor:{value:new _t(0)},specularColor:{value:new _t(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new zt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new zt},anisotropyVector:{value:new Ft},anisotropyMap:{value:null},anisotropyMapTransform:{value:new zt}}]),vertexShader:Ht.meshphysical_vert,fragmentShader:Ht.meshphysical_frag};const Ar={r:0,b:0,g:0},xi=new Dn,q0=new Wt;function Y0(i,t,e,n,s,r,o){const a=new _t(0);let c=r===!0?0:1,l,h,u=null,f=0,m=null;function g(y){let b=y.isScene===!0?y.background:null;return b&&b.isTexture&&(b=(y.backgroundBlurriness>0?e:t).get(b)),b}function _(y){let b=!1;const w=g(y);w===null?d(a,c):w&&w.isColor&&(d(w,1),b=!0);const C=i.xr.getEnvironmentBlendMode();C==="additive"?n.buffers.color.setClear(0,0,0,1,o):C==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(i.autoClear||b)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function p(y,b){const w=g(b);w&&(w.isCubeTexture||w.mapping===ro)?(h===void 0&&(h=new tt(new Nt(1,1,1),new hi({name:"BackgroundCubeMaterial",uniforms:xs(An.backgroundCube.uniforms),vertexShader:An.backgroundCube.vertexShader,fragmentShader:An.backgroundCube.fragmentShader,side:Qe,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(C,A,S){this.matrixWorld.copyPosition(S.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),xi.copy(b.backgroundRotation),xi.x*=-1,xi.y*=-1,xi.z*=-1,w.isCubeTexture&&w.isRenderTargetTexture===!1&&(xi.y*=-1,xi.z*=-1),h.material.uniforms.envMap.value=w,h.material.uniforms.flipEnvMap.value=w.isCubeTexture&&w.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=b.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=b.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(q0.makeRotationFromEuler(xi)),h.material.toneMapped=Kt.getTransfer(w.colorSpace)!==ae,(u!==w||f!==w.version||m!==i.toneMapping)&&(h.material.needsUpdate=!0,u=w,f=w.version,m=i.toneMapping),h.layers.enableAll(),y.unshift(h,h.geometry,h.material,0,0,null)):w&&w.isTexture&&(l===void 0&&(l=new tt(new Ae(2,2),new hi({name:"BackgroundMaterial",uniforms:xs(An.background.uniforms),vertexShader:An.background.vertexShader,fragmentShader:An.background.fragmentShader,side:li,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(l)),l.material.uniforms.t2D.value=w,l.material.uniforms.backgroundIntensity.value=b.backgroundIntensity,l.material.toneMapped=Kt.getTransfer(w.colorSpace)!==ae,w.matrixAutoUpdate===!0&&w.updateMatrix(),l.material.uniforms.uvTransform.value.copy(w.matrix),(u!==w||f!==w.version||m!==i.toneMapping)&&(l.material.needsUpdate=!0,u=w,f=w.version,m=i.toneMapping),l.layers.enableAll(),y.unshift(l,l.geometry,l.material,0,0,null))}function d(y,b){y.getRGB(Ar,ou(i)),n.buffers.color.setClear(Ar.r,Ar.g,Ar.b,b,o)}return{getClearColor:function(){return a},setClearColor:function(y,b=1){a.set(y),c=b,d(a,c)},getClearAlpha:function(){return c},setClearAlpha:function(y){c=y,d(a,c)},render:_,addToRenderList:p}}function j0(i,t){const e=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=f(null);let r=s,o=!1;function a(v,E,P,L,N){let F=!1;const U=u(L,P,E);r!==U&&(r=U,l(r.object)),F=m(v,L,P,N),F&&g(v,L,P,N),N!==null&&t.update(N,i.ELEMENT_ARRAY_BUFFER),(F||o)&&(o=!1,w(v,E,P,L),N!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,t.get(N).buffer))}function c(){return i.createVertexArray()}function l(v){return i.bindVertexArray(v)}function h(v){return i.deleteVertexArray(v)}function u(v,E,P){const L=P.wireframe===!0;let N=n[v.id];N===void 0&&(N={},n[v.id]=N);let F=N[E.id];F===void 0&&(F={},N[E.id]=F);let U=F[L];return U===void 0&&(U=f(c()),F[L]=U),U}function f(v){const E=[],P=[],L=[];for(let N=0;N<e;N++)E[N]=0,P[N]=0,L[N]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:E,enabledAttributes:P,attributeDivisors:L,object:v,attributes:{},index:null}}function m(v,E,P,L){const N=r.attributes,F=E.attributes;let U=0;const O=P.getAttributes();for(const k in O)if(O[k].location>=0){const Y=N[k];let it=F[k];if(it===void 0&&(k==="instanceMatrix"&&v.instanceMatrix&&(it=v.instanceMatrix),k==="instanceColor"&&v.instanceColor&&(it=v.instanceColor)),Y===void 0||Y.attribute!==it||it&&Y.data!==it.data)return!0;U++}return r.attributesNum!==U||r.index!==L}function g(v,E,P,L){const N={},F=E.attributes;let U=0;const O=P.getAttributes();for(const k in O)if(O[k].location>=0){let Y=F[k];Y===void 0&&(k==="instanceMatrix"&&v.instanceMatrix&&(Y=v.instanceMatrix),k==="instanceColor"&&v.instanceColor&&(Y=v.instanceColor));const it={};it.attribute=Y,Y&&Y.data&&(it.data=Y.data),N[k]=it,U++}r.attributes=N,r.attributesNum=U,r.index=L}function _(){const v=r.newAttributes;for(let E=0,P=v.length;E<P;E++)v[E]=0}function p(v){d(v,0)}function d(v,E){const P=r.newAttributes,L=r.enabledAttributes,N=r.attributeDivisors;P[v]=1,L[v]===0&&(i.enableVertexAttribArray(v),L[v]=1),N[v]!==E&&(i.vertexAttribDivisor(v,E),N[v]=E)}function y(){const v=r.newAttributes,E=r.enabledAttributes;for(let P=0,L=E.length;P<L;P++)E[P]!==v[P]&&(i.disableVertexAttribArray(P),E[P]=0)}function b(v,E,P,L,N,F,U){U===!0?i.vertexAttribIPointer(v,E,P,N,F):i.vertexAttribPointer(v,E,P,L,N,F)}function w(v,E,P,L){_();const N=L.attributes,F=P.getAttributes(),U=E.defaultAttributeValues;for(const O in F){const k=F[O];if(k.location>=0){let K=N[O];if(K===void 0&&(O==="instanceMatrix"&&v.instanceMatrix&&(K=v.instanceMatrix),O==="instanceColor"&&v.instanceColor&&(K=v.instanceColor)),K!==void 0){const Y=K.normalized,it=K.itemSize,ct=t.get(K);if(ct===void 0)continue;const xt=ct.buffer,$=ct.type,et=ct.bytesPerElement,ut=$===i.INT||$===i.UNSIGNED_INT||K.gpuType===oc;if(K.isInterleavedBufferAttribute){const at=K.data,Ct=at.stride,Ot=K.offset;if(at.isInstancedInterleavedBuffer){for(let Vt=0;Vt<k.locationSize;Vt++)d(k.location+Vt,at.meshPerAttribute);v.isInstancedMesh!==!0&&L._maxInstanceCount===void 0&&(L._maxInstanceCount=at.meshPerAttribute*at.count)}else for(let Vt=0;Vt<k.locationSize;Vt++)p(k.location+Vt);i.bindBuffer(i.ARRAY_BUFFER,xt);for(let Vt=0;Vt<k.locationSize;Vt++)b(k.location+Vt,it/k.locationSize,$,Y,Ct*et,(Ot+it/k.locationSize*Vt)*et,ut)}else{if(K.isInstancedBufferAttribute){for(let at=0;at<k.locationSize;at++)d(k.location+at,K.meshPerAttribute);v.isInstancedMesh!==!0&&L._maxInstanceCount===void 0&&(L._maxInstanceCount=K.meshPerAttribute*K.count)}else for(let at=0;at<k.locationSize;at++)p(k.location+at);i.bindBuffer(i.ARRAY_BUFFER,xt);for(let at=0;at<k.locationSize;at++)b(k.location+at,it/k.locationSize,$,Y,it*et,it/k.locationSize*at*et,ut)}}else if(U!==void 0){const Y=U[O];if(Y!==void 0)switch(Y.length){case 2:i.vertexAttrib2fv(k.location,Y);break;case 3:i.vertexAttrib3fv(k.location,Y);break;case 4:i.vertexAttrib4fv(k.location,Y);break;default:i.vertexAttrib1fv(k.location,Y)}}}}y()}function C(){M();for(const v in n){const E=n[v];for(const P in E){const L=E[P];for(const N in L)h(L[N].object),delete L[N];delete E[P]}delete n[v]}}function A(v){if(n[v.id]===void 0)return;const E=n[v.id];for(const P in E){const L=E[P];for(const N in L)h(L[N].object),delete L[N];delete E[P]}delete n[v.id]}function S(v){for(const E in n){const P=n[E];if(P[v.id]===void 0)continue;const L=P[v.id];for(const N in L)h(L[N].object),delete L[N];delete P[v.id]}}function M(){x(),o=!0,r!==s&&(r=s,l(r.object))}function x(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:a,reset:M,resetDefaultState:x,dispose:C,releaseStatesOfGeometry:A,releaseStatesOfProgram:S,initAttributes:_,enableAttribute:p,disableUnusedAttributes:y}}function K0(i,t,e){let n;function s(l){n=l}function r(l,h){i.drawArrays(n,l,h),e.update(h,n,1)}function o(l,h,u){u!==0&&(i.drawArraysInstanced(n,l,h,u),e.update(h,n,u))}function a(l,h,u){if(u===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,h,0,u);let m=0;for(let g=0;g<u;g++)m+=h[g];e.update(m,n,1)}function c(l,h,u,f){if(u===0)return;const m=t.get("WEBGL_multi_draw");if(m===null)for(let g=0;g<l.length;g++)o(l[g],h[g],f[g]);else{m.multiDrawArraysInstancedWEBGL(n,l,0,h,0,f,0,u);let g=0;for(let _=0;_<u;_++)g+=h[_]*f[_];e.update(g,n,1)}}this.setMode=s,this.render=r,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=c}function Z0(i,t,e,n){let s;function r(){if(s!==void 0)return s;if(t.has("EXT_texture_filter_anisotropic")===!0){const S=t.get("EXT_texture_filter_anisotropic");s=i.getParameter(S.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function o(S){return!(S!==wn&&n.convert(S)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(S){const M=S===nr&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(S!==$n&&n.convert(S)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&S!==Cn&&!M)}function c(S){if(S==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";S="mediump"}return S==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let l=e.precision!==void 0?e.precision:"highp";const h=c(l);h!==l&&(console.warn("THREE.WebGLRenderer:",l,"not supported, using",h,"instead."),l=h);const u=e.logarithmicDepthBuffer===!0,f=e.reverseDepthBuffer===!0&&t.has("EXT_clip_control"),m=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),_=i.getParameter(i.MAX_TEXTURE_SIZE),p=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),d=i.getParameter(i.MAX_VERTEX_ATTRIBS),y=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),b=i.getParameter(i.MAX_VARYING_VECTORS),w=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),C=g>0,A=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:c,textureFormatReadable:o,textureTypeReadable:a,precision:l,logarithmicDepthBuffer:u,reverseDepthBuffer:f,maxTextures:m,maxVertexTextures:g,maxTextureSize:_,maxCubemapSize:p,maxAttributes:d,maxVertexUniforms:y,maxVaryings:b,maxFragmentUniforms:w,vertexTextures:C,maxSamples:A}}function J0(i){const t=this;let e=null,n=0,s=!1,r=!1;const o=new yi,a=new zt,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(u,f){const m=u.length!==0||f||n!==0||s;return s=f,n=u.length,m},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,f){e=h(u,f,0)},this.setState=function(u,f,m){const g=u.clippingPlanes,_=u.clipIntersection,p=u.clipShadows,d=i.get(u);if(!s||g===null||g.length===0||r&&!p)r?h(null):l();else{const y=r?0:n,b=y*4;let w=d.clippingState||null;c.value=w,w=h(g,f,b,m);for(let C=0;C!==b;++C)w[C]=e[C];d.clippingState=w,this.numIntersection=_?this.numPlanes:0,this.numPlanes+=y}};function l(){c.value!==e&&(c.value=e,c.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(u,f,m,g){const _=u!==null?u.length:0;let p=null;if(_!==0){if(p=c.value,g!==!0||p===null){const d=m+_*4,y=f.matrixWorldInverse;a.getNormalMatrix(y),(p===null||p.length<d)&&(p=new Float32Array(d));for(let b=0,w=m;b!==_;++b,w+=4)o.copy(u[b]).applyMatrix4(y,a),o.normal.toArray(p,w),p[w+3]=o.constant}c.value=p,c.needsUpdate=!0}return t.numPlanes=_,t.numIntersection=0,p}}function Q0(i){let t=new WeakMap;function e(o,a){return a===_a?o.mapping=fs:a===xa&&(o.mapping=ds),o}function n(o){if(o&&o.isTexture){const a=o.mapping;if(a===_a||a===xa)if(t.has(o)){const c=t.get(o).texture;return e(c,o.mapping)}else{const c=o.image;if(c&&c.height>0){const l=new hp(c.height);return l.fromEquirectangularTexture(i,o),t.set(o,l),o.addEventListener("dispose",s),e(l.texture,o.mapping)}else return null}}return o}function s(o){const a=o.target;a.removeEventListener("dispose",s);const c=t.get(a);c!==void 0&&(t.delete(a),c.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}class hu extends au{constructor(t=-1,e=1,n=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let r=n-t,o=n+t,a=s+e,c=s-e;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=l*this.view.offsetX,o=r+l*this.view.width,a-=h*this.view.offsetY,c=a-h*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,c,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}}const rs=4,yl=[.125,.215,.35,.446,.526,.582],bi=20,zo=new hu,Sl=new _t;let Go=null,Ho=0,Vo=0,Wo=!1;const Si=(1+Math.sqrt(5))/2,Ki=1/Si,wl=[new I(-Si,Ki,0),new I(Si,Ki,0),new I(-Ki,0,Si),new I(Ki,0,Si),new I(0,Si,-Ki),new I(0,Si,Ki),new I(-1,1,-1),new I(1,1,-1),new I(-1,1,1),new I(1,1,1)];class bl{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,s=100){Go=this._renderer.getRenderTarget(),Ho=this._renderer.getActiveCubeFace(),Vo=this._renderer.getActiveMipmapLevel(),Wo=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);const r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,n,s,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Al(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Tl(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(Go,Ho,Vo),this._renderer.xr.enabled=Wo,t.scissorTest=!1,Rr(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===fs||t.mapping===ds?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Go=this._renderer.getRenderTarget(),Ho=this._renderer.getActiveCubeFace(),Vo=this._renderer.getActiveMipmapLevel(),Wo=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:Sn,minFilter:Sn,generateMipmaps:!1,type:nr,format:wn,colorSpace:Ss,depthBuffer:!1},s=El(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=El(t,e,n);const{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=tg(r)),this._blurMaterial=eg(r,t,e)}return s}_compileMaterial(t){const e=new tt(this._lodPlanes[0],t);this._renderer.compile(e,zo)}_sceneToCubeUV(t,e,n,s){const a=new je(90,1,e,n),c=[1,-1,1,1,1,1],l=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,f=h.toneMapping;h.getClearColor(Sl),h.toneMapping=ci,h.autoClear=!1;const m=new cn({name:"PMREM.Background",side:Qe,depthWrite:!1,depthTest:!1}),g=new tt(new Nt,m);let _=!1;const p=t.background;p?p.isColor&&(m.color.copy(p),t.background=null,_=!0):(m.color.copy(Sl),_=!0);for(let d=0;d<6;d++){const y=d%3;y===0?(a.up.set(0,c[d],0),a.lookAt(l[d],0,0)):y===1?(a.up.set(0,0,c[d]),a.lookAt(0,l[d],0)):(a.up.set(0,c[d],0),a.lookAt(0,0,l[d]));const b=this._cubeSize;Rr(s,y*b,d>2?b:0,b,b),h.setRenderTarget(s),_&&h.render(g,a),h.render(t,a)}g.geometry.dispose(),g.material.dispose(),h.toneMapping=f,h.autoClear=u,t.background=p}_textureToCubeUV(t,e){const n=this._renderer,s=t.mapping===fs||t.mapping===ds;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=Al()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Tl());const r=s?this._cubemapMaterial:this._equirectMaterial,o=new tt(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=t;const c=this._cubeSize;Rr(e,0,0,3*c,2*c),n.setRenderTarget(e),n.render(o,zo)}_applyPMREM(t){const e=this._renderer,n=e.autoClear;e.autoClear=!1;const s=this._lodPlanes.length;for(let r=1;r<s;r++){const o=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),a=wl[(s-r-1)%wl.length];this._blur(t,r-1,r,o,a)}e.autoClear=n}_blur(t,e,n,s,r){const o=this._pingPongRenderTarget;this._halfBlur(t,o,e,n,s,"latitudinal",r),this._halfBlur(o,t,n,n,s,"longitudinal",r)}_halfBlur(t,e,n,s,r,o,a){const c=this._renderer,l=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const h=3,u=new tt(this._lodPlanes[s],l),f=l.uniforms,m=this._sizeLods[n]-1,g=isFinite(r)?Math.PI/(2*m):2*Math.PI/(2*bi-1),_=r/g,p=isFinite(r)?1+Math.floor(h*_):bi;p>bi&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${p} samples when the maximum is set to ${bi}`);const d=[];let y=0;for(let S=0;S<bi;++S){const M=S/_,x=Math.exp(-M*M/2);d.push(x),S===0?y+=x:S<p&&(y+=2*x)}for(let S=0;S<d.length;S++)d[S]=d[S]/y;f.envMap.value=t.texture,f.samples.value=p,f.weights.value=d,f.latitudinal.value=o==="latitudinal",a&&(f.poleAxis.value=a);const{_lodMax:b}=this;f.dTheta.value=g,f.mipInt.value=b-n;const w=this._sizeLods[s],C=3*w*(s>b-rs?s-b+rs:0),A=4*(this._cubeSize-w);Rr(e,C,A,3*w,2*w),c.setRenderTarget(e),c.render(u,zo)}}function tg(i){const t=[],e=[],n=[];let s=i;const r=i-rs+1+yl.length;for(let o=0;o<r;o++){const a=Math.pow(2,s);e.push(a);let c=1/a;o>i-rs?c=yl[o-i+rs-1]:o===0&&(c=0),n.push(c);const l=1/(a-2),h=-l,u=1+l,f=[h,h,u,h,u,u,h,h,u,u,h,u],m=6,g=6,_=3,p=2,d=1,y=new Float32Array(_*g*m),b=new Float32Array(p*g*m),w=new Float32Array(d*g*m);for(let A=0;A<m;A++){const S=A%3*2/3-1,M=A>2?0:-1,x=[S,M,0,S+2/3,M,0,S+2/3,M+1,0,S,M,0,S+2/3,M+1,0,S,M+1,0];y.set(x,_*g*A),b.set(f,p*g*A);const v=[A,A,A,A,A,A];w.set(v,d*g*A)}const C=new Me;C.setAttribute("position",new ve(y,_)),C.setAttribute("uv",new ve(b,p)),C.setAttribute("faceIndex",new ve(w,d)),t.push(C),s>rs&&s--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function El(i,t,e){const n=new Li(i,t,e);return n.texture.mapping=ro,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Rr(i,t,e,n,s){i.viewport.set(t,e,n,s),i.scissor.set(t,e,n,s)}function eg(i,t,e){const n=new Float32Array(bi),s=new I(0,1,0);return new hi({name:"SphericalGaussianBlur",defines:{n:bi,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:gc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:ai,depthTest:!1,depthWrite:!1})}function Tl(){return new hi({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:gc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:ai,depthTest:!1,depthWrite:!1})}function Al(){return new hi({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:gc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:ai,depthTest:!1,depthWrite:!1})}function gc(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function ng(i){let t=new WeakMap,e=null;function n(a){if(a&&a.isTexture){const c=a.mapping,l=c===_a||c===xa,h=c===fs||c===ds;if(l||h){let u=t.get(a);const f=u!==void 0?u.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==f)return e===null&&(e=new bl(i)),u=l?e.fromEquirectangular(a,u):e.fromCubemap(a,u),u.texture.pmremVersion=a.pmremVersion,t.set(a,u),u.texture;if(u!==void 0)return u.texture;{const m=a.image;return l&&m&&m.height>0||h&&m&&s(m)?(e===null&&(e=new bl(i)),u=l?e.fromEquirectangular(a):e.fromCubemap(a),u.texture.pmremVersion=a.pmremVersion,t.set(a,u),a.addEventListener("dispose",r),u.texture):null}}}return a}function s(a){let c=0;const l=6;for(let h=0;h<l;h++)a[h]!==void 0&&c++;return c===l}function r(a){const c=a.target;c.removeEventListener("dispose",r);const l=t.get(c);l!==void 0&&(t.delete(c),l.dispose())}function o(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:o}}function ig(i){const t={};function e(n){if(t[n]!==void 0)return t[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return t[n]=s,s}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){const s=e(n);return s===null&&Gs("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function sg(i,t,e,n){const s={},r=new WeakMap;function o(u){const f=u.target;f.index!==null&&t.remove(f.index);for(const g in f.attributes)t.remove(f.attributes[g]);for(const g in f.morphAttributes){const _=f.morphAttributes[g];for(let p=0,d=_.length;p<d;p++)t.remove(_[p])}f.removeEventListener("dispose",o),delete s[f.id];const m=r.get(f);m&&(t.remove(m),r.delete(f)),n.releaseStatesOfGeometry(f),f.isInstancedBufferGeometry===!0&&delete f._maxInstanceCount,e.memory.geometries--}function a(u,f){return s[f.id]===!0||(f.addEventListener("dispose",o),s[f.id]=!0,e.memory.geometries++),f}function c(u){const f=u.attributes;for(const g in f)t.update(f[g],i.ARRAY_BUFFER);const m=u.morphAttributes;for(const g in m){const _=m[g];for(let p=0,d=_.length;p<d;p++)t.update(_[p],i.ARRAY_BUFFER)}}function l(u){const f=[],m=u.index,g=u.attributes.position;let _=0;if(m!==null){const y=m.array;_=m.version;for(let b=0,w=y.length;b<w;b+=3){const C=y[b+0],A=y[b+1],S=y[b+2];f.push(C,A,A,S,S,C)}}else if(g!==void 0){const y=g.array;_=g.version;for(let b=0,w=y.length/3-1;b<w;b+=3){const C=b+0,A=b+1,S=b+2;f.push(C,A,A,S,S,C)}}else return;const p=new(Qh(f)?ru:su)(f,1);p.version=_;const d=r.get(u);d&&t.remove(d),r.set(u,p)}function h(u){const f=r.get(u);if(f){const m=u.index;m!==null&&f.version<m.version&&l(u)}else l(u);return r.get(u)}return{get:a,update:c,getWireframeAttribute:h}}function rg(i,t,e){let n;function s(f){n=f}let r,o;function a(f){r=f.type,o=f.bytesPerElement}function c(f,m){i.drawElements(n,m,r,f*o),e.update(m,n,1)}function l(f,m,g){g!==0&&(i.drawElementsInstanced(n,m,r,f*o,g),e.update(m,n,g))}function h(f,m,g){if(g===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,m,0,r,f,0,g);let p=0;for(let d=0;d<g;d++)p+=m[d];e.update(p,n,1)}function u(f,m,g,_){if(g===0)return;const p=t.get("WEBGL_multi_draw");if(p===null)for(let d=0;d<f.length;d++)l(f[d]/o,m[d],_[d]);else{p.multiDrawElementsInstancedWEBGL(n,m,0,r,f,0,_,0,g);let d=0;for(let y=0;y<g;y++)d+=m[y]*_[y];e.update(d,n,1)}}this.setMode=s,this.setIndex=a,this.render=c,this.renderInstances=l,this.renderMultiDraw=h,this.renderMultiDrawInstances=u}function og(i){const t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(e.calls++,o){case i.TRIANGLES:e.triangles+=a*(r/3);break;case i.LINES:e.lines+=a*(r/2);break;case i.LINE_STRIP:e.lines+=a*(r-1);break;case i.LINE_LOOP:e.lines+=a*r;break;case i.POINTS:e.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:n}}function ag(i,t,e){const n=new WeakMap,s=new Se;function r(o,a,c){const l=o.morphTargetInfluences,h=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,u=h!==void 0?h.length:0;let f=n.get(a);if(f===void 0||f.count!==u){let x=function(){S.dispose(),n.delete(a),a.removeEventListener("dispose",x)};f!==void 0&&f.texture.dispose();const m=a.morphAttributes.position!==void 0,g=a.morphAttributes.normal!==void 0,_=a.morphAttributes.color!==void 0,p=a.morphAttributes.position||[],d=a.morphAttributes.normal||[],y=a.morphAttributes.color||[];let b=0;m===!0&&(b=1),g===!0&&(b=2),_===!0&&(b=3);let w=a.attributes.position.count*b,C=1;w>t.maxTextureSize&&(C=Math.ceil(w/t.maxTextureSize),w=t.maxTextureSize);const A=new Float32Array(w*C*4*u),S=new eu(A,w,C,u);S.type=Cn,S.needsUpdate=!0;const M=b*4;for(let v=0;v<u;v++){const E=p[v],P=d[v],L=y[v],N=w*C*4*v;for(let F=0;F<E.count;F++){const U=F*M;m===!0&&(s.fromBufferAttribute(E,F),A[N+U+0]=s.x,A[N+U+1]=s.y,A[N+U+2]=s.z,A[N+U+3]=0),g===!0&&(s.fromBufferAttribute(P,F),A[N+U+4]=s.x,A[N+U+5]=s.y,A[N+U+6]=s.z,A[N+U+7]=0),_===!0&&(s.fromBufferAttribute(L,F),A[N+U+8]=s.x,A[N+U+9]=s.y,A[N+U+10]=s.z,A[N+U+11]=L.itemSize===4?s.w:1)}}f={count:u,texture:S,size:new Ft(w,C)},n.set(a,f),a.addEventListener("dispose",x)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)c.getUniforms().setValue(i,"morphTexture",o.morphTexture,e);else{let m=0;for(let _=0;_<l.length;_++)m+=l[_];const g=a.morphTargetsRelative?1:1-m;c.getUniforms().setValue(i,"morphTargetBaseInfluence",g),c.getUniforms().setValue(i,"morphTargetInfluences",l)}c.getUniforms().setValue(i,"morphTargetsTexture",f.texture,e),c.getUniforms().setValue(i,"morphTargetsTextureSize",f.size)}return{update:r}}function cg(i,t,e,n){let s=new WeakMap;function r(c){const l=n.render.frame,h=c.geometry,u=t.get(c,h);if(s.get(u)!==l&&(t.update(u),s.set(u,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",a)===!1&&c.addEventListener("dispose",a),s.get(c)!==l&&(e.update(c.instanceMatrix,i.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,i.ARRAY_BUFFER),s.set(c,l))),c.isSkinnedMesh){const f=c.skeleton;s.get(f)!==l&&(f.update(),s.set(f,l))}return u}function o(){s=new WeakMap}function a(c){const l=c.target;l.removeEventListener("dispose",a),e.remove(l.instanceMatrix),l.instanceColor!==null&&e.remove(l.instanceColor)}return{update:r,dispose:o}}class uu extends Xe{constructor(t,e,n,s,r,o,a,c,l,h=cs){if(h!==cs&&h!==gs)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===cs&&(n=Pi),n===void 0&&h===gs&&(n=ms),super(null,s,r,o,a,c,h,n,l),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=a!==void 0?a:tn,this.minFilter=c!==void 0?c:tn,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){const e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}}const fu=new Xe,Rl=new uu(1,1),du=new eu,pu=new Yd,mu=new cu,Cl=[],Pl=[],Ll=new Float32Array(16),Dl=new Float32Array(9),Il=new Float32Array(4);function bs(i,t,e){const n=i[0];if(n<=0||n>0)return i;const s=t*e;let r=Cl[s];if(r===void 0&&(r=new Float32Array(s),Cl[s]=r),t!==0){n.toArray(r,0);for(let o=1,a=0;o!==t;++o)a+=e,i[o].toArray(r,a)}return r}function Pe(i,t){if(i.length!==t.length)return!1;for(let e=0,n=i.length;e<n;e++)if(i[e]!==t[e])return!1;return!0}function Le(i,t){for(let e=0,n=t.length;e<n;e++)i[e]=t[e]}function ao(i,t){let e=Pl[t];e===void 0&&(e=new Int32Array(t),Pl[t]=e);for(let n=0;n!==t;++n)e[n]=i.allocateTextureUnit();return e}function lg(i,t){const e=this.cache;e[0]!==t&&(i.uniform1f(this.addr,t),e[0]=t)}function hg(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Pe(e,t))return;i.uniform2fv(this.addr,t),Le(e,t)}}function ug(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(i.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Pe(e,t))return;i.uniform3fv(this.addr,t),Le(e,t)}}function fg(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Pe(e,t))return;i.uniform4fv(this.addr,t),Le(e,t)}}function dg(i,t){const e=this.cache,n=t.elements;if(n===void 0){if(Pe(e,t))return;i.uniformMatrix2fv(this.addr,!1,t),Le(e,t)}else{if(Pe(e,n))return;Il.set(n),i.uniformMatrix2fv(this.addr,!1,Il),Le(e,n)}}function pg(i,t){const e=this.cache,n=t.elements;if(n===void 0){if(Pe(e,t))return;i.uniformMatrix3fv(this.addr,!1,t),Le(e,t)}else{if(Pe(e,n))return;Dl.set(n),i.uniformMatrix3fv(this.addr,!1,Dl),Le(e,n)}}function mg(i,t){const e=this.cache,n=t.elements;if(n===void 0){if(Pe(e,t))return;i.uniformMatrix4fv(this.addr,!1,t),Le(e,t)}else{if(Pe(e,n))return;Ll.set(n),i.uniformMatrix4fv(this.addr,!1,Ll),Le(e,n)}}function gg(i,t){const e=this.cache;e[0]!==t&&(i.uniform1i(this.addr,t),e[0]=t)}function _g(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Pe(e,t))return;i.uniform2iv(this.addr,t),Le(e,t)}}function xg(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Pe(e,t))return;i.uniform3iv(this.addr,t),Le(e,t)}}function vg(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Pe(e,t))return;i.uniform4iv(this.addr,t),Le(e,t)}}function Mg(i,t){const e=this.cache;e[0]!==t&&(i.uniform1ui(this.addr,t),e[0]=t)}function yg(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Pe(e,t))return;i.uniform2uiv(this.addr,t),Le(e,t)}}function Sg(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Pe(e,t))return;i.uniform3uiv(this.addr,t),Le(e,t)}}function wg(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Pe(e,t))return;i.uniform4uiv(this.addr,t),Le(e,t)}}function bg(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?(Rl.compareFunction=Zh,r=Rl):r=fu,e.setTexture2D(t||r,s)}function Eg(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture3D(t||pu,s)}function Tg(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTextureCube(t||mu,s)}function Ag(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture2DArray(t||du,s)}function Rg(i){switch(i){case 5126:return lg;case 35664:return hg;case 35665:return ug;case 35666:return fg;case 35674:return dg;case 35675:return pg;case 35676:return mg;case 5124:case 35670:return gg;case 35667:case 35671:return _g;case 35668:case 35672:return xg;case 35669:case 35673:return vg;case 5125:return Mg;case 36294:return yg;case 36295:return Sg;case 36296:return wg;case 35678:case 36198:case 36298:case 36306:case 35682:return bg;case 35679:case 36299:case 36307:return Eg;case 35680:case 36300:case 36308:case 36293:return Tg;case 36289:case 36303:case 36311:case 36292:return Ag}}function Cg(i,t){i.uniform1fv(this.addr,t)}function Pg(i,t){const e=bs(t,this.size,2);i.uniform2fv(this.addr,e)}function Lg(i,t){const e=bs(t,this.size,3);i.uniform3fv(this.addr,e)}function Dg(i,t){const e=bs(t,this.size,4);i.uniform4fv(this.addr,e)}function Ig(i,t){const e=bs(t,this.size,4);i.uniformMatrix2fv(this.addr,!1,e)}function Ug(i,t){const e=bs(t,this.size,9);i.uniformMatrix3fv(this.addr,!1,e)}function Ng(i,t){const e=bs(t,this.size,16);i.uniformMatrix4fv(this.addr,!1,e)}function Fg(i,t){i.uniform1iv(this.addr,t)}function Og(i,t){i.uniform2iv(this.addr,t)}function kg(i,t){i.uniform3iv(this.addr,t)}function Bg(i,t){i.uniform4iv(this.addr,t)}function zg(i,t){i.uniform1uiv(this.addr,t)}function Gg(i,t){i.uniform2uiv(this.addr,t)}function Hg(i,t){i.uniform3uiv(this.addr,t)}function Vg(i,t){i.uniform4uiv(this.addr,t)}function Wg(i,t,e){const n=this.cache,s=t.length,r=ao(e,s);Pe(n,r)||(i.uniform1iv(this.addr,r),Le(n,r));for(let o=0;o!==s;++o)e.setTexture2D(t[o]||fu,r[o])}function Xg(i,t,e){const n=this.cache,s=t.length,r=ao(e,s);Pe(n,r)||(i.uniform1iv(this.addr,r),Le(n,r));for(let o=0;o!==s;++o)e.setTexture3D(t[o]||pu,r[o])}function $g(i,t,e){const n=this.cache,s=t.length,r=ao(e,s);Pe(n,r)||(i.uniform1iv(this.addr,r),Le(n,r));for(let o=0;o!==s;++o)e.setTextureCube(t[o]||mu,r[o])}function qg(i,t,e){const n=this.cache,s=t.length,r=ao(e,s);Pe(n,r)||(i.uniform1iv(this.addr,r),Le(n,r));for(let o=0;o!==s;++o)e.setTexture2DArray(t[o]||du,r[o])}function Yg(i){switch(i){case 5126:return Cg;case 35664:return Pg;case 35665:return Lg;case 35666:return Dg;case 35674:return Ig;case 35675:return Ug;case 35676:return Ng;case 5124:case 35670:return Fg;case 35667:case 35671:return Og;case 35668:case 35672:return kg;case 35669:case 35673:return Bg;case 5125:return zg;case 36294:return Gg;case 36295:return Hg;case 36296:return Vg;case 35678:case 36198:case 36298:case 36306:case 35682:return Wg;case 35679:case 36299:case 36307:return Xg;case 35680:case 36300:case 36308:case 36293:return $g;case 36289:case 36303:case 36311:case 36292:return qg}}class jg{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=Rg(e.type)}}class Kg{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Yg(e.type)}}class Zg{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){const s=this.seq;for(let r=0,o=s.length;r!==o;++r){const a=s[r];a.setValue(t,e[a.id],n)}}}const Xo=/(\w+)(\])?(\[|\.)?/g;function Ul(i,t){i.seq.push(t),i.map[t.id]=t}function Jg(i,t,e){const n=i.name,s=n.length;for(Xo.lastIndex=0;;){const r=Xo.exec(n),o=Xo.lastIndex;let a=r[1];const c=r[2]==="]",l=r[3];if(c&&(a=a|0),l===void 0||l==="["&&o+2===s){Ul(e,l===void 0?new jg(a,i,t):new Kg(a,i,t));break}else{let u=e.map[a];u===void 0&&(u=new Zg(a),Ul(e,u)),e=u}}}class qr{constructor(t,e){this.seq=[],this.map={};const n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){const r=t.getActiveUniform(e,s),o=t.getUniformLocation(e,r.name);Jg(r,o,this)}}setValue(t,e,n,s){const r=this.map[e];r!==void 0&&r.setValue(t,n,s)}setOptional(t,e,n){const s=e[n];s!==void 0&&this.setValue(t,n,s)}static upload(t,e,n,s){for(let r=0,o=e.length;r!==o;++r){const a=e[r],c=n[a.id];c.needsUpdate!==!1&&a.setValue(t,c.value,s)}}static seqWithValue(t,e){const n=[];for(let s=0,r=t.length;s!==r;++s){const o=t[s];o.id in e&&n.push(o)}return n}}function Nl(i,t,e){const n=i.createShader(t);return i.shaderSource(n,e),i.compileShader(n),n}const Qg=37297;let t_=0;function e_(i,t){const e=i.split(`
`),n=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let o=s;o<r;o++){const a=o+1;n.push(`${a===t?">":" "} ${a}: ${e[o]}`)}return n.join(`
`)}const Fl=new zt;function n_(i){Kt._getMatrix(Fl,Kt.workingColorSpace,i);const t=`mat3( ${Fl.elements.map(e=>e.toFixed(4))} )`;switch(Kt.getTransfer(i)){case oo:return[t,"LinearTransferOETF"];case ae:return[t,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",i),[t,"LinearTransferOETF"]}}function Ol(i,t,e){const n=i.getShaderParameter(t,i.COMPILE_STATUS),s=i.getShaderInfoLog(t).trim();if(n&&s==="")return"";const r=/ERROR: 0:(\d+)/.exec(s);if(r){const o=parseInt(r[1]);return e.toUpperCase()+`

`+s+`

`+e_(i.getShaderSource(t),o)}else return s}function i_(i,t){const e=n_(t);return[`vec4 ${i}( vec4 value ) {`,`	return ${e[1]}( vec4( value.rgb * ${e[0]}, value.a ) );`,"}"].join(`
`)}function s_(i,t){let e;switch(t){case od:e="Linear";break;case ad:e="Reinhard";break;case cd:e="Cineon";break;case ld:e="ACESFilmic";break;case ud:e="AgX";break;case fd:e="Neutral";break;case hd:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+i+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}const Cr=new I;function r_(){Kt.getLuminanceCoefficients(Cr);const i=Cr.x.toFixed(4),t=Cr.y.toFixed(4),e=Cr.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function o_(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Hs).join(`
`)}function a_(i){const t=[];for(const e in i){const n=i[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function c_(i,t){const e={},n=i.getProgramParameter(t,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){const r=i.getActiveAttrib(t,s),o=r.name;let a=1;r.type===i.FLOAT_MAT2&&(a=2),r.type===i.FLOAT_MAT3&&(a=3),r.type===i.FLOAT_MAT4&&(a=4),e[o]={type:r.type,location:i.getAttribLocation(t,o),locationSize:a}}return e}function Hs(i){return i!==""}function kl(i,t){const e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Bl(i,t){return i.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const l_=/^[ \t]*#include +<([\w\d./]+)>/gm;function qa(i){return i.replace(l_,u_)}const h_=new Map;function u_(i,t){let e=Ht[t];if(e===void 0){const n=h_.get(t);if(n!==void 0)e=Ht[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return qa(e)}const f_=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function zl(i){return i.replace(f_,d_)}function d_(i,t,e,n){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Gl(i){let t=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?t+=`
#define HIGH_PRECISION`:i.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function p_(i){let t="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===kh?t="SHADOWMAP_TYPE_PCF":i.shadowMapType===Bh?t="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===Hn&&(t="SHADOWMAP_TYPE_VSM"),t}function m_(i){let t="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case fs:case ds:t="ENVMAP_TYPE_CUBE";break;case ro:t="ENVMAP_TYPE_CUBE_UV";break}return t}function g_(i){let t="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case ds:t="ENVMAP_MODE_REFRACTION";break}return t}function __(i){let t="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case rc:t="ENVMAP_BLENDING_MULTIPLY";break;case sd:t="ENVMAP_BLENDING_MIX";break;case rd:t="ENVMAP_BLENDING_ADD";break}return t}function x_(i){const t=i.envMapCubeUVHeight;if(t===null)return null;const e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),112)),texelHeight:n,maxMip:e}}function v_(i,t,e,n){const s=i.getContext(),r=e.defines;let o=e.vertexShader,a=e.fragmentShader;const c=p_(e),l=m_(e),h=g_(e),u=__(e),f=x_(e),m=o_(e),g=a_(r),_=s.createProgram();let p,d,y=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(p=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g].filter(Hs).join(`
`),p.length>0&&(p+=`
`),d=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g].filter(Hs).join(`
`),d.length>0&&(d+=`
`)):(p=[Gl(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Hs).join(`
`),d=[Gl(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+l:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",f?"#define CUBEUV_TEXEL_WIDTH "+f.texelWidth:"",f?"#define CUBEUV_TEXEL_HEIGHT "+f.texelHeight:"",f?"#define CUBEUV_MAX_MIP "+f.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor||e.batchingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==ci?"#define TONE_MAPPING":"",e.toneMapping!==ci?Ht.tonemapping_pars_fragment:"",e.toneMapping!==ci?s_("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Ht.colorspace_pars_fragment,i_("linearToOutputTexel",e.outputColorSpace),r_(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(Hs).join(`
`)),o=qa(o),o=kl(o,e),o=Bl(o,e),a=qa(a),a=kl(a,e),a=Bl(a,e),o=zl(o),a=zl(a),e.isRawShaderMaterial!==!0&&(y=`#version 300 es
`,p=[m,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+p,d=["#define varying in",e.glslVersion===Qc?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Qc?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+d);const b=y+p+o,w=y+d+a,C=Nl(s,s.VERTEX_SHADER,b),A=Nl(s,s.FRAGMENT_SHADER,w);s.attachShader(_,C),s.attachShader(_,A),e.index0AttributeName!==void 0?s.bindAttribLocation(_,0,e.index0AttributeName):e.morphTargets===!0&&s.bindAttribLocation(_,0,"position"),s.linkProgram(_);function S(E){if(i.debug.checkShaderErrors){const P=s.getProgramInfoLog(_).trim(),L=s.getShaderInfoLog(C).trim(),N=s.getShaderInfoLog(A).trim();let F=!0,U=!0;if(s.getProgramParameter(_,s.LINK_STATUS)===!1)if(F=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,_,C,A);else{const O=Ol(s,C,"vertex"),k=Ol(s,A,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(_,s.VALIDATE_STATUS)+`

Material Name: `+E.name+`
Material Type: `+E.type+`

Program Info Log: `+P+`
`+O+`
`+k)}else P!==""?console.warn("THREE.WebGLProgram: Program Info Log:",P):(L===""||N==="")&&(U=!1);U&&(E.diagnostics={runnable:F,programLog:P,vertexShader:{log:L,prefix:p},fragmentShader:{log:N,prefix:d}})}s.deleteShader(C),s.deleteShader(A),M=new qr(s,_),x=c_(s,_)}let M;this.getUniforms=function(){return M===void 0&&S(this),M};let x;this.getAttributes=function(){return x===void 0&&S(this),x};let v=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return v===!1&&(v=s.getProgramParameter(_,Qg)),v},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(_),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=t_++,this.cacheKey=t,this.usedTimes=1,this.program=_,this.vertexShader=C,this.fragmentShader=A,this}let M_=0;class y_{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){const e=t.vertexShader,n=t.fragmentShader,s=this._getShaderStage(e),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(t);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(t){const e=this.materialCache.get(t);for(const n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const e=this.materialCache;let n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){const e=this.shaderCache;let n=e.get(t);return n===void 0&&(n=new S_(t),e.set(t,n)),n}}class S_{constructor(t){this.id=M_++,this.code=t,this.usedTimes=0}}function w_(i,t,e,n,s,r,o){const a=new nu,c=new y_,l=new Set,h=[],u=s.logarithmicDepthBuffer,f=s.vertexTextures;let m=s.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function _(x){return l.add(x),x===0?"uv":`uv${x}`}function p(x,v,E,P,L){const N=P.fog,F=L.geometry,U=x.isMeshStandardMaterial?P.environment:null,O=(x.isMeshStandardMaterial?e:t).get(x.envMap||U),k=O&&O.mapping===ro?O.image.height:null,K=g[x.type];x.precision!==null&&(m=s.getMaxPrecision(x.precision),m!==x.precision&&console.warn("THREE.WebGLProgram.getParameters:",x.precision,"not supported, using",m,"instead."));const Y=F.morphAttributes.position||F.morphAttributes.normal||F.morphAttributes.color,it=Y!==void 0?Y.length:0;let ct=0;F.morphAttributes.position!==void 0&&(ct=1),F.morphAttributes.normal!==void 0&&(ct=2),F.morphAttributes.color!==void 0&&(ct=3);let xt,$,et,ut;if(K){const ne=An[K];xt=ne.vertexShader,$=ne.fragmentShader}else xt=x.vertexShader,$=x.fragmentShader,c.update(x),et=c.getVertexShaderID(x),ut=c.getFragmentShaderID(x);const at=i.getRenderTarget(),Ct=i.state.buffers.depth.getReversed(),Ot=L.isInstancedMesh===!0,Vt=L.isBatchedMesh===!0,ge=!!x.map,Yt=!!x.matcap,be=!!O,H=!!x.aoMap,ln=!!x.lightMap,Xt=!!x.bumpMap,$t=!!x.normalMap,Lt=!!x.displacementMap,he=!!x.emissiveMap,Pt=!!x.metalnessMap,D=!!x.roughnessMap,T=x.anisotropy>0,V=x.clearcoat>0,J=x.dispersion>0,nt=x.iridescence>0,Z=x.sheen>0,Tt=x.transmission>0,dt=T&&!!x.anisotropyMap,Mt=V&&!!x.clearcoatMap,jt=V&&!!x.clearcoatNormalMap,rt=V&&!!x.clearcoatRoughnessMap,yt=nt&&!!x.iridescenceMap,Dt=nt&&!!x.iridescenceThicknessMap,It=Z&&!!x.sheenColorMap,St=Z&&!!x.sheenRoughnessMap,qt=!!x.specularMap,Gt=!!x.specularColorMap,ce=!!x.specularIntensityMap,B=Tt&&!!x.transmissionMap,ft=Tt&&!!x.thicknessMap,j=!!x.gradientMap,Q=!!x.alphaMap,gt=x.alphaTest>0,pt=!!x.alphaHash,kt=!!x.extensions;let ye=ci;x.toneMapped&&(at===null||at.isXRRenderTarget===!0)&&(ye=i.toneMapping);const Ge={shaderID:K,shaderType:x.type,shaderName:x.name,vertexShader:xt,fragmentShader:$,defines:x.defines,customVertexShaderID:et,customFragmentShaderID:ut,isRawShaderMaterial:x.isRawShaderMaterial===!0,glslVersion:x.glslVersion,precision:m,batching:Vt,batchingColor:Vt&&L._colorsTexture!==null,instancing:Ot,instancingColor:Ot&&L.instanceColor!==null,instancingMorph:Ot&&L.morphTexture!==null,supportsVertexTextures:f,outputColorSpace:at===null?i.outputColorSpace:at.isXRRenderTarget===!0?at.texture.colorSpace:Ss,alphaToCoverage:!!x.alphaToCoverage,map:ge,matcap:Yt,envMap:be,envMapMode:be&&O.mapping,envMapCubeUVHeight:k,aoMap:H,lightMap:ln,bumpMap:Xt,normalMap:$t,displacementMap:f&&Lt,emissiveMap:he,normalMapObjectSpace:$t&&x.normalMapType===gd,normalMapTangentSpace:$t&&x.normalMapType===Kh,metalnessMap:Pt,roughnessMap:D,anisotropy:T,anisotropyMap:dt,clearcoat:V,clearcoatMap:Mt,clearcoatNormalMap:jt,clearcoatRoughnessMap:rt,dispersion:J,iridescence:nt,iridescenceMap:yt,iridescenceThicknessMap:Dt,sheen:Z,sheenColorMap:It,sheenRoughnessMap:St,specularMap:qt,specularColorMap:Gt,specularIntensityMap:ce,transmission:Tt,transmissionMap:B,thicknessMap:ft,gradientMap:j,opaque:x.transparent===!1&&x.blending===as&&x.alphaToCoverage===!1,alphaMap:Q,alphaTest:gt,alphaHash:pt,combine:x.combine,mapUv:ge&&_(x.map.channel),aoMapUv:H&&_(x.aoMap.channel),lightMapUv:ln&&_(x.lightMap.channel),bumpMapUv:Xt&&_(x.bumpMap.channel),normalMapUv:$t&&_(x.normalMap.channel),displacementMapUv:Lt&&_(x.displacementMap.channel),emissiveMapUv:he&&_(x.emissiveMap.channel),metalnessMapUv:Pt&&_(x.metalnessMap.channel),roughnessMapUv:D&&_(x.roughnessMap.channel),anisotropyMapUv:dt&&_(x.anisotropyMap.channel),clearcoatMapUv:Mt&&_(x.clearcoatMap.channel),clearcoatNormalMapUv:jt&&_(x.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:rt&&_(x.clearcoatRoughnessMap.channel),iridescenceMapUv:yt&&_(x.iridescenceMap.channel),iridescenceThicknessMapUv:Dt&&_(x.iridescenceThicknessMap.channel),sheenColorMapUv:It&&_(x.sheenColorMap.channel),sheenRoughnessMapUv:St&&_(x.sheenRoughnessMap.channel),specularMapUv:qt&&_(x.specularMap.channel),specularColorMapUv:Gt&&_(x.specularColorMap.channel),specularIntensityMapUv:ce&&_(x.specularIntensityMap.channel),transmissionMapUv:B&&_(x.transmissionMap.channel),thicknessMapUv:ft&&_(x.thicknessMap.channel),alphaMapUv:Q&&_(x.alphaMap.channel),vertexTangents:!!F.attributes.tangent&&($t||T),vertexColors:x.vertexColors,vertexAlphas:x.vertexColors===!0&&!!F.attributes.color&&F.attributes.color.itemSize===4,pointsUvs:L.isPoints===!0&&!!F.attributes.uv&&(ge||Q),fog:!!N,useFog:x.fog===!0,fogExp2:!!N&&N.isFogExp2,flatShading:x.flatShading===!0,sizeAttenuation:x.sizeAttenuation===!0,logarithmicDepthBuffer:u,reverseDepthBuffer:Ct,skinning:L.isSkinnedMesh===!0,morphTargets:F.morphAttributes.position!==void 0,morphNormals:F.morphAttributes.normal!==void 0,morphColors:F.morphAttributes.color!==void 0,morphTargetsCount:it,morphTextureStride:ct,numDirLights:v.directional.length,numPointLights:v.point.length,numSpotLights:v.spot.length,numSpotLightMaps:v.spotLightMap.length,numRectAreaLights:v.rectArea.length,numHemiLights:v.hemi.length,numDirLightShadows:v.directionalShadowMap.length,numPointLightShadows:v.pointShadowMap.length,numSpotLightShadows:v.spotShadowMap.length,numSpotLightShadowsWithMaps:v.numSpotLightShadowsWithMaps,numLightProbes:v.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:x.dithering,shadowMapEnabled:i.shadowMap.enabled&&E.length>0,shadowMapType:i.shadowMap.type,toneMapping:ye,decodeVideoTexture:ge&&x.map.isVideoTexture===!0&&Kt.getTransfer(x.map.colorSpace)===ae,decodeVideoTextureEmissive:he&&x.emissiveMap.isVideoTexture===!0&&Kt.getTransfer(x.emissiveMap.colorSpace)===ae,premultipliedAlpha:x.premultipliedAlpha,doubleSided:x.side===ze,flipSided:x.side===Qe,useDepthPacking:x.depthPacking>=0,depthPacking:x.depthPacking||0,index0AttributeName:x.index0AttributeName,extensionClipCullDistance:kt&&x.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(kt&&x.extensions.multiDraw===!0||Vt)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:x.customProgramCacheKey()};return Ge.vertexUv1s=l.has(1),Ge.vertexUv2s=l.has(2),Ge.vertexUv3s=l.has(3),l.clear(),Ge}function d(x){const v=[];if(x.shaderID?v.push(x.shaderID):(v.push(x.customVertexShaderID),v.push(x.customFragmentShaderID)),x.defines!==void 0)for(const E in x.defines)v.push(E),v.push(x.defines[E]);return x.isRawShaderMaterial===!1&&(y(v,x),b(v,x),v.push(i.outputColorSpace)),v.push(x.customProgramCacheKey),v.join()}function y(x,v){x.push(v.precision),x.push(v.outputColorSpace),x.push(v.envMapMode),x.push(v.envMapCubeUVHeight),x.push(v.mapUv),x.push(v.alphaMapUv),x.push(v.lightMapUv),x.push(v.aoMapUv),x.push(v.bumpMapUv),x.push(v.normalMapUv),x.push(v.displacementMapUv),x.push(v.emissiveMapUv),x.push(v.metalnessMapUv),x.push(v.roughnessMapUv),x.push(v.anisotropyMapUv),x.push(v.clearcoatMapUv),x.push(v.clearcoatNormalMapUv),x.push(v.clearcoatRoughnessMapUv),x.push(v.iridescenceMapUv),x.push(v.iridescenceThicknessMapUv),x.push(v.sheenColorMapUv),x.push(v.sheenRoughnessMapUv),x.push(v.specularMapUv),x.push(v.specularColorMapUv),x.push(v.specularIntensityMapUv),x.push(v.transmissionMapUv),x.push(v.thicknessMapUv),x.push(v.combine),x.push(v.fogExp2),x.push(v.sizeAttenuation),x.push(v.morphTargetsCount),x.push(v.morphAttributeCount),x.push(v.numDirLights),x.push(v.numPointLights),x.push(v.numSpotLights),x.push(v.numSpotLightMaps),x.push(v.numHemiLights),x.push(v.numRectAreaLights),x.push(v.numDirLightShadows),x.push(v.numPointLightShadows),x.push(v.numSpotLightShadows),x.push(v.numSpotLightShadowsWithMaps),x.push(v.numLightProbes),x.push(v.shadowMapType),x.push(v.toneMapping),x.push(v.numClippingPlanes),x.push(v.numClipIntersection),x.push(v.depthPacking)}function b(x,v){a.disableAll(),v.supportsVertexTextures&&a.enable(0),v.instancing&&a.enable(1),v.instancingColor&&a.enable(2),v.instancingMorph&&a.enable(3),v.matcap&&a.enable(4),v.envMap&&a.enable(5),v.normalMapObjectSpace&&a.enable(6),v.normalMapTangentSpace&&a.enable(7),v.clearcoat&&a.enable(8),v.iridescence&&a.enable(9),v.alphaTest&&a.enable(10),v.vertexColors&&a.enable(11),v.vertexAlphas&&a.enable(12),v.vertexUv1s&&a.enable(13),v.vertexUv2s&&a.enable(14),v.vertexUv3s&&a.enable(15),v.vertexTangents&&a.enable(16),v.anisotropy&&a.enable(17),v.alphaHash&&a.enable(18),v.batching&&a.enable(19),v.dispersion&&a.enable(20),v.batchingColor&&a.enable(21),x.push(a.mask),a.disableAll(),v.fog&&a.enable(0),v.useFog&&a.enable(1),v.flatShading&&a.enable(2),v.logarithmicDepthBuffer&&a.enable(3),v.reverseDepthBuffer&&a.enable(4),v.skinning&&a.enable(5),v.morphTargets&&a.enable(6),v.morphNormals&&a.enable(7),v.morphColors&&a.enable(8),v.premultipliedAlpha&&a.enable(9),v.shadowMapEnabled&&a.enable(10),v.doubleSided&&a.enable(11),v.flipSided&&a.enable(12),v.useDepthPacking&&a.enable(13),v.dithering&&a.enable(14),v.transmission&&a.enable(15),v.sheen&&a.enable(16),v.opaque&&a.enable(17),v.pointsUvs&&a.enable(18),v.decodeVideoTexture&&a.enable(19),v.decodeVideoTextureEmissive&&a.enable(20),v.alphaToCoverage&&a.enable(21),x.push(a.mask)}function w(x){const v=g[x.type];let E;if(v){const P=An[v];E=op.clone(P.uniforms)}else E=x.uniforms;return E}function C(x,v){let E;for(let P=0,L=h.length;P<L;P++){const N=h[P];if(N.cacheKey===v){E=N,++E.usedTimes;break}}return E===void 0&&(E=new v_(i,v,x,r),h.push(E)),E}function A(x){if(--x.usedTimes===0){const v=h.indexOf(x);h[v]=h[h.length-1],h.pop(),x.destroy()}}function S(x){c.remove(x)}function M(){c.dispose()}return{getParameters:p,getProgramCacheKey:d,getUniforms:w,acquireProgram:C,releaseProgram:A,releaseShaderCache:S,programs:h,dispose:M}}function b_(){let i=new WeakMap;function t(o){return i.has(o)}function e(o){let a=i.get(o);return a===void 0&&(a={},i.set(o,a)),a}function n(o){i.delete(o)}function s(o,a,c){i.get(o)[a]=c}function r(){i=new WeakMap}return{has:t,get:e,remove:n,update:s,dispose:r}}function E_(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.material.id!==t.material.id?i.material.id-t.material.id:i.z!==t.z?i.z-t.z:i.id-t.id}function Hl(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.z!==t.z?t.z-i.z:i.id-t.id}function Vl(){const i=[];let t=0;const e=[],n=[],s=[];function r(){t=0,e.length=0,n.length=0,s.length=0}function o(u,f,m,g,_,p){let d=i[t];return d===void 0?(d={id:u.id,object:u,geometry:f,material:m,groupOrder:g,renderOrder:u.renderOrder,z:_,group:p},i[t]=d):(d.id=u.id,d.object=u,d.geometry=f,d.material=m,d.groupOrder=g,d.renderOrder=u.renderOrder,d.z=_,d.group=p),t++,d}function a(u,f,m,g,_,p){const d=o(u,f,m,g,_,p);m.transmission>0?n.push(d):m.transparent===!0?s.push(d):e.push(d)}function c(u,f,m,g,_,p){const d=o(u,f,m,g,_,p);m.transmission>0?n.unshift(d):m.transparent===!0?s.unshift(d):e.unshift(d)}function l(u,f){e.length>1&&e.sort(u||E_),n.length>1&&n.sort(f||Hl),s.length>1&&s.sort(f||Hl)}function h(){for(let u=t,f=i.length;u<f;u++){const m=i[u];if(m.id===null)break;m.id=null,m.object=null,m.geometry=null,m.material=null,m.group=null}}return{opaque:e,transmissive:n,transparent:s,init:r,push:a,unshift:c,finish:h,sort:l}}function T_(){let i=new WeakMap;function t(n,s){const r=i.get(n);let o;return r===void 0?(o=new Vl,i.set(n,[o])):s>=r.length?(o=new Vl,r.push(o)):o=r[s],o}function e(){i=new WeakMap}return{get:t,dispose:e}}function A_(){const i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new I,color:new _t};break;case"SpotLight":e={position:new I,direction:new I,color:new _t,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new I,color:new _t,distance:0,decay:0};break;case"HemisphereLight":e={direction:new I,skyColor:new _t,groundColor:new _t};break;case"RectAreaLight":e={color:new _t,position:new I,halfWidth:new I,halfHeight:new I};break}return i[t.id]=e,e}}}function R_(){const i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ft};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ft};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ft,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[t.id]=e,e}}}let C_=0;function P_(i,t){return(t.castShadow?2:0)-(i.castShadow?2:0)+(t.map?1:0)-(i.map?1:0)}function L_(i){const t=new A_,e=R_(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let l=0;l<9;l++)n.probe.push(new I);const s=new I,r=new Wt,o=new Wt;function a(l){let h=0,u=0,f=0;for(let x=0;x<9;x++)n.probe[x].set(0,0,0);let m=0,g=0,_=0,p=0,d=0,y=0,b=0,w=0,C=0,A=0,S=0;l.sort(P_);for(let x=0,v=l.length;x<v;x++){const E=l[x],P=E.color,L=E.intensity,N=E.distance,F=E.shadow&&E.shadow.map?E.shadow.map.texture:null;if(E.isAmbientLight)h+=P.r*L,u+=P.g*L,f+=P.b*L;else if(E.isLightProbe){for(let U=0;U<9;U++)n.probe[U].addScaledVector(E.sh.coefficients[U],L);S++}else if(E.isDirectionalLight){const U=t.get(E);if(U.color.copy(E.color).multiplyScalar(E.intensity),E.castShadow){const O=E.shadow,k=e.get(E);k.shadowIntensity=O.intensity,k.shadowBias=O.bias,k.shadowNormalBias=O.normalBias,k.shadowRadius=O.radius,k.shadowMapSize=O.mapSize,n.directionalShadow[m]=k,n.directionalShadowMap[m]=F,n.directionalShadowMatrix[m]=E.shadow.matrix,y++}n.directional[m]=U,m++}else if(E.isSpotLight){const U=t.get(E);U.position.setFromMatrixPosition(E.matrixWorld),U.color.copy(P).multiplyScalar(L),U.distance=N,U.coneCos=Math.cos(E.angle),U.penumbraCos=Math.cos(E.angle*(1-E.penumbra)),U.decay=E.decay,n.spot[_]=U;const O=E.shadow;if(E.map&&(n.spotLightMap[C]=E.map,C++,O.updateMatrices(E),E.castShadow&&A++),n.spotLightMatrix[_]=O.matrix,E.castShadow){const k=e.get(E);k.shadowIntensity=O.intensity,k.shadowBias=O.bias,k.shadowNormalBias=O.normalBias,k.shadowRadius=O.radius,k.shadowMapSize=O.mapSize,n.spotShadow[_]=k,n.spotShadowMap[_]=F,w++}_++}else if(E.isRectAreaLight){const U=t.get(E);U.color.copy(P).multiplyScalar(L),U.halfWidth.set(E.width*.5,0,0),U.halfHeight.set(0,E.height*.5,0),n.rectArea[p]=U,p++}else if(E.isPointLight){const U=t.get(E);if(U.color.copy(E.color).multiplyScalar(E.intensity),U.distance=E.distance,U.decay=E.decay,E.castShadow){const O=E.shadow,k=e.get(E);k.shadowIntensity=O.intensity,k.shadowBias=O.bias,k.shadowNormalBias=O.normalBias,k.shadowRadius=O.radius,k.shadowMapSize=O.mapSize,k.shadowCameraNear=O.camera.near,k.shadowCameraFar=O.camera.far,n.pointShadow[g]=k,n.pointShadowMap[g]=F,n.pointShadowMatrix[g]=E.shadow.matrix,b++}n.point[g]=U,g++}else if(E.isHemisphereLight){const U=t.get(E);U.skyColor.copy(E.color).multiplyScalar(L),U.groundColor.copy(E.groundColor).multiplyScalar(L),n.hemi[d]=U,d++}}p>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=lt.LTC_FLOAT_1,n.rectAreaLTC2=lt.LTC_FLOAT_2):(n.rectAreaLTC1=lt.LTC_HALF_1,n.rectAreaLTC2=lt.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=f;const M=n.hash;(M.directionalLength!==m||M.pointLength!==g||M.spotLength!==_||M.rectAreaLength!==p||M.hemiLength!==d||M.numDirectionalShadows!==y||M.numPointShadows!==b||M.numSpotShadows!==w||M.numSpotMaps!==C||M.numLightProbes!==S)&&(n.directional.length=m,n.spot.length=_,n.rectArea.length=p,n.point.length=g,n.hemi.length=d,n.directionalShadow.length=y,n.directionalShadowMap.length=y,n.pointShadow.length=b,n.pointShadowMap.length=b,n.spotShadow.length=w,n.spotShadowMap.length=w,n.directionalShadowMatrix.length=y,n.pointShadowMatrix.length=b,n.spotLightMatrix.length=w+C-A,n.spotLightMap.length=C,n.numSpotLightShadowsWithMaps=A,n.numLightProbes=S,M.directionalLength=m,M.pointLength=g,M.spotLength=_,M.rectAreaLength=p,M.hemiLength=d,M.numDirectionalShadows=y,M.numPointShadows=b,M.numSpotShadows=w,M.numSpotMaps=C,M.numLightProbes=S,n.version=C_++)}function c(l,h){let u=0,f=0,m=0,g=0,_=0;const p=h.matrixWorldInverse;for(let d=0,y=l.length;d<y;d++){const b=l[d];if(b.isDirectionalLight){const w=n.directional[u];w.direction.setFromMatrixPosition(b.matrixWorld),s.setFromMatrixPosition(b.target.matrixWorld),w.direction.sub(s),w.direction.transformDirection(p),u++}else if(b.isSpotLight){const w=n.spot[m];w.position.setFromMatrixPosition(b.matrixWorld),w.position.applyMatrix4(p),w.direction.setFromMatrixPosition(b.matrixWorld),s.setFromMatrixPosition(b.target.matrixWorld),w.direction.sub(s),w.direction.transformDirection(p),m++}else if(b.isRectAreaLight){const w=n.rectArea[g];w.position.setFromMatrixPosition(b.matrixWorld),w.position.applyMatrix4(p),o.identity(),r.copy(b.matrixWorld),r.premultiply(p),o.extractRotation(r),w.halfWidth.set(b.width*.5,0,0),w.halfHeight.set(0,b.height*.5,0),w.halfWidth.applyMatrix4(o),w.halfHeight.applyMatrix4(o),g++}else if(b.isPointLight){const w=n.point[f];w.position.setFromMatrixPosition(b.matrixWorld),w.position.applyMatrix4(p),f++}else if(b.isHemisphereLight){const w=n.hemi[_];w.direction.setFromMatrixPosition(b.matrixWorld),w.direction.transformDirection(p),_++}}}return{setup:a,setupView:c,state:n}}function Wl(i){const t=new L_(i),e=[],n=[];function s(h){l.camera=h,e.length=0,n.length=0}function r(h){e.push(h)}function o(h){n.push(h)}function a(){t.setup(e)}function c(h){t.setupView(e,h)}const l={lightsArray:e,shadowsArray:n,camera:null,lights:t,transmissionRenderTarget:{}};return{init:s,state:l,setupLights:a,setupLightsView:c,pushLight:r,pushShadow:o}}function D_(i){let t=new WeakMap;function e(s,r=0){const o=t.get(s);let a;return o===void 0?(a=new Wl(i),t.set(s,[a])):r>=o.length?(a=new Wl(i),o.push(a)):a=o[r],a}function n(){t=new WeakMap}return{get:e,dispose:n}}class I_ extends fi{static get type(){return"MeshDepthMaterial"}constructor(t){super(),this.isMeshDepthMaterial=!0,this.depthPacking=pd,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class U_ extends fi{static get type(){return"MeshDistanceMaterial"}constructor(t){super(),this.isMeshDistanceMaterial=!0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}const N_=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,F_=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function O_(i,t,e){let n=new mc;const s=new Ft,r=new Ft,o=new Se,a=new I_({depthPacking:md}),c=new U_,l={},h=e.maxTextureSize,u={[li]:Qe,[Qe]:li,[ze]:ze},f=new hi({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Ft},radius:{value:4}},vertexShader:N_,fragmentShader:F_}),m=f.clone();m.defines.HORIZONTAL_PASS=1;const g=new Me;g.setAttribute("position",new ve(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const _=new tt(g,f),p=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=kh;let d=this.type;this.render=function(A,S,M){if(p.enabled===!1||p.autoUpdate===!1&&p.needsUpdate===!1||A.length===0)return;const x=i.getRenderTarget(),v=i.getActiveCubeFace(),E=i.getActiveMipmapLevel(),P=i.state;P.setBlending(ai),P.buffers.color.setClear(1,1,1,1),P.buffers.depth.setTest(!0),P.setScissorTest(!1);const L=d!==Hn&&this.type===Hn,N=d===Hn&&this.type!==Hn;for(let F=0,U=A.length;F<U;F++){const O=A[F],k=O.shadow;if(k===void 0){console.warn("THREE.WebGLShadowMap:",O,"has no shadow.");continue}if(k.autoUpdate===!1&&k.needsUpdate===!1)continue;s.copy(k.mapSize);const K=k.getFrameExtents();if(s.multiply(K),r.copy(k.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/K.x),s.x=r.x*K.x,k.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/K.y),s.y=r.y*K.y,k.mapSize.y=r.y)),k.map===null||L===!0||N===!0){const it=this.type!==Hn?{minFilter:tn,magFilter:tn}:{};k.map!==null&&k.map.dispose(),k.map=new Li(s.x,s.y,it),k.map.texture.name=O.name+".shadowMap",k.camera.updateProjectionMatrix()}i.setRenderTarget(k.map),i.clear();const Y=k.getViewportCount();for(let it=0;it<Y;it++){const ct=k.getViewport(it);o.set(r.x*ct.x,r.y*ct.y,r.x*ct.z,r.y*ct.w),P.viewport(o),k.updateMatrices(O,it),n=k.getFrustum(),w(S,M,k.camera,O,this.type)}k.isPointLightShadow!==!0&&this.type===Hn&&y(k,M),k.needsUpdate=!1}d=this.type,p.needsUpdate=!1,i.setRenderTarget(x,v,E)};function y(A,S){const M=t.update(_);f.defines.VSM_SAMPLES!==A.blurSamples&&(f.defines.VSM_SAMPLES=A.blurSamples,m.defines.VSM_SAMPLES=A.blurSamples,f.needsUpdate=!0,m.needsUpdate=!0),A.mapPass===null&&(A.mapPass=new Li(s.x,s.y)),f.uniforms.shadow_pass.value=A.map.texture,f.uniforms.resolution.value=A.mapSize,f.uniforms.radius.value=A.radius,i.setRenderTarget(A.mapPass),i.clear(),i.renderBufferDirect(S,null,M,f,_,null),m.uniforms.shadow_pass.value=A.mapPass.texture,m.uniforms.resolution.value=A.mapSize,m.uniforms.radius.value=A.radius,i.setRenderTarget(A.map),i.clear(),i.renderBufferDirect(S,null,M,m,_,null)}function b(A,S,M,x){let v=null;const E=M.isPointLight===!0?A.customDistanceMaterial:A.customDepthMaterial;if(E!==void 0)v=E;else if(v=M.isPointLight===!0?c:a,i.localClippingEnabled&&S.clipShadows===!0&&Array.isArray(S.clippingPlanes)&&S.clippingPlanes.length!==0||S.displacementMap&&S.displacementScale!==0||S.alphaMap&&S.alphaTest>0||S.map&&S.alphaTest>0){const P=v.uuid,L=S.uuid;let N=l[P];N===void 0&&(N={},l[P]=N);let F=N[L];F===void 0&&(F=v.clone(),N[L]=F,S.addEventListener("dispose",C)),v=F}if(v.visible=S.visible,v.wireframe=S.wireframe,x===Hn?v.side=S.shadowSide!==null?S.shadowSide:S.side:v.side=S.shadowSide!==null?S.shadowSide:u[S.side],v.alphaMap=S.alphaMap,v.alphaTest=S.alphaTest,v.map=S.map,v.clipShadows=S.clipShadows,v.clippingPlanes=S.clippingPlanes,v.clipIntersection=S.clipIntersection,v.displacementMap=S.displacementMap,v.displacementScale=S.displacementScale,v.displacementBias=S.displacementBias,v.wireframeLinewidth=S.wireframeLinewidth,v.linewidth=S.linewidth,M.isPointLight===!0&&v.isMeshDistanceMaterial===!0){const P=i.properties.get(v);P.light=M}return v}function w(A,S,M,x,v){if(A.visible===!1)return;if(A.layers.test(S.layers)&&(A.isMesh||A.isLine||A.isPoints)&&(A.castShadow||A.receiveShadow&&v===Hn)&&(!A.frustumCulled||n.intersectsObject(A))){A.modelViewMatrix.multiplyMatrices(M.matrixWorldInverse,A.matrixWorld);const L=t.update(A),N=A.material;if(Array.isArray(N)){const F=L.groups;for(let U=0,O=F.length;U<O;U++){const k=F[U],K=N[k.materialIndex];if(K&&K.visible){const Y=b(A,K,x,v);A.onBeforeShadow(i,A,S,M,L,Y,k),i.renderBufferDirect(M,null,L,Y,A,k),A.onAfterShadow(i,A,S,M,L,Y,k)}}}else if(N.visible){const F=b(A,N,x,v);A.onBeforeShadow(i,A,S,M,L,F,null),i.renderBufferDirect(M,null,L,F,A,null),A.onAfterShadow(i,A,S,M,L,F,null)}}const P=A.children;for(let L=0,N=P.length;L<N;L++)w(P[L],S,M,x,v)}function C(A){A.target.removeEventListener("dispose",C);for(const M in l){const x=l[M],v=A.target.uuid;v in x&&(x[v].dispose(),delete x[v])}}}const k_={[ha]:ua,[fa]:ma,[da]:ga,[us]:pa,[ua]:ha,[ma]:fa,[ga]:da,[pa]:us};function B_(i,t){function e(){let B=!1;const ft=new Se;let j=null;const Q=new Se(0,0,0,0);return{setMask:function(gt){j!==gt&&!B&&(i.colorMask(gt,gt,gt,gt),j=gt)},setLocked:function(gt){B=gt},setClear:function(gt,pt,kt,ye,Ge){Ge===!0&&(gt*=ye,pt*=ye,kt*=ye),ft.set(gt,pt,kt,ye),Q.equals(ft)===!1&&(i.clearColor(gt,pt,kt,ye),Q.copy(ft))},reset:function(){B=!1,j=null,Q.set(-1,0,0,0)}}}function n(){let B=!1,ft=!1,j=null,Q=null,gt=null;return{setReversed:function(pt){if(ft!==pt){const kt=t.get("EXT_clip_control");ft?kt.clipControlEXT(kt.LOWER_LEFT_EXT,kt.ZERO_TO_ONE_EXT):kt.clipControlEXT(kt.LOWER_LEFT_EXT,kt.NEGATIVE_ONE_TO_ONE_EXT);const ye=gt;gt=null,this.setClear(ye)}ft=pt},getReversed:function(){return ft},setTest:function(pt){pt?at(i.DEPTH_TEST):Ct(i.DEPTH_TEST)},setMask:function(pt){j!==pt&&!B&&(i.depthMask(pt),j=pt)},setFunc:function(pt){if(ft&&(pt=k_[pt]),Q!==pt){switch(pt){case ha:i.depthFunc(i.NEVER);break;case ua:i.depthFunc(i.ALWAYS);break;case fa:i.depthFunc(i.LESS);break;case us:i.depthFunc(i.LEQUAL);break;case da:i.depthFunc(i.EQUAL);break;case pa:i.depthFunc(i.GEQUAL);break;case ma:i.depthFunc(i.GREATER);break;case ga:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}Q=pt}},setLocked:function(pt){B=pt},setClear:function(pt){gt!==pt&&(ft&&(pt=1-pt),i.clearDepth(pt),gt=pt)},reset:function(){B=!1,j=null,Q=null,gt=null,ft=!1}}}function s(){let B=!1,ft=null,j=null,Q=null,gt=null,pt=null,kt=null,ye=null,Ge=null;return{setTest:function(ne){B||(ne?at(i.STENCIL_TEST):Ct(i.STENCIL_TEST))},setMask:function(ne){ft!==ne&&!B&&(i.stencilMask(ne),ft=ne)},setFunc:function(ne,pn,Nn){(j!==ne||Q!==pn||gt!==Nn)&&(i.stencilFunc(ne,pn,Nn),j=ne,Q=pn,gt=Nn)},setOp:function(ne,pn,Nn){(pt!==ne||kt!==pn||ye!==Nn)&&(i.stencilOp(ne,pn,Nn),pt=ne,kt=pn,ye=Nn)},setLocked:function(ne){B=ne},setClear:function(ne){Ge!==ne&&(i.clearStencil(ne),Ge=ne)},reset:function(){B=!1,ft=null,j=null,Q=null,gt=null,pt=null,kt=null,ye=null,Ge=null}}}const r=new e,o=new n,a=new s,c=new WeakMap,l=new WeakMap;let h={},u={},f=new WeakMap,m=[],g=null,_=!1,p=null,d=null,y=null,b=null,w=null,C=null,A=null,S=new _t(0,0,0),M=0,x=!1,v=null,E=null,P=null,L=null,N=null;const F=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let U=!1,O=0;const k=i.getParameter(i.VERSION);k.indexOf("WebGL")!==-1?(O=parseFloat(/^WebGL (\d)/.exec(k)[1]),U=O>=1):k.indexOf("OpenGL ES")!==-1&&(O=parseFloat(/^OpenGL ES (\d)/.exec(k)[1]),U=O>=2);let K=null,Y={};const it=i.getParameter(i.SCISSOR_BOX),ct=i.getParameter(i.VIEWPORT),xt=new Se().fromArray(it),$=new Se().fromArray(ct);function et(B,ft,j,Q){const gt=new Uint8Array(4),pt=i.createTexture();i.bindTexture(B,pt),i.texParameteri(B,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(B,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let kt=0;kt<j;kt++)B===i.TEXTURE_3D||B===i.TEXTURE_2D_ARRAY?i.texImage3D(ft,0,i.RGBA,1,1,Q,0,i.RGBA,i.UNSIGNED_BYTE,gt):i.texImage2D(ft+kt,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,gt);return pt}const ut={};ut[i.TEXTURE_2D]=et(i.TEXTURE_2D,i.TEXTURE_2D,1),ut[i.TEXTURE_CUBE_MAP]=et(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),ut[i.TEXTURE_2D_ARRAY]=et(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),ut[i.TEXTURE_3D]=et(i.TEXTURE_3D,i.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),a.setClear(0),at(i.DEPTH_TEST),o.setFunc(us),Xt(!1),$t(jc),at(i.CULL_FACE),H(ai);function at(B){h[B]!==!0&&(i.enable(B),h[B]=!0)}function Ct(B){h[B]!==!1&&(i.disable(B),h[B]=!1)}function Ot(B,ft){return u[B]!==ft?(i.bindFramebuffer(B,ft),u[B]=ft,B===i.DRAW_FRAMEBUFFER&&(u[i.FRAMEBUFFER]=ft),B===i.FRAMEBUFFER&&(u[i.DRAW_FRAMEBUFFER]=ft),!0):!1}function Vt(B,ft){let j=m,Q=!1;if(B){j=f.get(ft),j===void 0&&(j=[],f.set(ft,j));const gt=B.textures;if(j.length!==gt.length||j[0]!==i.COLOR_ATTACHMENT0){for(let pt=0,kt=gt.length;pt<kt;pt++)j[pt]=i.COLOR_ATTACHMENT0+pt;j.length=gt.length,Q=!0}}else j[0]!==i.BACK&&(j[0]=i.BACK,Q=!0);Q&&i.drawBuffers(j)}function ge(B){return g!==B?(i.useProgram(B),g=B,!0):!1}const Yt={[wi]:i.FUNC_ADD,[Gf]:i.FUNC_SUBTRACT,[Hf]:i.FUNC_REVERSE_SUBTRACT};Yt[Vf]=i.MIN,Yt[Wf]=i.MAX;const be={[Xf]:i.ZERO,[$f]:i.ONE,[qf]:i.SRC_COLOR,[ca]:i.SRC_ALPHA,[Qf]:i.SRC_ALPHA_SATURATE,[Zf]:i.DST_COLOR,[jf]:i.DST_ALPHA,[Yf]:i.ONE_MINUS_SRC_COLOR,[la]:i.ONE_MINUS_SRC_ALPHA,[Jf]:i.ONE_MINUS_DST_COLOR,[Kf]:i.ONE_MINUS_DST_ALPHA,[td]:i.CONSTANT_COLOR,[ed]:i.ONE_MINUS_CONSTANT_COLOR,[nd]:i.CONSTANT_ALPHA,[id]:i.ONE_MINUS_CONSTANT_ALPHA};function H(B,ft,j,Q,gt,pt,kt,ye,Ge,ne){if(B===ai){_===!0&&(Ct(i.BLEND),_=!1);return}if(_===!1&&(at(i.BLEND),_=!0),B!==zf){if(B!==p||ne!==x){if((d!==wi||w!==wi)&&(i.blendEquation(i.FUNC_ADD),d=wi,w=wi),ne)switch(B){case as:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case aa:i.blendFunc(i.ONE,i.ONE);break;case Kc:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case Zc:i.blendFuncSeparate(i.ZERO,i.SRC_COLOR,i.ZERO,i.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",B);break}else switch(B){case as:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case aa:i.blendFunc(i.SRC_ALPHA,i.ONE);break;case Kc:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case Zc:i.blendFunc(i.ZERO,i.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",B);break}y=null,b=null,C=null,A=null,S.set(0,0,0),M=0,p=B,x=ne}return}gt=gt||ft,pt=pt||j,kt=kt||Q,(ft!==d||gt!==w)&&(i.blendEquationSeparate(Yt[ft],Yt[gt]),d=ft,w=gt),(j!==y||Q!==b||pt!==C||kt!==A)&&(i.blendFuncSeparate(be[j],be[Q],be[pt],be[kt]),y=j,b=Q,C=pt,A=kt),(ye.equals(S)===!1||Ge!==M)&&(i.blendColor(ye.r,ye.g,ye.b,Ge),S.copy(ye),M=Ge),p=B,x=!1}function ln(B,ft){B.side===ze?Ct(i.CULL_FACE):at(i.CULL_FACE);let j=B.side===Qe;ft&&(j=!j),Xt(j),B.blending===as&&B.transparent===!1?H(ai):H(B.blending,B.blendEquation,B.blendSrc,B.blendDst,B.blendEquationAlpha,B.blendSrcAlpha,B.blendDstAlpha,B.blendColor,B.blendAlpha,B.premultipliedAlpha),o.setFunc(B.depthFunc),o.setTest(B.depthTest),o.setMask(B.depthWrite),r.setMask(B.colorWrite);const Q=B.stencilWrite;a.setTest(Q),Q&&(a.setMask(B.stencilWriteMask),a.setFunc(B.stencilFunc,B.stencilRef,B.stencilFuncMask),a.setOp(B.stencilFail,B.stencilZFail,B.stencilZPass)),he(B.polygonOffset,B.polygonOffsetFactor,B.polygonOffsetUnits),B.alphaToCoverage===!0?at(i.SAMPLE_ALPHA_TO_COVERAGE):Ct(i.SAMPLE_ALPHA_TO_COVERAGE)}function Xt(B){v!==B&&(B?i.frontFace(i.CW):i.frontFace(i.CCW),v=B)}function $t(B){B!==kf?(at(i.CULL_FACE),B!==E&&(B===jc?i.cullFace(i.BACK):B===Bf?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Ct(i.CULL_FACE),E=B}function Lt(B){B!==P&&(U&&i.lineWidth(B),P=B)}function he(B,ft,j){B?(at(i.POLYGON_OFFSET_FILL),(L!==ft||N!==j)&&(i.polygonOffset(ft,j),L=ft,N=j)):Ct(i.POLYGON_OFFSET_FILL)}function Pt(B){B?at(i.SCISSOR_TEST):Ct(i.SCISSOR_TEST)}function D(B){B===void 0&&(B=i.TEXTURE0+F-1),K!==B&&(i.activeTexture(B),K=B)}function T(B,ft,j){j===void 0&&(K===null?j=i.TEXTURE0+F-1:j=K);let Q=Y[j];Q===void 0&&(Q={type:void 0,texture:void 0},Y[j]=Q),(Q.type!==B||Q.texture!==ft)&&(K!==j&&(i.activeTexture(j),K=j),i.bindTexture(B,ft||ut[B]),Q.type=B,Q.texture=ft)}function V(){const B=Y[K];B!==void 0&&B.type!==void 0&&(i.bindTexture(B.type,null),B.type=void 0,B.texture=void 0)}function J(){try{i.compressedTexImage2D.apply(i,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function nt(){try{i.compressedTexImage3D.apply(i,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function Z(){try{i.texSubImage2D.apply(i,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function Tt(){try{i.texSubImage3D.apply(i,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function dt(){try{i.compressedTexSubImage2D.apply(i,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function Mt(){try{i.compressedTexSubImage3D.apply(i,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function jt(){try{i.texStorage2D.apply(i,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function rt(){try{i.texStorage3D.apply(i,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function yt(){try{i.texImage2D.apply(i,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function Dt(){try{i.texImage3D.apply(i,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function It(B){xt.equals(B)===!1&&(i.scissor(B.x,B.y,B.z,B.w),xt.copy(B))}function St(B){$.equals(B)===!1&&(i.viewport(B.x,B.y,B.z,B.w),$.copy(B))}function qt(B,ft){let j=l.get(ft);j===void 0&&(j=new WeakMap,l.set(ft,j));let Q=j.get(B);Q===void 0&&(Q=i.getUniformBlockIndex(ft,B.name),j.set(B,Q))}function Gt(B,ft){const Q=l.get(ft).get(B);c.get(ft)!==Q&&(i.uniformBlockBinding(ft,Q,B.__bindingPointIndex),c.set(ft,Q))}function ce(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),o.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),h={},K=null,Y={},u={},f=new WeakMap,m=[],g=null,_=!1,p=null,d=null,y=null,b=null,w=null,C=null,A=null,S=new _t(0,0,0),M=0,x=!1,v=null,E=null,P=null,L=null,N=null,xt.set(0,0,i.canvas.width,i.canvas.height),$.set(0,0,i.canvas.width,i.canvas.height),r.reset(),o.reset(),a.reset()}return{buffers:{color:r,depth:o,stencil:a},enable:at,disable:Ct,bindFramebuffer:Ot,drawBuffers:Vt,useProgram:ge,setBlending:H,setMaterial:ln,setFlipSided:Xt,setCullFace:$t,setLineWidth:Lt,setPolygonOffset:he,setScissorTest:Pt,activeTexture:D,bindTexture:T,unbindTexture:V,compressedTexImage2D:J,compressedTexImage3D:nt,texImage2D:yt,texImage3D:Dt,updateUBOMapping:qt,uniformBlockBinding:Gt,texStorage2D:jt,texStorage3D:rt,texSubImage2D:Z,texSubImage3D:Tt,compressedTexSubImage2D:dt,compressedTexSubImage3D:Mt,scissor:It,viewport:St,reset:ce}}function Xl(i,t,e,n){const s=z_(n);switch(e){case Wh:return i*t;case $h:return i*t;case qh:return i*t*2;case lc:return i*t/s.components*s.byteLength;case hc:return i*t/s.components*s.byteLength;case Yh:return i*t*2/s.components*s.byteLength;case uc:return i*t*2/s.components*s.byteLength;case Xh:return i*t*3/s.components*s.byteLength;case wn:return i*t*4/s.components*s.byteLength;case fc:return i*t*4/s.components*s.byteLength;case Hr:case Vr:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case Wr:case Xr:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case ya:case wa:return Math.max(i,16)*Math.max(t,8)/4;case Ma:case Sa:return Math.max(i,8)*Math.max(t,8)/2;case ba:case Ea:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case Ta:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case Aa:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case Ra:return Math.floor((i+4)/5)*Math.floor((t+3)/4)*16;case Ca:return Math.floor((i+4)/5)*Math.floor((t+4)/5)*16;case Pa:return Math.floor((i+5)/6)*Math.floor((t+4)/5)*16;case La:return Math.floor((i+5)/6)*Math.floor((t+5)/6)*16;case Da:return Math.floor((i+7)/8)*Math.floor((t+4)/5)*16;case Ia:return Math.floor((i+7)/8)*Math.floor((t+5)/6)*16;case Ua:return Math.floor((i+7)/8)*Math.floor((t+7)/8)*16;case Na:return Math.floor((i+9)/10)*Math.floor((t+4)/5)*16;case Fa:return Math.floor((i+9)/10)*Math.floor((t+5)/6)*16;case Oa:return Math.floor((i+9)/10)*Math.floor((t+7)/8)*16;case ka:return Math.floor((i+9)/10)*Math.floor((t+9)/10)*16;case Ba:return Math.floor((i+11)/12)*Math.floor((t+9)/10)*16;case za:return Math.floor((i+11)/12)*Math.floor((t+11)/12)*16;case $r:case Ga:case Ha:return Math.ceil(i/4)*Math.ceil(t/4)*16;case jh:case Va:return Math.ceil(i/4)*Math.ceil(t/4)*8;case Wa:case Xa:return Math.ceil(i/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function z_(i){switch(i){case $n:case Gh:return{byteLength:1,components:1};case Ks:case Hh:case nr:return{byteLength:2,components:1};case ac:case cc:return{byteLength:2,components:4};case Pi:case oc:case Cn:return{byteLength:4,components:1};case Vh:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}function G_(i,t,e,n,s,r,o){const a=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),l=new Ft,h=new WeakMap;let u;const f=new WeakMap;let m=!1;try{m=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(D,T){return m?new OffscreenCanvas(D,T):Zr("canvas")}function _(D,T,V){let J=1;const nt=Pt(D);if((nt.width>V||nt.height>V)&&(J=V/Math.max(nt.width,nt.height)),J<1)if(typeof HTMLImageElement<"u"&&D instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&D instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&D instanceof ImageBitmap||typeof VideoFrame<"u"&&D instanceof VideoFrame){const Z=Math.floor(J*nt.width),Tt=Math.floor(J*nt.height);u===void 0&&(u=g(Z,Tt));const dt=T?g(Z,Tt):u;return dt.width=Z,dt.height=Tt,dt.getContext("2d").drawImage(D,0,0,Z,Tt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+nt.width+"x"+nt.height+") to ("+Z+"x"+Tt+")."),dt}else return"data"in D&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+nt.width+"x"+nt.height+")."),D;return D}function p(D){return D.generateMipmaps}function d(D){i.generateMipmap(D)}function y(D){return D.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:D.isWebGL3DRenderTarget?i.TEXTURE_3D:D.isWebGLArrayRenderTarget||D.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function b(D,T,V,J,nt=!1){if(D!==null){if(i[D]!==void 0)return i[D];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+D+"'")}let Z=T;if(T===i.RED&&(V===i.FLOAT&&(Z=i.R32F),V===i.HALF_FLOAT&&(Z=i.R16F),V===i.UNSIGNED_BYTE&&(Z=i.R8)),T===i.RED_INTEGER&&(V===i.UNSIGNED_BYTE&&(Z=i.R8UI),V===i.UNSIGNED_SHORT&&(Z=i.R16UI),V===i.UNSIGNED_INT&&(Z=i.R32UI),V===i.BYTE&&(Z=i.R8I),V===i.SHORT&&(Z=i.R16I),V===i.INT&&(Z=i.R32I)),T===i.RG&&(V===i.FLOAT&&(Z=i.RG32F),V===i.HALF_FLOAT&&(Z=i.RG16F),V===i.UNSIGNED_BYTE&&(Z=i.RG8)),T===i.RG_INTEGER&&(V===i.UNSIGNED_BYTE&&(Z=i.RG8UI),V===i.UNSIGNED_SHORT&&(Z=i.RG16UI),V===i.UNSIGNED_INT&&(Z=i.RG32UI),V===i.BYTE&&(Z=i.RG8I),V===i.SHORT&&(Z=i.RG16I),V===i.INT&&(Z=i.RG32I)),T===i.RGB_INTEGER&&(V===i.UNSIGNED_BYTE&&(Z=i.RGB8UI),V===i.UNSIGNED_SHORT&&(Z=i.RGB16UI),V===i.UNSIGNED_INT&&(Z=i.RGB32UI),V===i.BYTE&&(Z=i.RGB8I),V===i.SHORT&&(Z=i.RGB16I),V===i.INT&&(Z=i.RGB32I)),T===i.RGBA_INTEGER&&(V===i.UNSIGNED_BYTE&&(Z=i.RGBA8UI),V===i.UNSIGNED_SHORT&&(Z=i.RGBA16UI),V===i.UNSIGNED_INT&&(Z=i.RGBA32UI),V===i.BYTE&&(Z=i.RGBA8I),V===i.SHORT&&(Z=i.RGBA16I),V===i.INT&&(Z=i.RGBA32I)),T===i.RGB&&V===i.UNSIGNED_INT_5_9_9_9_REV&&(Z=i.RGB9_E5),T===i.RGBA){const Tt=nt?oo:Kt.getTransfer(J);V===i.FLOAT&&(Z=i.RGBA32F),V===i.HALF_FLOAT&&(Z=i.RGBA16F),V===i.UNSIGNED_BYTE&&(Z=Tt===ae?i.SRGB8_ALPHA8:i.RGBA8),V===i.UNSIGNED_SHORT_4_4_4_4&&(Z=i.RGBA4),V===i.UNSIGNED_SHORT_5_5_5_1&&(Z=i.RGB5_A1)}return(Z===i.R16F||Z===i.R32F||Z===i.RG16F||Z===i.RG32F||Z===i.RGBA16F||Z===i.RGBA32F)&&t.get("EXT_color_buffer_float"),Z}function w(D,T){let V;return D?T===null||T===Pi||T===ms?V=i.DEPTH24_STENCIL8:T===Cn?V=i.DEPTH32F_STENCIL8:T===Ks&&(V=i.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):T===null||T===Pi||T===ms?V=i.DEPTH_COMPONENT24:T===Cn?V=i.DEPTH_COMPONENT32F:T===Ks&&(V=i.DEPTH_COMPONENT16),V}function C(D,T){return p(D)===!0||D.isFramebufferTexture&&D.minFilter!==tn&&D.minFilter!==Sn?Math.log2(Math.max(T.width,T.height))+1:D.mipmaps!==void 0&&D.mipmaps.length>0?D.mipmaps.length:D.isCompressedTexture&&Array.isArray(D.image)?T.mipmaps.length:1}function A(D){const T=D.target;T.removeEventListener("dispose",A),M(T),T.isVideoTexture&&h.delete(T)}function S(D){const T=D.target;T.removeEventListener("dispose",S),v(T)}function M(D){const T=n.get(D);if(T.__webglInit===void 0)return;const V=D.source,J=f.get(V);if(J){const nt=J[T.__cacheKey];nt.usedTimes--,nt.usedTimes===0&&x(D),Object.keys(J).length===0&&f.delete(V)}n.remove(D)}function x(D){const T=n.get(D);i.deleteTexture(T.__webglTexture);const V=D.source,J=f.get(V);delete J[T.__cacheKey],o.memory.textures--}function v(D){const T=n.get(D);if(D.depthTexture&&(D.depthTexture.dispose(),n.remove(D.depthTexture)),D.isWebGLCubeRenderTarget)for(let J=0;J<6;J++){if(Array.isArray(T.__webglFramebuffer[J]))for(let nt=0;nt<T.__webglFramebuffer[J].length;nt++)i.deleteFramebuffer(T.__webglFramebuffer[J][nt]);else i.deleteFramebuffer(T.__webglFramebuffer[J]);T.__webglDepthbuffer&&i.deleteRenderbuffer(T.__webglDepthbuffer[J])}else{if(Array.isArray(T.__webglFramebuffer))for(let J=0;J<T.__webglFramebuffer.length;J++)i.deleteFramebuffer(T.__webglFramebuffer[J]);else i.deleteFramebuffer(T.__webglFramebuffer);if(T.__webglDepthbuffer&&i.deleteRenderbuffer(T.__webglDepthbuffer),T.__webglMultisampledFramebuffer&&i.deleteFramebuffer(T.__webglMultisampledFramebuffer),T.__webglColorRenderbuffer)for(let J=0;J<T.__webglColorRenderbuffer.length;J++)T.__webglColorRenderbuffer[J]&&i.deleteRenderbuffer(T.__webglColorRenderbuffer[J]);T.__webglDepthRenderbuffer&&i.deleteRenderbuffer(T.__webglDepthRenderbuffer)}const V=D.textures;for(let J=0,nt=V.length;J<nt;J++){const Z=n.get(V[J]);Z.__webglTexture&&(i.deleteTexture(Z.__webglTexture),o.memory.textures--),n.remove(V[J])}n.remove(D)}let E=0;function P(){E=0}function L(){const D=E;return D>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+D+" texture units while this GPU supports only "+s.maxTextures),E+=1,D}function N(D){const T=[];return T.push(D.wrapS),T.push(D.wrapT),T.push(D.wrapR||0),T.push(D.magFilter),T.push(D.minFilter),T.push(D.anisotropy),T.push(D.internalFormat),T.push(D.format),T.push(D.type),T.push(D.generateMipmaps),T.push(D.premultiplyAlpha),T.push(D.flipY),T.push(D.unpackAlignment),T.push(D.colorSpace),T.join()}function F(D,T){const V=n.get(D);if(D.isVideoTexture&&Lt(D),D.isRenderTargetTexture===!1&&D.version>0&&V.__version!==D.version){const J=D.image;if(J===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(J.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{$(V,D,T);return}}e.bindTexture(i.TEXTURE_2D,V.__webglTexture,i.TEXTURE0+T)}function U(D,T){const V=n.get(D);if(D.version>0&&V.__version!==D.version){$(V,D,T);return}e.bindTexture(i.TEXTURE_2D_ARRAY,V.__webglTexture,i.TEXTURE0+T)}function O(D,T){const V=n.get(D);if(D.version>0&&V.__version!==D.version){$(V,D,T);return}e.bindTexture(i.TEXTURE_3D,V.__webglTexture,i.TEXTURE0+T)}function k(D,T){const V=n.get(D);if(D.version>0&&V.__version!==D.version){et(V,D,T);return}e.bindTexture(i.TEXTURE_CUBE_MAP,V.__webglTexture,i.TEXTURE0+T)}const K={[ps]:i.REPEAT,[Ti]:i.CLAMP_TO_EDGE,[va]:i.MIRRORED_REPEAT},Y={[tn]:i.NEAREST,[dd]:i.NEAREST_MIPMAP_NEAREST,[lr]:i.NEAREST_MIPMAP_LINEAR,[Sn]:i.LINEAR,[vo]:i.LINEAR_MIPMAP_NEAREST,[Ai]:i.LINEAR_MIPMAP_LINEAR},it={[_d]:i.NEVER,[wd]:i.ALWAYS,[xd]:i.LESS,[Zh]:i.LEQUAL,[vd]:i.EQUAL,[Sd]:i.GEQUAL,[Md]:i.GREATER,[yd]:i.NOTEQUAL};function ct(D,T){if(T.type===Cn&&t.has("OES_texture_float_linear")===!1&&(T.magFilter===Sn||T.magFilter===vo||T.magFilter===lr||T.magFilter===Ai||T.minFilter===Sn||T.minFilter===vo||T.minFilter===lr||T.minFilter===Ai)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(D,i.TEXTURE_WRAP_S,K[T.wrapS]),i.texParameteri(D,i.TEXTURE_WRAP_T,K[T.wrapT]),(D===i.TEXTURE_3D||D===i.TEXTURE_2D_ARRAY)&&i.texParameteri(D,i.TEXTURE_WRAP_R,K[T.wrapR]),i.texParameteri(D,i.TEXTURE_MAG_FILTER,Y[T.magFilter]),i.texParameteri(D,i.TEXTURE_MIN_FILTER,Y[T.minFilter]),T.compareFunction&&(i.texParameteri(D,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(D,i.TEXTURE_COMPARE_FUNC,it[T.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(T.magFilter===tn||T.minFilter!==lr&&T.minFilter!==Ai||T.type===Cn&&t.has("OES_texture_float_linear")===!1)return;if(T.anisotropy>1||n.get(T).__currentAnisotropy){const V=t.get("EXT_texture_filter_anisotropic");i.texParameterf(D,V.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(T.anisotropy,s.getMaxAnisotropy())),n.get(T).__currentAnisotropy=T.anisotropy}}}function xt(D,T){let V=!1;D.__webglInit===void 0&&(D.__webglInit=!0,T.addEventListener("dispose",A));const J=T.source;let nt=f.get(J);nt===void 0&&(nt={},f.set(J,nt));const Z=N(T);if(Z!==D.__cacheKey){nt[Z]===void 0&&(nt[Z]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,V=!0),nt[Z].usedTimes++;const Tt=nt[D.__cacheKey];Tt!==void 0&&(nt[D.__cacheKey].usedTimes--,Tt.usedTimes===0&&x(T)),D.__cacheKey=Z,D.__webglTexture=nt[Z].texture}return V}function $(D,T,V){let J=i.TEXTURE_2D;(T.isDataArrayTexture||T.isCompressedArrayTexture)&&(J=i.TEXTURE_2D_ARRAY),T.isData3DTexture&&(J=i.TEXTURE_3D);const nt=xt(D,T),Z=T.source;e.bindTexture(J,D.__webglTexture,i.TEXTURE0+V);const Tt=n.get(Z);if(Z.version!==Tt.__version||nt===!0){e.activeTexture(i.TEXTURE0+V);const dt=Kt.getPrimaries(Kt.workingColorSpace),Mt=T.colorSpace===oi?null:Kt.getPrimaries(T.colorSpace),jt=T.colorSpace===oi||dt===Mt?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,T.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,T.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,jt);let rt=_(T.image,!1,s.maxTextureSize);rt=he(T,rt);const yt=r.convert(T.format,T.colorSpace),Dt=r.convert(T.type);let It=b(T.internalFormat,yt,Dt,T.colorSpace,T.isVideoTexture);ct(J,T);let St;const qt=T.mipmaps,Gt=T.isVideoTexture!==!0,ce=Tt.__version===void 0||nt===!0,B=Z.dataReady,ft=C(T,rt);if(T.isDepthTexture)It=w(T.format===gs,T.type),ce&&(Gt?e.texStorage2D(i.TEXTURE_2D,1,It,rt.width,rt.height):e.texImage2D(i.TEXTURE_2D,0,It,rt.width,rt.height,0,yt,Dt,null));else if(T.isDataTexture)if(qt.length>0){Gt&&ce&&e.texStorage2D(i.TEXTURE_2D,ft,It,qt[0].width,qt[0].height);for(let j=0,Q=qt.length;j<Q;j++)St=qt[j],Gt?B&&e.texSubImage2D(i.TEXTURE_2D,j,0,0,St.width,St.height,yt,Dt,St.data):e.texImage2D(i.TEXTURE_2D,j,It,St.width,St.height,0,yt,Dt,St.data);T.generateMipmaps=!1}else Gt?(ce&&e.texStorage2D(i.TEXTURE_2D,ft,It,rt.width,rt.height),B&&e.texSubImage2D(i.TEXTURE_2D,0,0,0,rt.width,rt.height,yt,Dt,rt.data)):e.texImage2D(i.TEXTURE_2D,0,It,rt.width,rt.height,0,yt,Dt,rt.data);else if(T.isCompressedTexture)if(T.isCompressedArrayTexture){Gt&&ce&&e.texStorage3D(i.TEXTURE_2D_ARRAY,ft,It,qt[0].width,qt[0].height,rt.depth);for(let j=0,Q=qt.length;j<Q;j++)if(St=qt[j],T.format!==wn)if(yt!==null)if(Gt){if(B)if(T.layerUpdates.size>0){const gt=Xl(St.width,St.height,T.format,T.type);for(const pt of T.layerUpdates){const kt=St.data.subarray(pt*gt/St.data.BYTES_PER_ELEMENT,(pt+1)*gt/St.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,j,0,0,pt,St.width,St.height,1,yt,kt)}T.clearLayerUpdates()}else e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,j,0,0,0,St.width,St.height,rt.depth,yt,St.data)}else e.compressedTexImage3D(i.TEXTURE_2D_ARRAY,j,It,St.width,St.height,rt.depth,0,St.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Gt?B&&e.texSubImage3D(i.TEXTURE_2D_ARRAY,j,0,0,0,St.width,St.height,rt.depth,yt,Dt,St.data):e.texImage3D(i.TEXTURE_2D_ARRAY,j,It,St.width,St.height,rt.depth,0,yt,Dt,St.data)}else{Gt&&ce&&e.texStorage2D(i.TEXTURE_2D,ft,It,qt[0].width,qt[0].height);for(let j=0,Q=qt.length;j<Q;j++)St=qt[j],T.format!==wn?yt!==null?Gt?B&&e.compressedTexSubImage2D(i.TEXTURE_2D,j,0,0,St.width,St.height,yt,St.data):e.compressedTexImage2D(i.TEXTURE_2D,j,It,St.width,St.height,0,St.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Gt?B&&e.texSubImage2D(i.TEXTURE_2D,j,0,0,St.width,St.height,yt,Dt,St.data):e.texImage2D(i.TEXTURE_2D,j,It,St.width,St.height,0,yt,Dt,St.data)}else if(T.isDataArrayTexture)if(Gt){if(ce&&e.texStorage3D(i.TEXTURE_2D_ARRAY,ft,It,rt.width,rt.height,rt.depth),B)if(T.layerUpdates.size>0){const j=Xl(rt.width,rt.height,T.format,T.type);for(const Q of T.layerUpdates){const gt=rt.data.subarray(Q*j/rt.data.BYTES_PER_ELEMENT,(Q+1)*j/rt.data.BYTES_PER_ELEMENT);e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,Q,rt.width,rt.height,1,yt,Dt,gt)}T.clearLayerUpdates()}else e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,rt.width,rt.height,rt.depth,yt,Dt,rt.data)}else e.texImage3D(i.TEXTURE_2D_ARRAY,0,It,rt.width,rt.height,rt.depth,0,yt,Dt,rt.data);else if(T.isData3DTexture)Gt?(ce&&e.texStorage3D(i.TEXTURE_3D,ft,It,rt.width,rt.height,rt.depth),B&&e.texSubImage3D(i.TEXTURE_3D,0,0,0,0,rt.width,rt.height,rt.depth,yt,Dt,rt.data)):e.texImage3D(i.TEXTURE_3D,0,It,rt.width,rt.height,rt.depth,0,yt,Dt,rt.data);else if(T.isFramebufferTexture){if(ce)if(Gt)e.texStorage2D(i.TEXTURE_2D,ft,It,rt.width,rt.height);else{let j=rt.width,Q=rt.height;for(let gt=0;gt<ft;gt++)e.texImage2D(i.TEXTURE_2D,gt,It,j,Q,0,yt,Dt,null),j>>=1,Q>>=1}}else if(qt.length>0){if(Gt&&ce){const j=Pt(qt[0]);e.texStorage2D(i.TEXTURE_2D,ft,It,j.width,j.height)}for(let j=0,Q=qt.length;j<Q;j++)St=qt[j],Gt?B&&e.texSubImage2D(i.TEXTURE_2D,j,0,0,yt,Dt,St):e.texImage2D(i.TEXTURE_2D,j,It,yt,Dt,St);T.generateMipmaps=!1}else if(Gt){if(ce){const j=Pt(rt);e.texStorage2D(i.TEXTURE_2D,ft,It,j.width,j.height)}B&&e.texSubImage2D(i.TEXTURE_2D,0,0,0,yt,Dt,rt)}else e.texImage2D(i.TEXTURE_2D,0,It,yt,Dt,rt);p(T)&&d(J),Tt.__version=Z.version,T.onUpdate&&T.onUpdate(T)}D.__version=T.version}function et(D,T,V){if(T.image.length!==6)return;const J=xt(D,T),nt=T.source;e.bindTexture(i.TEXTURE_CUBE_MAP,D.__webglTexture,i.TEXTURE0+V);const Z=n.get(nt);if(nt.version!==Z.__version||J===!0){e.activeTexture(i.TEXTURE0+V);const Tt=Kt.getPrimaries(Kt.workingColorSpace),dt=T.colorSpace===oi?null:Kt.getPrimaries(T.colorSpace),Mt=T.colorSpace===oi||Tt===dt?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,T.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,T.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Mt);const jt=T.isCompressedTexture||T.image[0].isCompressedTexture,rt=T.image[0]&&T.image[0].isDataTexture,yt=[];for(let Q=0;Q<6;Q++)!jt&&!rt?yt[Q]=_(T.image[Q],!0,s.maxCubemapSize):yt[Q]=rt?T.image[Q].image:T.image[Q],yt[Q]=he(T,yt[Q]);const Dt=yt[0],It=r.convert(T.format,T.colorSpace),St=r.convert(T.type),qt=b(T.internalFormat,It,St,T.colorSpace),Gt=T.isVideoTexture!==!0,ce=Z.__version===void 0||J===!0,B=nt.dataReady;let ft=C(T,Dt);ct(i.TEXTURE_CUBE_MAP,T);let j;if(jt){Gt&&ce&&e.texStorage2D(i.TEXTURE_CUBE_MAP,ft,qt,Dt.width,Dt.height);for(let Q=0;Q<6;Q++){j=yt[Q].mipmaps;for(let gt=0;gt<j.length;gt++){const pt=j[gt];T.format!==wn?It!==null?Gt?B&&e.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,gt,0,0,pt.width,pt.height,It,pt.data):e.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,gt,qt,pt.width,pt.height,0,pt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Gt?B&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,gt,0,0,pt.width,pt.height,It,St,pt.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,gt,qt,pt.width,pt.height,0,It,St,pt.data)}}}else{if(j=T.mipmaps,Gt&&ce){j.length>0&&ft++;const Q=Pt(yt[0]);e.texStorage2D(i.TEXTURE_CUBE_MAP,ft,qt,Q.width,Q.height)}for(let Q=0;Q<6;Q++)if(rt){Gt?B&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,0,0,yt[Q].width,yt[Q].height,It,St,yt[Q].data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,qt,yt[Q].width,yt[Q].height,0,It,St,yt[Q].data);for(let gt=0;gt<j.length;gt++){const kt=j[gt].image[Q].image;Gt?B&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,gt+1,0,0,kt.width,kt.height,It,St,kt.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,gt+1,qt,kt.width,kt.height,0,It,St,kt.data)}}else{Gt?B&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,0,0,It,St,yt[Q]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,qt,It,St,yt[Q]);for(let gt=0;gt<j.length;gt++){const pt=j[gt];Gt?B&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,gt+1,0,0,It,St,pt.image[Q]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,gt+1,qt,It,St,pt.image[Q])}}}p(T)&&d(i.TEXTURE_CUBE_MAP),Z.__version=nt.version,T.onUpdate&&T.onUpdate(T)}D.__version=T.version}function ut(D,T,V,J,nt,Z){const Tt=r.convert(V.format,V.colorSpace),dt=r.convert(V.type),Mt=b(V.internalFormat,Tt,dt,V.colorSpace),jt=n.get(T),rt=n.get(V);if(rt.__renderTarget=T,!jt.__hasExternalTextures){const yt=Math.max(1,T.width>>Z),Dt=Math.max(1,T.height>>Z);nt===i.TEXTURE_3D||nt===i.TEXTURE_2D_ARRAY?e.texImage3D(nt,Z,Mt,yt,Dt,T.depth,0,Tt,dt,null):e.texImage2D(nt,Z,Mt,yt,Dt,0,Tt,dt,null)}e.bindFramebuffer(i.FRAMEBUFFER,D),$t(T)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,J,nt,rt.__webglTexture,0,Xt(T)):(nt===i.TEXTURE_2D||nt>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&nt<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,J,nt,rt.__webglTexture,Z),e.bindFramebuffer(i.FRAMEBUFFER,null)}function at(D,T,V){if(i.bindRenderbuffer(i.RENDERBUFFER,D),T.depthBuffer){const J=T.depthTexture,nt=J&&J.isDepthTexture?J.type:null,Z=w(T.stencilBuffer,nt),Tt=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,dt=Xt(T);$t(T)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,dt,Z,T.width,T.height):V?i.renderbufferStorageMultisample(i.RENDERBUFFER,dt,Z,T.width,T.height):i.renderbufferStorage(i.RENDERBUFFER,Z,T.width,T.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,Tt,i.RENDERBUFFER,D)}else{const J=T.textures;for(let nt=0;nt<J.length;nt++){const Z=J[nt],Tt=r.convert(Z.format,Z.colorSpace),dt=r.convert(Z.type),Mt=b(Z.internalFormat,Tt,dt,Z.colorSpace),jt=Xt(T);V&&$t(T)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,jt,Mt,T.width,T.height):$t(T)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,jt,Mt,T.width,T.height):i.renderbufferStorage(i.RENDERBUFFER,Mt,T.width,T.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Ct(D,T){if(T&&T.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(i.FRAMEBUFFER,D),!(T.depthTexture&&T.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const J=n.get(T.depthTexture);J.__renderTarget=T,(!J.__webglTexture||T.depthTexture.image.width!==T.width||T.depthTexture.image.height!==T.height)&&(T.depthTexture.image.width=T.width,T.depthTexture.image.height=T.height,T.depthTexture.needsUpdate=!0),F(T.depthTexture,0);const nt=J.__webglTexture,Z=Xt(T);if(T.depthTexture.format===cs)$t(T)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,nt,0,Z):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,nt,0);else if(T.depthTexture.format===gs)$t(T)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,nt,0,Z):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,nt,0);else throw new Error("Unknown depthTexture format")}function Ot(D){const T=n.get(D),V=D.isWebGLCubeRenderTarget===!0;if(T.__boundDepthTexture!==D.depthTexture){const J=D.depthTexture;if(T.__depthDisposeCallback&&T.__depthDisposeCallback(),J){const nt=()=>{delete T.__boundDepthTexture,delete T.__depthDisposeCallback,J.removeEventListener("dispose",nt)};J.addEventListener("dispose",nt),T.__depthDisposeCallback=nt}T.__boundDepthTexture=J}if(D.depthTexture&&!T.__autoAllocateDepthBuffer){if(V)throw new Error("target.depthTexture not supported in Cube render targets");Ct(T.__webglFramebuffer,D)}else if(V){T.__webglDepthbuffer=[];for(let J=0;J<6;J++)if(e.bindFramebuffer(i.FRAMEBUFFER,T.__webglFramebuffer[J]),T.__webglDepthbuffer[J]===void 0)T.__webglDepthbuffer[J]=i.createRenderbuffer(),at(T.__webglDepthbuffer[J],D,!1);else{const nt=D.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Z=T.__webglDepthbuffer[J];i.bindRenderbuffer(i.RENDERBUFFER,Z),i.framebufferRenderbuffer(i.FRAMEBUFFER,nt,i.RENDERBUFFER,Z)}}else if(e.bindFramebuffer(i.FRAMEBUFFER,T.__webglFramebuffer),T.__webglDepthbuffer===void 0)T.__webglDepthbuffer=i.createRenderbuffer(),at(T.__webglDepthbuffer,D,!1);else{const J=D.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,nt=T.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,nt),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,nt)}e.bindFramebuffer(i.FRAMEBUFFER,null)}function Vt(D,T,V){const J=n.get(D);T!==void 0&&ut(J.__webglFramebuffer,D,D.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),V!==void 0&&Ot(D)}function ge(D){const T=D.texture,V=n.get(D),J=n.get(T);D.addEventListener("dispose",S);const nt=D.textures,Z=D.isWebGLCubeRenderTarget===!0,Tt=nt.length>1;if(Tt||(J.__webglTexture===void 0&&(J.__webglTexture=i.createTexture()),J.__version=T.version,o.memory.textures++),Z){V.__webglFramebuffer=[];for(let dt=0;dt<6;dt++)if(T.mipmaps&&T.mipmaps.length>0){V.__webglFramebuffer[dt]=[];for(let Mt=0;Mt<T.mipmaps.length;Mt++)V.__webglFramebuffer[dt][Mt]=i.createFramebuffer()}else V.__webglFramebuffer[dt]=i.createFramebuffer()}else{if(T.mipmaps&&T.mipmaps.length>0){V.__webglFramebuffer=[];for(let dt=0;dt<T.mipmaps.length;dt++)V.__webglFramebuffer[dt]=i.createFramebuffer()}else V.__webglFramebuffer=i.createFramebuffer();if(Tt)for(let dt=0,Mt=nt.length;dt<Mt;dt++){const jt=n.get(nt[dt]);jt.__webglTexture===void 0&&(jt.__webglTexture=i.createTexture(),o.memory.textures++)}if(D.samples>0&&$t(D)===!1){V.__webglMultisampledFramebuffer=i.createFramebuffer(),V.__webglColorRenderbuffer=[],e.bindFramebuffer(i.FRAMEBUFFER,V.__webglMultisampledFramebuffer);for(let dt=0;dt<nt.length;dt++){const Mt=nt[dt];V.__webglColorRenderbuffer[dt]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,V.__webglColorRenderbuffer[dt]);const jt=r.convert(Mt.format,Mt.colorSpace),rt=r.convert(Mt.type),yt=b(Mt.internalFormat,jt,rt,Mt.colorSpace,D.isXRRenderTarget===!0),Dt=Xt(D);i.renderbufferStorageMultisample(i.RENDERBUFFER,Dt,yt,D.width,D.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+dt,i.RENDERBUFFER,V.__webglColorRenderbuffer[dt])}i.bindRenderbuffer(i.RENDERBUFFER,null),D.depthBuffer&&(V.__webglDepthRenderbuffer=i.createRenderbuffer(),at(V.__webglDepthRenderbuffer,D,!0)),e.bindFramebuffer(i.FRAMEBUFFER,null)}}if(Z){e.bindTexture(i.TEXTURE_CUBE_MAP,J.__webglTexture),ct(i.TEXTURE_CUBE_MAP,T);for(let dt=0;dt<6;dt++)if(T.mipmaps&&T.mipmaps.length>0)for(let Mt=0;Mt<T.mipmaps.length;Mt++)ut(V.__webglFramebuffer[dt][Mt],D,T,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+dt,Mt);else ut(V.__webglFramebuffer[dt],D,T,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+dt,0);p(T)&&d(i.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(Tt){for(let dt=0,Mt=nt.length;dt<Mt;dt++){const jt=nt[dt],rt=n.get(jt);e.bindTexture(i.TEXTURE_2D,rt.__webglTexture),ct(i.TEXTURE_2D,jt),ut(V.__webglFramebuffer,D,jt,i.COLOR_ATTACHMENT0+dt,i.TEXTURE_2D,0),p(jt)&&d(i.TEXTURE_2D)}e.unbindTexture()}else{let dt=i.TEXTURE_2D;if((D.isWebGL3DRenderTarget||D.isWebGLArrayRenderTarget)&&(dt=D.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),e.bindTexture(dt,J.__webglTexture),ct(dt,T),T.mipmaps&&T.mipmaps.length>0)for(let Mt=0;Mt<T.mipmaps.length;Mt++)ut(V.__webglFramebuffer[Mt],D,T,i.COLOR_ATTACHMENT0,dt,Mt);else ut(V.__webglFramebuffer,D,T,i.COLOR_ATTACHMENT0,dt,0);p(T)&&d(dt),e.unbindTexture()}D.depthBuffer&&Ot(D)}function Yt(D){const T=D.textures;for(let V=0,J=T.length;V<J;V++){const nt=T[V];if(p(nt)){const Z=y(D),Tt=n.get(nt).__webglTexture;e.bindTexture(Z,Tt),d(Z),e.unbindTexture()}}}const be=[],H=[];function ln(D){if(D.samples>0){if($t(D)===!1){const T=D.textures,V=D.width,J=D.height;let nt=i.COLOR_BUFFER_BIT;const Z=D.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Tt=n.get(D),dt=T.length>1;if(dt)for(let Mt=0;Mt<T.length;Mt++)e.bindFramebuffer(i.FRAMEBUFFER,Tt.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Mt,i.RENDERBUFFER,null),e.bindFramebuffer(i.FRAMEBUFFER,Tt.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Mt,i.TEXTURE_2D,null,0);e.bindFramebuffer(i.READ_FRAMEBUFFER,Tt.__webglMultisampledFramebuffer),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,Tt.__webglFramebuffer);for(let Mt=0;Mt<T.length;Mt++){if(D.resolveDepthBuffer&&(D.depthBuffer&&(nt|=i.DEPTH_BUFFER_BIT),D.stencilBuffer&&D.resolveStencilBuffer&&(nt|=i.STENCIL_BUFFER_BIT)),dt){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,Tt.__webglColorRenderbuffer[Mt]);const jt=n.get(T[Mt]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,jt,0)}i.blitFramebuffer(0,0,V,J,0,0,V,J,nt,i.NEAREST),c===!0&&(be.length=0,H.length=0,be.push(i.COLOR_ATTACHMENT0+Mt),D.depthBuffer&&D.resolveDepthBuffer===!1&&(be.push(Z),H.push(Z),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,H)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,be))}if(e.bindFramebuffer(i.READ_FRAMEBUFFER,null),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),dt)for(let Mt=0;Mt<T.length;Mt++){e.bindFramebuffer(i.FRAMEBUFFER,Tt.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Mt,i.RENDERBUFFER,Tt.__webglColorRenderbuffer[Mt]);const jt=n.get(T[Mt]).__webglTexture;e.bindFramebuffer(i.FRAMEBUFFER,Tt.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Mt,i.TEXTURE_2D,jt,0)}e.bindFramebuffer(i.DRAW_FRAMEBUFFER,Tt.__webglMultisampledFramebuffer)}else if(D.depthBuffer&&D.resolveDepthBuffer===!1&&c){const T=D.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[T])}}}function Xt(D){return Math.min(s.maxSamples,D.samples)}function $t(D){const T=n.get(D);return D.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&T.__useRenderToTexture!==!1}function Lt(D){const T=o.render.frame;h.get(D)!==T&&(h.set(D,T),D.update())}function he(D,T){const V=D.colorSpace,J=D.format,nt=D.type;return D.isCompressedTexture===!0||D.isVideoTexture===!0||V!==Ss&&V!==oi&&(Kt.getTransfer(V)===ae?(J!==wn||nt!==$n)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",V)),T}function Pt(D){return typeof HTMLImageElement<"u"&&D instanceof HTMLImageElement?(l.width=D.naturalWidth||D.width,l.height=D.naturalHeight||D.height):typeof VideoFrame<"u"&&D instanceof VideoFrame?(l.width=D.displayWidth,l.height=D.displayHeight):(l.width=D.width,l.height=D.height),l}this.allocateTextureUnit=L,this.resetTextureUnits=P,this.setTexture2D=F,this.setTexture2DArray=U,this.setTexture3D=O,this.setTextureCube=k,this.rebindTextures=Vt,this.setupRenderTarget=ge,this.updateRenderTargetMipmap=Yt,this.updateMultisampleRenderTarget=ln,this.setupDepthRenderbuffer=Ot,this.setupFrameBufferTexture=ut,this.useMultisampledRTT=$t}function H_(i,t){function e(n,s=oi){let r;const o=Kt.getTransfer(s);if(n===$n)return i.UNSIGNED_BYTE;if(n===ac)return i.UNSIGNED_SHORT_4_4_4_4;if(n===cc)return i.UNSIGNED_SHORT_5_5_5_1;if(n===Vh)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===Gh)return i.BYTE;if(n===Hh)return i.SHORT;if(n===Ks)return i.UNSIGNED_SHORT;if(n===oc)return i.INT;if(n===Pi)return i.UNSIGNED_INT;if(n===Cn)return i.FLOAT;if(n===nr)return i.HALF_FLOAT;if(n===Wh)return i.ALPHA;if(n===Xh)return i.RGB;if(n===wn)return i.RGBA;if(n===$h)return i.LUMINANCE;if(n===qh)return i.LUMINANCE_ALPHA;if(n===cs)return i.DEPTH_COMPONENT;if(n===gs)return i.DEPTH_STENCIL;if(n===lc)return i.RED;if(n===hc)return i.RED_INTEGER;if(n===Yh)return i.RG;if(n===uc)return i.RG_INTEGER;if(n===fc)return i.RGBA_INTEGER;if(n===Hr||n===Vr||n===Wr||n===Xr)if(o===ae)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===Hr)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Vr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Wr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Xr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===Hr)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Vr)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Wr)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Xr)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Ma||n===ya||n===Sa||n===wa)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===Ma)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===ya)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Sa)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===wa)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===ba||n===Ea||n===Ta)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(n===ba||n===Ea)return o===ae?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===Ta)return o===ae?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===Aa||n===Ra||n===Ca||n===Pa||n===La||n===Da||n===Ia||n===Ua||n===Na||n===Fa||n===Oa||n===ka||n===Ba||n===za)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(n===Aa)return o===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Ra)return o===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Ca)return o===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Pa)return o===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===La)return o===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Da)return o===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Ia)return o===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Ua)return o===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Na)return o===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Fa)return o===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Oa)return o===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===ka)return o===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Ba)return o===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===za)return o===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===$r||n===Ga||n===Ha)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(n===$r)return o===ae?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Ga)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Ha)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===jh||n===Va||n===Wa||n===Xa)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(n===$r)return r.COMPRESSED_RED_RGTC1_EXT;if(n===Va)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Wa)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Xa)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===ms?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:e}}class V_ extends je{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}}class me extends we{constructor(){super(),this.isGroup=!0,this.type="Group"}}const W_={type:"move"};class $o{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new me,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new me,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new I,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new I),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new me,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new I,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new I),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const e=this._hand;if(e)for(const n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let s=null,r=null,o=null;const a=this._targetRay,c=this._grip,l=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(l&&t.hand){o=!0;for(const _ of t.hand.values()){const p=e.getJointPose(_,n),d=this._getHandJoint(l,_);p!==null&&(d.matrix.fromArray(p.transform.matrix),d.matrix.decompose(d.position,d.rotation,d.scale),d.matrixWorldNeedsUpdate=!0,d.jointRadius=p.radius),d.visible=p!==null}const h=l.joints["index-finger-tip"],u=l.joints["thumb-tip"],f=h.position.distanceTo(u.position),m=.02,g=.005;l.inputState.pinching&&f>m+g?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!l.inputState.pinching&&f<=m-g&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else c!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(c.matrix.fromArray(r.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,r.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(r.linearVelocity)):c.hasLinearVelocity=!1,r.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(r.angularVelocity)):c.hasAngularVelocity=!1));a!==null&&(s=e.getPose(t.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(W_)))}return a!==null&&(a.visible=s!==null),c!==null&&(c.visible=r!==null),l!==null&&(l.visible=o!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){const n=new me;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}}const X_=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,$_=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class q_{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e,n){if(this.texture===null){const s=new Xe,r=t.properties.get(s);r.__webglTexture=e.texture,(e.depthNear!=n.depthNear||e.depthFar!=n.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=s}}getMesh(t){if(this.texture!==null&&this.mesh===null){const e=t.cameras[0].viewport,n=new hi({vertexShader:X_,fragmentShader:$_,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new tt(new Ae(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class Y_ extends ws{constructor(t,e){super();const n=this;let s=null,r=1,o=null,a="local-floor",c=1,l=null,h=null,u=null,f=null,m=null,g=null;const _=new q_,p=e.getContextAttributes();let d=null,y=null;const b=[],w=[],C=new Ft;let A=null;const S=new je;S.viewport=new Se;const M=new je;M.viewport=new Se;const x=[S,M],v=new V_;let E=null,P=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function($){let et=b[$];return et===void 0&&(et=new $o,b[$]=et),et.getTargetRaySpace()},this.getControllerGrip=function($){let et=b[$];return et===void 0&&(et=new $o,b[$]=et),et.getGripSpace()},this.getHand=function($){let et=b[$];return et===void 0&&(et=new $o,b[$]=et),et.getHandSpace()};function L($){const et=w.indexOf($.inputSource);if(et===-1)return;const ut=b[et];ut!==void 0&&(ut.update($.inputSource,$.frame,l||o),ut.dispatchEvent({type:$.type,data:$.inputSource}))}function N(){s.removeEventListener("select",L),s.removeEventListener("selectstart",L),s.removeEventListener("selectend",L),s.removeEventListener("squeeze",L),s.removeEventListener("squeezestart",L),s.removeEventListener("squeezeend",L),s.removeEventListener("end",N),s.removeEventListener("inputsourceschange",F);for(let $=0;$<b.length;$++){const et=w[$];et!==null&&(w[$]=null,b[$].disconnect(et))}E=null,P=null,_.reset(),t.setRenderTarget(d),m=null,f=null,u=null,s=null,y=null,xt.stop(),n.isPresenting=!1,t.setPixelRatio(A),t.setSize(C.width,C.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function($){r=$,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function($){a=$,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||o},this.setReferenceSpace=function($){l=$},this.getBaseLayer=function(){return f!==null?f:m},this.getBinding=function(){return u},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function($){if(s=$,s!==null){if(d=t.getRenderTarget(),s.addEventListener("select",L),s.addEventListener("selectstart",L),s.addEventListener("selectend",L),s.addEventListener("squeeze",L),s.addEventListener("squeezestart",L),s.addEventListener("squeezeend",L),s.addEventListener("end",N),s.addEventListener("inputsourceschange",F),p.xrCompatible!==!0&&await e.makeXRCompatible(),A=t.getPixelRatio(),t.getSize(C),s.renderState.layers===void 0){const et={antialias:p.antialias,alpha:!0,depth:p.depth,stencil:p.stencil,framebufferScaleFactor:r};m=new XRWebGLLayer(s,e,et),s.updateRenderState({baseLayer:m}),t.setPixelRatio(1),t.setSize(m.framebufferWidth,m.framebufferHeight,!1),y=new Li(m.framebufferWidth,m.framebufferHeight,{format:wn,type:$n,colorSpace:t.outputColorSpace,stencilBuffer:p.stencil})}else{let et=null,ut=null,at=null;p.depth&&(at=p.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,et=p.stencil?gs:cs,ut=p.stencil?ms:Pi);const Ct={colorFormat:e.RGBA8,depthFormat:at,scaleFactor:r};u=new XRWebGLBinding(s,e),f=u.createProjectionLayer(Ct),s.updateRenderState({layers:[f]}),t.setPixelRatio(1),t.setSize(f.textureWidth,f.textureHeight,!1),y=new Li(f.textureWidth,f.textureHeight,{format:wn,type:$n,depthTexture:new uu(f.textureWidth,f.textureHeight,ut,void 0,void 0,void 0,void 0,void 0,void 0,et),stencilBuffer:p.stencil,colorSpace:t.outputColorSpace,samples:p.antialias?4:0,resolveDepthBuffer:f.ignoreDepthValues===!1})}y.isXRRenderTarget=!0,this.setFoveation(c),l=null,o=await s.requestReferenceSpace(a),xt.setContext(s),xt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return _.getDepthTexture()};function F($){for(let et=0;et<$.removed.length;et++){const ut=$.removed[et],at=w.indexOf(ut);at>=0&&(w[at]=null,b[at].disconnect(ut))}for(let et=0;et<$.added.length;et++){const ut=$.added[et];let at=w.indexOf(ut);if(at===-1){for(let Ot=0;Ot<b.length;Ot++)if(Ot>=w.length){w.push(ut),at=Ot;break}else if(w[Ot]===null){w[Ot]=ut,at=Ot;break}if(at===-1)break}const Ct=b[at];Ct&&Ct.connect(ut)}}const U=new I,O=new I;function k($,et,ut){U.setFromMatrixPosition(et.matrixWorld),O.setFromMatrixPosition(ut.matrixWorld);const at=U.distanceTo(O),Ct=et.projectionMatrix.elements,Ot=ut.projectionMatrix.elements,Vt=Ct[14]/(Ct[10]-1),ge=Ct[14]/(Ct[10]+1),Yt=(Ct[9]+1)/Ct[5],be=(Ct[9]-1)/Ct[5],H=(Ct[8]-1)/Ct[0],ln=(Ot[8]+1)/Ot[0],Xt=Vt*H,$t=Vt*ln,Lt=at/(-H+ln),he=Lt*-H;if(et.matrixWorld.decompose($.position,$.quaternion,$.scale),$.translateX(he),$.translateZ(Lt),$.matrixWorld.compose($.position,$.quaternion,$.scale),$.matrixWorldInverse.copy($.matrixWorld).invert(),Ct[10]===-1)$.projectionMatrix.copy(et.projectionMatrix),$.projectionMatrixInverse.copy(et.projectionMatrixInverse);else{const Pt=Vt+Lt,D=ge+Lt,T=Xt-he,V=$t+(at-he),J=Yt*ge/D*Pt,nt=be*ge/D*Pt;$.projectionMatrix.makePerspective(T,V,J,nt,Pt,D),$.projectionMatrixInverse.copy($.projectionMatrix).invert()}}function K($,et){et===null?$.matrixWorld.copy($.matrix):$.matrixWorld.multiplyMatrices(et.matrixWorld,$.matrix),$.matrixWorldInverse.copy($.matrixWorld).invert()}this.updateCamera=function($){if(s===null)return;let et=$.near,ut=$.far;_.texture!==null&&(_.depthNear>0&&(et=_.depthNear),_.depthFar>0&&(ut=_.depthFar)),v.near=M.near=S.near=et,v.far=M.far=S.far=ut,(E!==v.near||P!==v.far)&&(s.updateRenderState({depthNear:v.near,depthFar:v.far}),E=v.near,P=v.far),S.layers.mask=$.layers.mask|2,M.layers.mask=$.layers.mask|4,v.layers.mask=S.layers.mask|M.layers.mask;const at=$.parent,Ct=v.cameras;K(v,at);for(let Ot=0;Ot<Ct.length;Ot++)K(Ct[Ot],at);Ct.length===2?k(v,S,M):v.projectionMatrix.copy(S.projectionMatrix),Y($,v,at)};function Y($,et,ut){ut===null?$.matrix.copy(et.matrixWorld):($.matrix.copy(ut.matrixWorld),$.matrix.invert(),$.matrix.multiply(et.matrixWorld)),$.matrix.decompose($.position,$.quaternion,$.scale),$.updateMatrixWorld(!0),$.projectionMatrix.copy(et.projectionMatrix),$.projectionMatrixInverse.copy(et.projectionMatrixInverse),$.isPerspectiveCamera&&($.fov=_s*2*Math.atan(1/$.projectionMatrix.elements[5]),$.zoom=1)}this.getCamera=function(){return v},this.getFoveation=function(){if(!(f===null&&m===null))return c},this.setFoveation=function($){c=$,f!==null&&(f.fixedFoveation=$),m!==null&&m.fixedFoveation!==void 0&&(m.fixedFoveation=$)},this.hasDepthSensing=function(){return _.texture!==null},this.getDepthSensingMesh=function(){return _.getMesh(v)};let it=null;function ct($,et){if(h=et.getViewerPose(l||o),g=et,h!==null){const ut=h.views;m!==null&&(t.setRenderTargetFramebuffer(y,m.framebuffer),t.setRenderTarget(y));let at=!1;ut.length!==v.cameras.length&&(v.cameras.length=0,at=!0);for(let Ot=0;Ot<ut.length;Ot++){const Vt=ut[Ot];let ge=null;if(m!==null)ge=m.getViewport(Vt);else{const be=u.getViewSubImage(f,Vt);ge=be.viewport,Ot===0&&(t.setRenderTargetTextures(y,be.colorTexture,f.ignoreDepthValues?void 0:be.depthStencilTexture),t.setRenderTarget(y))}let Yt=x[Ot];Yt===void 0&&(Yt=new je,Yt.layers.enable(Ot),Yt.viewport=new Se,x[Ot]=Yt),Yt.matrix.fromArray(Vt.transform.matrix),Yt.matrix.decompose(Yt.position,Yt.quaternion,Yt.scale),Yt.projectionMatrix.fromArray(Vt.projectionMatrix),Yt.projectionMatrixInverse.copy(Yt.projectionMatrix).invert(),Yt.viewport.set(ge.x,ge.y,ge.width,ge.height),Ot===0&&(v.matrix.copy(Yt.matrix),v.matrix.decompose(v.position,v.quaternion,v.scale)),at===!0&&v.cameras.push(Yt)}const Ct=s.enabledFeatures;if(Ct&&Ct.includes("depth-sensing")){const Ot=u.getDepthInformation(ut[0]);Ot&&Ot.isValid&&Ot.texture&&_.init(t,Ot,s.renderState)}}for(let ut=0;ut<b.length;ut++){const at=w[ut],Ct=b[ut];at!==null&&Ct!==void 0&&Ct.update(at,et,l||o)}it&&it($,et),et.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:et}),g=null}const xt=new lu;xt.setAnimationLoop(ct),this.setAnimationLoop=function($){it=$},this.dispose=function(){}}}const vi=new Dn,j_=new Wt;function K_(i,t){function e(p,d){p.matrixAutoUpdate===!0&&p.updateMatrix(),d.value.copy(p.matrix)}function n(p,d){d.color.getRGB(p.fogColor.value,ou(i)),d.isFog?(p.fogNear.value=d.near,p.fogFar.value=d.far):d.isFogExp2&&(p.fogDensity.value=d.density)}function s(p,d,y,b,w){d.isMeshBasicMaterial||d.isMeshLambertMaterial?r(p,d):d.isMeshToonMaterial?(r(p,d),u(p,d)):d.isMeshPhongMaterial?(r(p,d),h(p,d)):d.isMeshStandardMaterial?(r(p,d),f(p,d),d.isMeshPhysicalMaterial&&m(p,d,w)):d.isMeshMatcapMaterial?(r(p,d),g(p,d)):d.isMeshDepthMaterial?r(p,d):d.isMeshDistanceMaterial?(r(p,d),_(p,d)):d.isMeshNormalMaterial?r(p,d):d.isLineBasicMaterial?(o(p,d),d.isLineDashedMaterial&&a(p,d)):d.isPointsMaterial?c(p,d,y,b):d.isSpriteMaterial?l(p,d):d.isShadowMaterial?(p.color.value.copy(d.color),p.opacity.value=d.opacity):d.isShaderMaterial&&(d.uniformsNeedUpdate=!1)}function r(p,d){p.opacity.value=d.opacity,d.color&&p.diffuse.value.copy(d.color),d.emissive&&p.emissive.value.copy(d.emissive).multiplyScalar(d.emissiveIntensity),d.map&&(p.map.value=d.map,e(d.map,p.mapTransform)),d.alphaMap&&(p.alphaMap.value=d.alphaMap,e(d.alphaMap,p.alphaMapTransform)),d.bumpMap&&(p.bumpMap.value=d.bumpMap,e(d.bumpMap,p.bumpMapTransform),p.bumpScale.value=d.bumpScale,d.side===Qe&&(p.bumpScale.value*=-1)),d.normalMap&&(p.normalMap.value=d.normalMap,e(d.normalMap,p.normalMapTransform),p.normalScale.value.copy(d.normalScale),d.side===Qe&&p.normalScale.value.negate()),d.displacementMap&&(p.displacementMap.value=d.displacementMap,e(d.displacementMap,p.displacementMapTransform),p.displacementScale.value=d.displacementScale,p.displacementBias.value=d.displacementBias),d.emissiveMap&&(p.emissiveMap.value=d.emissiveMap,e(d.emissiveMap,p.emissiveMapTransform)),d.specularMap&&(p.specularMap.value=d.specularMap,e(d.specularMap,p.specularMapTransform)),d.alphaTest>0&&(p.alphaTest.value=d.alphaTest);const y=t.get(d),b=y.envMap,w=y.envMapRotation;b&&(p.envMap.value=b,vi.copy(w),vi.x*=-1,vi.y*=-1,vi.z*=-1,b.isCubeTexture&&b.isRenderTargetTexture===!1&&(vi.y*=-1,vi.z*=-1),p.envMapRotation.value.setFromMatrix4(j_.makeRotationFromEuler(vi)),p.flipEnvMap.value=b.isCubeTexture&&b.isRenderTargetTexture===!1?-1:1,p.reflectivity.value=d.reflectivity,p.ior.value=d.ior,p.refractionRatio.value=d.refractionRatio),d.lightMap&&(p.lightMap.value=d.lightMap,p.lightMapIntensity.value=d.lightMapIntensity,e(d.lightMap,p.lightMapTransform)),d.aoMap&&(p.aoMap.value=d.aoMap,p.aoMapIntensity.value=d.aoMapIntensity,e(d.aoMap,p.aoMapTransform))}function o(p,d){p.diffuse.value.copy(d.color),p.opacity.value=d.opacity,d.map&&(p.map.value=d.map,e(d.map,p.mapTransform))}function a(p,d){p.dashSize.value=d.dashSize,p.totalSize.value=d.dashSize+d.gapSize,p.scale.value=d.scale}function c(p,d,y,b){p.diffuse.value.copy(d.color),p.opacity.value=d.opacity,p.size.value=d.size*y,p.scale.value=b*.5,d.map&&(p.map.value=d.map,e(d.map,p.uvTransform)),d.alphaMap&&(p.alphaMap.value=d.alphaMap,e(d.alphaMap,p.alphaMapTransform)),d.alphaTest>0&&(p.alphaTest.value=d.alphaTest)}function l(p,d){p.diffuse.value.copy(d.color),p.opacity.value=d.opacity,p.rotation.value=d.rotation,d.map&&(p.map.value=d.map,e(d.map,p.mapTransform)),d.alphaMap&&(p.alphaMap.value=d.alphaMap,e(d.alphaMap,p.alphaMapTransform)),d.alphaTest>0&&(p.alphaTest.value=d.alphaTest)}function h(p,d){p.specular.value.copy(d.specular),p.shininess.value=Math.max(d.shininess,1e-4)}function u(p,d){d.gradientMap&&(p.gradientMap.value=d.gradientMap)}function f(p,d){p.metalness.value=d.metalness,d.metalnessMap&&(p.metalnessMap.value=d.metalnessMap,e(d.metalnessMap,p.metalnessMapTransform)),p.roughness.value=d.roughness,d.roughnessMap&&(p.roughnessMap.value=d.roughnessMap,e(d.roughnessMap,p.roughnessMapTransform)),d.envMap&&(p.envMapIntensity.value=d.envMapIntensity)}function m(p,d,y){p.ior.value=d.ior,d.sheen>0&&(p.sheenColor.value.copy(d.sheenColor).multiplyScalar(d.sheen),p.sheenRoughness.value=d.sheenRoughness,d.sheenColorMap&&(p.sheenColorMap.value=d.sheenColorMap,e(d.sheenColorMap,p.sheenColorMapTransform)),d.sheenRoughnessMap&&(p.sheenRoughnessMap.value=d.sheenRoughnessMap,e(d.sheenRoughnessMap,p.sheenRoughnessMapTransform))),d.clearcoat>0&&(p.clearcoat.value=d.clearcoat,p.clearcoatRoughness.value=d.clearcoatRoughness,d.clearcoatMap&&(p.clearcoatMap.value=d.clearcoatMap,e(d.clearcoatMap,p.clearcoatMapTransform)),d.clearcoatRoughnessMap&&(p.clearcoatRoughnessMap.value=d.clearcoatRoughnessMap,e(d.clearcoatRoughnessMap,p.clearcoatRoughnessMapTransform)),d.clearcoatNormalMap&&(p.clearcoatNormalMap.value=d.clearcoatNormalMap,e(d.clearcoatNormalMap,p.clearcoatNormalMapTransform),p.clearcoatNormalScale.value.copy(d.clearcoatNormalScale),d.side===Qe&&p.clearcoatNormalScale.value.negate())),d.dispersion>0&&(p.dispersion.value=d.dispersion),d.iridescence>0&&(p.iridescence.value=d.iridescence,p.iridescenceIOR.value=d.iridescenceIOR,p.iridescenceThicknessMinimum.value=d.iridescenceThicknessRange[0],p.iridescenceThicknessMaximum.value=d.iridescenceThicknessRange[1],d.iridescenceMap&&(p.iridescenceMap.value=d.iridescenceMap,e(d.iridescenceMap,p.iridescenceMapTransform)),d.iridescenceThicknessMap&&(p.iridescenceThicknessMap.value=d.iridescenceThicknessMap,e(d.iridescenceThicknessMap,p.iridescenceThicknessMapTransform))),d.transmission>0&&(p.transmission.value=d.transmission,p.transmissionSamplerMap.value=y.texture,p.transmissionSamplerSize.value.set(y.width,y.height),d.transmissionMap&&(p.transmissionMap.value=d.transmissionMap,e(d.transmissionMap,p.transmissionMapTransform)),p.thickness.value=d.thickness,d.thicknessMap&&(p.thicknessMap.value=d.thicknessMap,e(d.thicknessMap,p.thicknessMapTransform)),p.attenuationDistance.value=d.attenuationDistance,p.attenuationColor.value.copy(d.attenuationColor)),d.anisotropy>0&&(p.anisotropyVector.value.set(d.anisotropy*Math.cos(d.anisotropyRotation),d.anisotropy*Math.sin(d.anisotropyRotation)),d.anisotropyMap&&(p.anisotropyMap.value=d.anisotropyMap,e(d.anisotropyMap,p.anisotropyMapTransform))),p.specularIntensity.value=d.specularIntensity,p.specularColor.value.copy(d.specularColor),d.specularColorMap&&(p.specularColorMap.value=d.specularColorMap,e(d.specularColorMap,p.specularColorMapTransform)),d.specularIntensityMap&&(p.specularIntensityMap.value=d.specularIntensityMap,e(d.specularIntensityMap,p.specularIntensityMapTransform))}function g(p,d){d.matcap&&(p.matcap.value=d.matcap)}function _(p,d){const y=t.get(d).light;p.referencePosition.value.setFromMatrixPosition(y.matrixWorld),p.nearDistance.value=y.shadow.camera.near,p.farDistance.value=y.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function Z_(i,t,e,n){let s={},r={},o=[];const a=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function c(y,b){const w=b.program;n.uniformBlockBinding(y,w)}function l(y,b){let w=s[y.id];w===void 0&&(g(y),w=h(y),s[y.id]=w,y.addEventListener("dispose",p));const C=b.program;n.updateUBOMapping(y,C);const A=t.render.frame;r[y.id]!==A&&(f(y),r[y.id]=A)}function h(y){const b=u();y.__bindingPointIndex=b;const w=i.createBuffer(),C=y.__size,A=y.usage;return i.bindBuffer(i.UNIFORM_BUFFER,w),i.bufferData(i.UNIFORM_BUFFER,C,A),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,b,w),w}function u(){for(let y=0;y<a;y++)if(o.indexOf(y)===-1)return o.push(y),y;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function f(y){const b=s[y.id],w=y.uniforms,C=y.__cache;i.bindBuffer(i.UNIFORM_BUFFER,b);for(let A=0,S=w.length;A<S;A++){const M=Array.isArray(w[A])?w[A]:[w[A]];for(let x=0,v=M.length;x<v;x++){const E=M[x];if(m(E,A,x,C)===!0){const P=E.__offset,L=Array.isArray(E.value)?E.value:[E.value];let N=0;for(let F=0;F<L.length;F++){const U=L[F],O=_(U);typeof U=="number"||typeof U=="boolean"?(E.__data[0]=U,i.bufferSubData(i.UNIFORM_BUFFER,P+N,E.__data)):U.isMatrix3?(E.__data[0]=U.elements[0],E.__data[1]=U.elements[1],E.__data[2]=U.elements[2],E.__data[3]=0,E.__data[4]=U.elements[3],E.__data[5]=U.elements[4],E.__data[6]=U.elements[5],E.__data[7]=0,E.__data[8]=U.elements[6],E.__data[9]=U.elements[7],E.__data[10]=U.elements[8],E.__data[11]=0):(U.toArray(E.__data,N),N+=O.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,P,E.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function m(y,b,w,C){const A=y.value,S=b+"_"+w;if(C[S]===void 0)return typeof A=="number"||typeof A=="boolean"?C[S]=A:C[S]=A.clone(),!0;{const M=C[S];if(typeof A=="number"||typeof A=="boolean"){if(M!==A)return C[S]=A,!0}else if(M.equals(A)===!1)return M.copy(A),!0}return!1}function g(y){const b=y.uniforms;let w=0;const C=16;for(let S=0,M=b.length;S<M;S++){const x=Array.isArray(b[S])?b[S]:[b[S]];for(let v=0,E=x.length;v<E;v++){const P=x[v],L=Array.isArray(P.value)?P.value:[P.value];for(let N=0,F=L.length;N<F;N++){const U=L[N],O=_(U),k=w%C,K=k%O.boundary,Y=k+K;w+=K,Y!==0&&C-Y<O.storage&&(w+=C-Y),P.__data=new Float32Array(O.storage/Float32Array.BYTES_PER_ELEMENT),P.__offset=w,w+=O.storage}}}const A=w%C;return A>0&&(w+=C-A),y.__size=w,y.__cache={},this}function _(y){const b={boundary:0,storage:0};return typeof y=="number"||typeof y=="boolean"?(b.boundary=4,b.storage=4):y.isVector2?(b.boundary=8,b.storage=8):y.isVector3||y.isColor?(b.boundary=16,b.storage=12):y.isVector4?(b.boundary=16,b.storage=16):y.isMatrix3?(b.boundary=48,b.storage=48):y.isMatrix4?(b.boundary=64,b.storage=64):y.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",y),b}function p(y){const b=y.target;b.removeEventListener("dispose",p);const w=o.indexOf(b.__bindingPointIndex);o.splice(w,1),i.deleteBuffer(s[b.id]),delete s[b.id],delete r[b.id]}function d(){for(const y in s)i.deleteBuffer(s[y]);o=[],s={},r={}}return{bind:c,update:l,dispose:d}}class gu{constructor(t={}){const{canvas:e=zd(),context:n=null,depth:s=!0,stencil:r=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reverseDepthBuffer:f=!1}=t;this.isWebGLRenderer=!0;let m;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");m=n.getContextAttributes().alpha}else m=o;const g=new Uint32Array(4),_=new Int32Array(4);let p=null,d=null;const y=[],b=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=Te,this.toneMapping=ci,this.toneMappingExposure=1;const w=this;let C=!1,A=0,S=0,M=null,x=-1,v=null;const E=new Se,P=new Se;let L=null;const N=new _t(0);let F=0,U=e.width,O=e.height,k=1,K=null,Y=null;const it=new Se(0,0,U,O),ct=new Se(0,0,U,O);let xt=!1;const $=new mc;let et=!1,ut=!1;const at=new Wt,Ct=new Wt,Ot=new I,Vt=new Se,ge={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Yt=!1;function be(){return M===null?k:1}let H=n;function ln(R,z){return e.getContext(R,z)}try{const R={alpha:!0,depth:s,stencil:r,antialias:a,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${sc}`),e.addEventListener("webglcontextlost",Q,!1),e.addEventListener("webglcontextrestored",gt,!1),e.addEventListener("webglcontextcreationerror",pt,!1),H===null){const z="webgl2";if(H=ln(z,R),H===null)throw ln(z)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(R){throw console.error("THREE.WebGLRenderer: "+R.message),R}let Xt,$t,Lt,he,Pt,D,T,V,J,nt,Z,Tt,dt,Mt,jt,rt,yt,Dt,It,St,qt,Gt,ce,B;function ft(){Xt=new ig(H),Xt.init(),Gt=new H_(H,Xt),$t=new Z0(H,Xt,t,Gt),Lt=new B_(H,Xt),$t.reverseDepthBuffer&&f&&Lt.buffers.depth.setReversed(!0),he=new og(H),Pt=new b_,D=new G_(H,Xt,Lt,Pt,$t,Gt,he),T=new Q0(w),V=new ng(w),J=new dp(H),ce=new j0(H,J),nt=new sg(H,J,he,ce),Z=new cg(H,nt,J,he),It=new ag(H,$t,D),rt=new J0(Pt),Tt=new w_(w,T,V,Xt,$t,ce,rt),dt=new K_(w,Pt),Mt=new T_,jt=new D_(Xt),Dt=new Y0(w,T,V,Lt,Z,m,c),yt=new O_(w,Z,$t),B=new Z_(H,he,$t,Lt),St=new K0(H,Xt,he),qt=new rg(H,Xt,he),he.programs=Tt.programs,w.capabilities=$t,w.extensions=Xt,w.properties=Pt,w.renderLists=Mt,w.shadowMap=yt,w.state=Lt,w.info=he}ft();const j=new Y_(w,H);this.xr=j,this.getContext=function(){return H},this.getContextAttributes=function(){return H.getContextAttributes()},this.forceContextLoss=function(){const R=Xt.get("WEBGL_lose_context");R&&R.loseContext()},this.forceContextRestore=function(){const R=Xt.get("WEBGL_lose_context");R&&R.restoreContext()},this.getPixelRatio=function(){return k},this.setPixelRatio=function(R){R!==void 0&&(k=R,this.setSize(U,O,!1))},this.getSize=function(R){return R.set(U,O)},this.setSize=function(R,z,W=!0){if(j.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}U=R,O=z,e.width=Math.floor(R*k),e.height=Math.floor(z*k),W===!0&&(e.style.width=R+"px",e.style.height=z+"px"),this.setViewport(0,0,R,z)},this.getDrawingBufferSize=function(R){return R.set(U*k,O*k).floor()},this.setDrawingBufferSize=function(R,z,W){U=R,O=z,k=W,e.width=Math.floor(R*W),e.height=Math.floor(z*W),this.setViewport(0,0,R,z)},this.getCurrentViewport=function(R){return R.copy(E)},this.getViewport=function(R){return R.copy(it)},this.setViewport=function(R,z,W,X){R.isVector4?it.set(R.x,R.y,R.z,R.w):it.set(R,z,W,X),Lt.viewport(E.copy(it).multiplyScalar(k).round())},this.getScissor=function(R){return R.copy(ct)},this.setScissor=function(R,z,W,X){R.isVector4?ct.set(R.x,R.y,R.z,R.w):ct.set(R,z,W,X),Lt.scissor(P.copy(ct).multiplyScalar(k).round())},this.getScissorTest=function(){return xt},this.setScissorTest=function(R){Lt.setScissorTest(xt=R)},this.setOpaqueSort=function(R){K=R},this.setTransparentSort=function(R){Y=R},this.getClearColor=function(R){return R.copy(Dt.getClearColor())},this.setClearColor=function(){Dt.setClearColor.apply(Dt,arguments)},this.getClearAlpha=function(){return Dt.getClearAlpha()},this.setClearAlpha=function(){Dt.setClearAlpha.apply(Dt,arguments)},this.clear=function(R=!0,z=!0,W=!0){let X=0;if(R){let G=!1;if(M!==null){const ot=M.texture.format;G=ot===fc||ot===uc||ot===hc}if(G){const ot=M.texture.type,mt=ot===$n||ot===Pi||ot===Ks||ot===ms||ot===ac||ot===cc,wt=Dt.getClearColor(),bt=Dt.getClearAlpha(),Ut=wt.r,Bt=wt.g,Et=wt.b;mt?(g[0]=Ut,g[1]=Bt,g[2]=Et,g[3]=bt,H.clearBufferuiv(H.COLOR,0,g)):(_[0]=Ut,_[1]=Bt,_[2]=Et,_[3]=bt,H.clearBufferiv(H.COLOR,0,_))}else X|=H.COLOR_BUFFER_BIT}z&&(X|=H.DEPTH_BUFFER_BIT),W&&(X|=H.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),H.clear(X)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",Q,!1),e.removeEventListener("webglcontextrestored",gt,!1),e.removeEventListener("webglcontextcreationerror",pt,!1),Mt.dispose(),jt.dispose(),Pt.dispose(),T.dispose(),V.dispose(),Z.dispose(),ce.dispose(),B.dispose(),Tt.dispose(),j.dispose(),j.removeEventListener("sessionstart",Ic),j.removeEventListener("sessionend",Uc),di.stop()};function Q(R){R.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),C=!0}function gt(){console.log("THREE.WebGLRenderer: Context Restored."),C=!1;const R=he.autoReset,z=yt.enabled,W=yt.autoUpdate,X=yt.needsUpdate,G=yt.type;ft(),he.autoReset=R,yt.enabled=z,yt.autoUpdate=W,yt.needsUpdate=X,yt.type=G}function pt(R){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",R.statusMessage)}function kt(R){const z=R.target;z.removeEventListener("dispose",kt),ye(z)}function ye(R){Ge(R),Pt.remove(R)}function Ge(R){const z=Pt.get(R).programs;z!==void 0&&(z.forEach(function(W){Tt.releaseProgram(W)}),R.isShaderMaterial&&Tt.releaseShaderCache(R))}this.renderBufferDirect=function(R,z,W,X,G,ot){z===null&&(z=ge);const mt=G.isMesh&&G.matrixWorld.determinant()<0,wt=ef(R,z,W,X,G);Lt.setMaterial(X,mt);let bt=W.index,Ut=1;if(X.wireframe===!0){if(bt=nt.getWireframeAttribute(W),bt===void 0)return;Ut=2}const Bt=W.drawRange,Et=W.attributes.position;let Zt=Bt.start*Ut,le=(Bt.start+Bt.count)*Ut;ot!==null&&(Zt=Math.max(Zt,ot.start*Ut),le=Math.min(le,(ot.start+ot.count)*Ut)),bt!==null?(Zt=Math.max(Zt,0),le=Math.min(le,bt.count)):Et!=null&&(Zt=Math.max(Zt,0),le=Math.min(le,Et.count));const ue=le-Zt;if(ue<0||ue===1/0)return;ce.setup(G,X,wt,W,bt);let Ze,Qt=St;if(bt!==null&&(Ze=J.get(bt),Qt=qt,Qt.setIndex(Ze)),G.isMesh)X.wireframe===!0?(Lt.setLineWidth(X.wireframeLinewidth*be()),Qt.setMode(H.LINES)):Qt.setMode(H.TRIANGLES);else if(G.isLine){let At=X.linewidth;At===void 0&&(At=1),Lt.setLineWidth(At*be()),G.isLineSegments?Qt.setMode(H.LINES):G.isLineLoop?Qt.setMode(H.LINE_LOOP):Qt.setMode(H.LINE_STRIP)}else G.isPoints?Qt.setMode(H.POINTS):G.isSprite&&Qt.setMode(H.TRIANGLES);if(G.isBatchedMesh)if(G._multiDrawInstances!==null)Qt.renderMultiDrawInstances(G._multiDrawStarts,G._multiDrawCounts,G._multiDrawCount,G._multiDrawInstances);else if(Xt.get("WEBGL_multi_draw"))Qt.renderMultiDraw(G._multiDrawStarts,G._multiDrawCounts,G._multiDrawCount);else{const At=G._multiDrawStarts,Fn=G._multiDrawCounts,te=G._multiDrawCount,mn=bt?J.get(bt).bytesPerElement:1,Fi=Pt.get(X).currentProgram.getUniforms();for(let sn=0;sn<te;sn++)Fi.setValue(H,"_gl_DrawID",sn),Qt.render(At[sn]/mn,Fn[sn])}else if(G.isInstancedMesh)Qt.renderInstances(Zt,ue,G.count);else if(W.isInstancedBufferGeometry){const At=W._maxInstanceCount!==void 0?W._maxInstanceCount:1/0,Fn=Math.min(W.instanceCount,At);Qt.renderInstances(Zt,ue,Fn)}else Qt.render(Zt,ue)};function ne(R,z,W){R.transparent===!0&&R.side===ze&&R.forceSinglePass===!1?(R.side=Qe,R.needsUpdate=!0,ar(R,z,W),R.side=li,R.needsUpdate=!0,ar(R,z,W),R.side=ze):ar(R,z,W)}this.compile=function(R,z,W=null){W===null&&(W=R),d=jt.get(W),d.init(z),b.push(d),W.traverseVisible(function(G){G.isLight&&G.layers.test(z.layers)&&(d.pushLight(G),G.castShadow&&d.pushShadow(G))}),R!==W&&R.traverseVisible(function(G){G.isLight&&G.layers.test(z.layers)&&(d.pushLight(G),G.castShadow&&d.pushShadow(G))}),d.setupLights();const X=new Set;return R.traverse(function(G){if(!(G.isMesh||G.isPoints||G.isLine||G.isSprite))return;const ot=G.material;if(ot)if(Array.isArray(ot))for(let mt=0;mt<ot.length;mt++){const wt=ot[mt];ne(wt,W,G),X.add(wt)}else ne(ot,W,G),X.add(ot)}),b.pop(),d=null,X},this.compileAsync=function(R,z,W=null){const X=this.compile(R,z,W);return new Promise(G=>{function ot(){if(X.forEach(function(mt){Pt.get(mt).currentProgram.isReady()&&X.delete(mt)}),X.size===0){G(R);return}setTimeout(ot,10)}Xt.get("KHR_parallel_shader_compile")!==null?ot():setTimeout(ot,10)})};let pn=null;function Nn(R){pn&&pn(R)}function Ic(){di.stop()}function Uc(){di.start()}const di=new lu;di.setAnimationLoop(Nn),typeof self<"u"&&di.setContext(self),this.setAnimationLoop=function(R){pn=R,j.setAnimationLoop(R),R===null?di.stop():di.start()},j.addEventListener("sessionstart",Ic),j.addEventListener("sessionend",Uc),this.render=function(R,z){if(z!==void 0&&z.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(C===!0)return;if(R.matrixWorldAutoUpdate===!0&&R.updateMatrixWorld(),z.parent===null&&z.matrixWorldAutoUpdate===!0&&z.updateMatrixWorld(),j.enabled===!0&&j.isPresenting===!0&&(j.cameraAutoUpdate===!0&&j.updateCamera(z),z=j.getCamera()),R.isScene===!0&&R.onBeforeRender(w,R,z,M),d=jt.get(R,b.length),d.init(z),b.push(d),Ct.multiplyMatrices(z.projectionMatrix,z.matrixWorldInverse),$.setFromProjectionMatrix(Ct),ut=this.localClippingEnabled,et=rt.init(this.clippingPlanes,ut),p=Mt.get(R,y.length),p.init(),y.push(p),j.enabled===!0&&j.isPresenting===!0){const ot=w.xr.getDepthSensingMesh();ot!==null&&mo(ot,z,-1/0,w.sortObjects)}mo(R,z,0,w.sortObjects),p.finish(),w.sortObjects===!0&&p.sort(K,Y),Yt=j.enabled===!1||j.isPresenting===!1||j.hasDepthSensing()===!1,Yt&&Dt.addToRenderList(p,R),this.info.render.frame++,et===!0&&rt.beginShadows();const W=d.state.shadowsArray;yt.render(W,R,z),et===!0&&rt.endShadows(),this.info.autoReset===!0&&this.info.reset();const X=p.opaque,G=p.transmissive;if(d.setupLights(),z.isArrayCamera){const ot=z.cameras;if(G.length>0)for(let mt=0,wt=ot.length;mt<wt;mt++){const bt=ot[mt];Fc(X,G,R,bt)}Yt&&Dt.render(R);for(let mt=0,wt=ot.length;mt<wt;mt++){const bt=ot[mt];Nc(p,R,bt,bt.viewport)}}else G.length>0&&Fc(X,G,R,z),Yt&&Dt.render(R),Nc(p,R,z);M!==null&&(D.updateMultisampleRenderTarget(M),D.updateRenderTargetMipmap(M)),R.isScene===!0&&R.onAfterRender(w,R,z),ce.resetDefaultState(),x=-1,v=null,b.pop(),b.length>0?(d=b[b.length-1],et===!0&&rt.setGlobalState(w.clippingPlanes,d.state.camera)):d=null,y.pop(),y.length>0?p=y[y.length-1]:p=null};function mo(R,z,W,X){if(R.visible===!1)return;if(R.layers.test(z.layers)){if(R.isGroup)W=R.renderOrder;else if(R.isLOD)R.autoUpdate===!0&&R.update(z);else if(R.isLight)d.pushLight(R),R.castShadow&&d.pushShadow(R);else if(R.isSprite){if(!R.frustumCulled||$.intersectsSprite(R)){X&&Vt.setFromMatrixPosition(R.matrixWorld).applyMatrix4(Ct);const mt=Z.update(R),wt=R.material;wt.visible&&p.push(R,mt,wt,W,Vt.z,null)}}else if((R.isMesh||R.isLine||R.isPoints)&&(!R.frustumCulled||$.intersectsObject(R))){const mt=Z.update(R),wt=R.material;if(X&&(R.boundingSphere!==void 0?(R.boundingSphere===null&&R.computeBoundingSphere(),Vt.copy(R.boundingSphere.center)):(mt.boundingSphere===null&&mt.computeBoundingSphere(),Vt.copy(mt.boundingSphere.center)),Vt.applyMatrix4(R.matrixWorld).applyMatrix4(Ct)),Array.isArray(wt)){const bt=mt.groups;for(let Ut=0,Bt=bt.length;Ut<Bt;Ut++){const Et=bt[Ut],Zt=wt[Et.materialIndex];Zt&&Zt.visible&&p.push(R,mt,Zt,W,Vt.z,Et)}}else wt.visible&&p.push(R,mt,wt,W,Vt.z,null)}}const ot=R.children;for(let mt=0,wt=ot.length;mt<wt;mt++)mo(ot[mt],z,W,X)}function Nc(R,z,W,X){const G=R.opaque,ot=R.transmissive,mt=R.transparent;d.setupLightsView(W),et===!0&&rt.setGlobalState(w.clippingPlanes,W),X&&Lt.viewport(E.copy(X)),G.length>0&&or(G,z,W),ot.length>0&&or(ot,z,W),mt.length>0&&or(mt,z,W),Lt.buffers.depth.setTest(!0),Lt.buffers.depth.setMask(!0),Lt.buffers.color.setMask(!0),Lt.setPolygonOffset(!1)}function Fc(R,z,W,X){if((W.isScene===!0?W.overrideMaterial:null)!==null)return;d.state.transmissionRenderTarget[X.id]===void 0&&(d.state.transmissionRenderTarget[X.id]=new Li(1,1,{generateMipmaps:!0,type:Xt.has("EXT_color_buffer_half_float")||Xt.has("EXT_color_buffer_float")?nr:$n,minFilter:Ai,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Kt.workingColorSpace}));const ot=d.state.transmissionRenderTarget[X.id],mt=X.viewport||E;ot.setSize(mt.z,mt.w);const wt=w.getRenderTarget();w.setRenderTarget(ot),w.getClearColor(N),F=w.getClearAlpha(),F<1&&w.setClearColor(16777215,.5),w.clear(),Yt&&Dt.render(W);const bt=w.toneMapping;w.toneMapping=ci;const Ut=X.viewport;if(X.viewport!==void 0&&(X.viewport=void 0),d.setupLightsView(X),et===!0&&rt.setGlobalState(w.clippingPlanes,X),or(R,W,X),D.updateMultisampleRenderTarget(ot),D.updateRenderTargetMipmap(ot),Xt.has("WEBGL_multisampled_render_to_texture")===!1){let Bt=!1;for(let Et=0,Zt=z.length;Et<Zt;Et++){const le=z[Et],ue=le.object,Ze=le.geometry,Qt=le.material,At=le.group;if(Qt.side===ze&&ue.layers.test(X.layers)){const Fn=Qt.side;Qt.side=Qe,Qt.needsUpdate=!0,Oc(ue,W,X,Ze,Qt,At),Qt.side=Fn,Qt.needsUpdate=!0,Bt=!0}}Bt===!0&&(D.updateMultisampleRenderTarget(ot),D.updateRenderTargetMipmap(ot))}w.setRenderTarget(wt),w.setClearColor(N,F),Ut!==void 0&&(X.viewport=Ut),w.toneMapping=bt}function or(R,z,W){const X=z.isScene===!0?z.overrideMaterial:null;for(let G=0,ot=R.length;G<ot;G++){const mt=R[G],wt=mt.object,bt=mt.geometry,Ut=X===null?mt.material:X,Bt=mt.group;wt.layers.test(W.layers)&&Oc(wt,z,W,bt,Ut,Bt)}}function Oc(R,z,W,X,G,ot){R.onBeforeRender(w,z,W,X,G,ot),R.modelViewMatrix.multiplyMatrices(W.matrixWorldInverse,R.matrixWorld),R.normalMatrix.getNormalMatrix(R.modelViewMatrix),G.onBeforeRender(w,z,W,X,R,ot),G.transparent===!0&&G.side===ze&&G.forceSinglePass===!1?(G.side=Qe,G.needsUpdate=!0,w.renderBufferDirect(W,z,X,G,R,ot),G.side=li,G.needsUpdate=!0,w.renderBufferDirect(W,z,X,G,R,ot),G.side=ze):w.renderBufferDirect(W,z,X,G,R,ot),R.onAfterRender(w,z,W,X,G,ot)}function ar(R,z,W){z.isScene!==!0&&(z=ge);const X=Pt.get(R),G=d.state.lights,ot=d.state.shadowsArray,mt=G.state.version,wt=Tt.getParameters(R,G.state,ot,z,W),bt=Tt.getProgramCacheKey(wt);let Ut=X.programs;X.environment=R.isMeshStandardMaterial?z.environment:null,X.fog=z.fog,X.envMap=(R.isMeshStandardMaterial?V:T).get(R.envMap||X.environment),X.envMapRotation=X.environment!==null&&R.envMap===null?z.environmentRotation:R.envMapRotation,Ut===void 0&&(R.addEventListener("dispose",kt),Ut=new Map,X.programs=Ut);let Bt=Ut.get(bt);if(Bt!==void 0){if(X.currentProgram===Bt&&X.lightsStateVersion===mt)return Bc(R,wt),Bt}else wt.uniforms=Tt.getUniforms(R),R.onBeforeCompile(wt,w),Bt=Tt.acquireProgram(wt,bt),Ut.set(bt,Bt),X.uniforms=wt.uniforms;const Et=X.uniforms;return(!R.isShaderMaterial&&!R.isRawShaderMaterial||R.clipping===!0)&&(Et.clippingPlanes=rt.uniform),Bc(R,wt),X.needsLights=sf(R),X.lightsStateVersion=mt,X.needsLights&&(Et.ambientLightColor.value=G.state.ambient,Et.lightProbe.value=G.state.probe,Et.directionalLights.value=G.state.directional,Et.directionalLightShadows.value=G.state.directionalShadow,Et.spotLights.value=G.state.spot,Et.spotLightShadows.value=G.state.spotShadow,Et.rectAreaLights.value=G.state.rectArea,Et.ltc_1.value=G.state.rectAreaLTC1,Et.ltc_2.value=G.state.rectAreaLTC2,Et.pointLights.value=G.state.point,Et.pointLightShadows.value=G.state.pointShadow,Et.hemisphereLights.value=G.state.hemi,Et.directionalShadowMap.value=G.state.directionalShadowMap,Et.directionalShadowMatrix.value=G.state.directionalShadowMatrix,Et.spotShadowMap.value=G.state.spotShadowMap,Et.spotLightMatrix.value=G.state.spotLightMatrix,Et.spotLightMap.value=G.state.spotLightMap,Et.pointShadowMap.value=G.state.pointShadowMap,Et.pointShadowMatrix.value=G.state.pointShadowMatrix),X.currentProgram=Bt,X.uniformsList=null,Bt}function kc(R){if(R.uniformsList===null){const z=R.currentProgram.getUniforms();R.uniformsList=qr.seqWithValue(z.seq,R.uniforms)}return R.uniformsList}function Bc(R,z){const W=Pt.get(R);W.outputColorSpace=z.outputColorSpace,W.batching=z.batching,W.batchingColor=z.batchingColor,W.instancing=z.instancing,W.instancingColor=z.instancingColor,W.instancingMorph=z.instancingMorph,W.skinning=z.skinning,W.morphTargets=z.morphTargets,W.morphNormals=z.morphNormals,W.morphColors=z.morphColors,W.morphTargetsCount=z.morphTargetsCount,W.numClippingPlanes=z.numClippingPlanes,W.numIntersection=z.numClipIntersection,W.vertexAlphas=z.vertexAlphas,W.vertexTangents=z.vertexTangents,W.toneMapping=z.toneMapping}function ef(R,z,W,X,G){z.isScene!==!0&&(z=ge),D.resetTextureUnits();const ot=z.fog,mt=X.isMeshStandardMaterial?z.environment:null,wt=M===null?w.outputColorSpace:M.isXRRenderTarget===!0?M.texture.colorSpace:Ss,bt=(X.isMeshStandardMaterial?V:T).get(X.envMap||mt),Ut=X.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,Bt=!!W.attributes.tangent&&(!!X.normalMap||X.anisotropy>0),Et=!!W.morphAttributes.position,Zt=!!W.morphAttributes.normal,le=!!W.morphAttributes.color;let ue=ci;X.toneMapped&&(M===null||M.isXRRenderTarget===!0)&&(ue=w.toneMapping);const Ze=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,Qt=Ze!==void 0?Ze.length:0,At=Pt.get(X),Fn=d.state.lights;if(et===!0&&(ut===!0||R!==v)){const hn=R===v&&X.id===x;rt.setState(X,R,hn)}let te=!1;X.version===At.__version?(At.needsLights&&At.lightsStateVersion!==Fn.state.version||At.outputColorSpace!==wt||G.isBatchedMesh&&At.batching===!1||!G.isBatchedMesh&&At.batching===!0||G.isBatchedMesh&&At.batchingColor===!0&&G.colorTexture===null||G.isBatchedMesh&&At.batchingColor===!1&&G.colorTexture!==null||G.isInstancedMesh&&At.instancing===!1||!G.isInstancedMesh&&At.instancing===!0||G.isSkinnedMesh&&At.skinning===!1||!G.isSkinnedMesh&&At.skinning===!0||G.isInstancedMesh&&At.instancingColor===!0&&G.instanceColor===null||G.isInstancedMesh&&At.instancingColor===!1&&G.instanceColor!==null||G.isInstancedMesh&&At.instancingMorph===!0&&G.morphTexture===null||G.isInstancedMesh&&At.instancingMorph===!1&&G.morphTexture!==null||At.envMap!==bt||X.fog===!0&&At.fog!==ot||At.numClippingPlanes!==void 0&&(At.numClippingPlanes!==rt.numPlanes||At.numIntersection!==rt.numIntersection)||At.vertexAlphas!==Ut||At.vertexTangents!==Bt||At.morphTargets!==Et||At.morphNormals!==Zt||At.morphColors!==le||At.toneMapping!==ue||At.morphTargetsCount!==Qt)&&(te=!0):(te=!0,At.__version=X.version);let mn=At.currentProgram;te===!0&&(mn=ar(X,z,G));let Fi=!1,sn=!1,As=!1;const fe=mn.getUniforms(),En=At.uniforms;if(Lt.useProgram(mn.program)&&(Fi=!0,sn=!0,As=!0),X.id!==x&&(x=X.id,sn=!0),Fi||v!==R){Lt.buffers.depth.getReversed()?(at.copy(R.projectionMatrix),Hd(at),Vd(at),fe.setValue(H,"projectionMatrix",at)):fe.setValue(H,"projectionMatrix",R.projectionMatrix),fe.setValue(H,"viewMatrix",R.matrixWorldInverse);const Yn=fe.map.cameraPosition;Yn!==void 0&&Yn.setValue(H,Ot.setFromMatrixPosition(R.matrixWorld)),$t.logarithmicDepthBuffer&&fe.setValue(H,"logDepthBufFC",2/(Math.log(R.far+1)/Math.LN2)),(X.isMeshPhongMaterial||X.isMeshToonMaterial||X.isMeshLambertMaterial||X.isMeshBasicMaterial||X.isMeshStandardMaterial||X.isShaderMaterial)&&fe.setValue(H,"isOrthographic",R.isOrthographicCamera===!0),v!==R&&(v=R,sn=!0,As=!0)}if(G.isSkinnedMesh){fe.setOptional(H,G,"bindMatrix"),fe.setOptional(H,G,"bindMatrixInverse");const hn=G.skeleton;hn&&(hn.boneTexture===null&&hn.computeBoneTexture(),fe.setValue(H,"boneTexture",hn.boneTexture,D))}G.isBatchedMesh&&(fe.setOptional(H,G,"batchingTexture"),fe.setValue(H,"batchingTexture",G._matricesTexture,D),fe.setOptional(H,G,"batchingIdTexture"),fe.setValue(H,"batchingIdTexture",G._indirectTexture,D),fe.setOptional(H,G,"batchingColorTexture"),G._colorsTexture!==null&&fe.setValue(H,"batchingColorTexture",G._colorsTexture,D));const Rs=W.morphAttributes;if((Rs.position!==void 0||Rs.normal!==void 0||Rs.color!==void 0)&&It.update(G,W,mn),(sn||At.receiveShadow!==G.receiveShadow)&&(At.receiveShadow=G.receiveShadow,fe.setValue(H,"receiveShadow",G.receiveShadow)),X.isMeshGouraudMaterial&&X.envMap!==null&&(En.envMap.value=bt,En.flipEnvMap.value=bt.isCubeTexture&&bt.isRenderTargetTexture===!1?-1:1),X.isMeshStandardMaterial&&X.envMap===null&&z.environment!==null&&(En.envMapIntensity.value=z.environmentIntensity),sn&&(fe.setValue(H,"toneMappingExposure",w.toneMappingExposure),At.needsLights&&nf(En,As),ot&&X.fog===!0&&dt.refreshFogUniforms(En,ot),dt.refreshMaterialUniforms(En,X,k,O,d.state.transmissionRenderTarget[R.id]),qr.upload(H,kc(At),En,D)),X.isShaderMaterial&&X.uniformsNeedUpdate===!0&&(qr.upload(H,kc(At),En,D),X.uniformsNeedUpdate=!1),X.isSpriteMaterial&&fe.setValue(H,"center",G.center),fe.setValue(H,"modelViewMatrix",G.modelViewMatrix),fe.setValue(H,"normalMatrix",G.normalMatrix),fe.setValue(H,"modelMatrix",G.matrixWorld),X.isShaderMaterial||X.isRawShaderMaterial){const hn=X.uniformsGroups;for(let Yn=0,jn=hn.length;Yn<jn;Yn++){const zc=hn[Yn];B.update(zc,mn),B.bind(zc,mn)}}return mn}function nf(R,z){R.ambientLightColor.needsUpdate=z,R.lightProbe.needsUpdate=z,R.directionalLights.needsUpdate=z,R.directionalLightShadows.needsUpdate=z,R.pointLights.needsUpdate=z,R.pointLightShadows.needsUpdate=z,R.spotLights.needsUpdate=z,R.spotLightShadows.needsUpdate=z,R.rectAreaLights.needsUpdate=z,R.hemisphereLights.needsUpdate=z}function sf(R){return R.isMeshLambertMaterial||R.isMeshToonMaterial||R.isMeshPhongMaterial||R.isMeshStandardMaterial||R.isShadowMaterial||R.isShaderMaterial&&R.lights===!0}this.getActiveCubeFace=function(){return A},this.getActiveMipmapLevel=function(){return S},this.getRenderTarget=function(){return M},this.setRenderTargetTextures=function(R,z,W){Pt.get(R.texture).__webglTexture=z,Pt.get(R.depthTexture).__webglTexture=W;const X=Pt.get(R);X.__hasExternalTextures=!0,X.__autoAllocateDepthBuffer=W===void 0,X.__autoAllocateDepthBuffer||Xt.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),X.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(R,z){const W=Pt.get(R);W.__webglFramebuffer=z,W.__useDefaultFramebuffer=z===void 0},this.setRenderTarget=function(R,z=0,W=0){M=R,A=z,S=W;let X=!0,G=null,ot=!1,mt=!1;if(R){const bt=Pt.get(R);if(bt.__useDefaultFramebuffer!==void 0)Lt.bindFramebuffer(H.FRAMEBUFFER,null),X=!1;else if(bt.__webglFramebuffer===void 0)D.setupRenderTarget(R);else if(bt.__hasExternalTextures)D.rebindTextures(R,Pt.get(R.texture).__webglTexture,Pt.get(R.depthTexture).__webglTexture);else if(R.depthBuffer){const Et=R.depthTexture;if(bt.__boundDepthTexture!==Et){if(Et!==null&&Pt.has(Et)&&(R.width!==Et.image.width||R.height!==Et.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");D.setupDepthRenderbuffer(R)}}const Ut=R.texture;(Ut.isData3DTexture||Ut.isDataArrayTexture||Ut.isCompressedArrayTexture)&&(mt=!0);const Bt=Pt.get(R).__webglFramebuffer;R.isWebGLCubeRenderTarget?(Array.isArray(Bt[z])?G=Bt[z][W]:G=Bt[z],ot=!0):R.samples>0&&D.useMultisampledRTT(R)===!1?G=Pt.get(R).__webglMultisampledFramebuffer:Array.isArray(Bt)?G=Bt[W]:G=Bt,E.copy(R.viewport),P.copy(R.scissor),L=R.scissorTest}else E.copy(it).multiplyScalar(k).floor(),P.copy(ct).multiplyScalar(k).floor(),L=xt;if(Lt.bindFramebuffer(H.FRAMEBUFFER,G)&&X&&Lt.drawBuffers(R,G),Lt.viewport(E),Lt.scissor(P),Lt.setScissorTest(L),ot){const bt=Pt.get(R.texture);H.framebufferTexture2D(H.FRAMEBUFFER,H.COLOR_ATTACHMENT0,H.TEXTURE_CUBE_MAP_POSITIVE_X+z,bt.__webglTexture,W)}else if(mt){const bt=Pt.get(R.texture),Ut=z||0;H.framebufferTextureLayer(H.FRAMEBUFFER,H.COLOR_ATTACHMENT0,bt.__webglTexture,W||0,Ut)}x=-1},this.readRenderTargetPixels=function(R,z,W,X,G,ot,mt){if(!(R&&R.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let wt=Pt.get(R).__webglFramebuffer;if(R.isWebGLCubeRenderTarget&&mt!==void 0&&(wt=wt[mt]),wt){Lt.bindFramebuffer(H.FRAMEBUFFER,wt);try{const bt=R.texture,Ut=bt.format,Bt=bt.type;if(!$t.textureFormatReadable(Ut)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!$t.textureTypeReadable(Bt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}z>=0&&z<=R.width-X&&W>=0&&W<=R.height-G&&H.readPixels(z,W,X,G,Gt.convert(Ut),Gt.convert(Bt),ot)}finally{const bt=M!==null?Pt.get(M).__webglFramebuffer:null;Lt.bindFramebuffer(H.FRAMEBUFFER,bt)}}},this.readRenderTargetPixelsAsync=async function(R,z,W,X,G,ot,mt){if(!(R&&R.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let wt=Pt.get(R).__webglFramebuffer;if(R.isWebGLCubeRenderTarget&&mt!==void 0&&(wt=wt[mt]),wt){const bt=R.texture,Ut=bt.format,Bt=bt.type;if(!$t.textureFormatReadable(Ut))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!$t.textureTypeReadable(Bt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(z>=0&&z<=R.width-X&&W>=0&&W<=R.height-G){Lt.bindFramebuffer(H.FRAMEBUFFER,wt);const Et=H.createBuffer();H.bindBuffer(H.PIXEL_PACK_BUFFER,Et),H.bufferData(H.PIXEL_PACK_BUFFER,ot.byteLength,H.STREAM_READ),H.readPixels(z,W,X,G,Gt.convert(Ut),Gt.convert(Bt),0);const Zt=M!==null?Pt.get(M).__webglFramebuffer:null;Lt.bindFramebuffer(H.FRAMEBUFFER,Zt);const le=H.fenceSync(H.SYNC_GPU_COMMANDS_COMPLETE,0);return H.flush(),await Gd(H,le,4),H.bindBuffer(H.PIXEL_PACK_BUFFER,Et),H.getBufferSubData(H.PIXEL_PACK_BUFFER,0,ot),H.deleteBuffer(Et),H.deleteSync(le),ot}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(R,z=null,W=0){R.isTexture!==!0&&(Gs("WebGLRenderer: copyFramebufferToTexture function signature has changed."),z=arguments[0]||null,R=arguments[1]);const X=Math.pow(2,-W),G=Math.floor(R.image.width*X),ot=Math.floor(R.image.height*X),mt=z!==null?z.x:0,wt=z!==null?z.y:0;D.setTexture2D(R,0),H.copyTexSubImage2D(H.TEXTURE_2D,W,0,0,mt,wt,G,ot),Lt.unbindTexture()},this.copyTextureToTexture=function(R,z,W=null,X=null,G=0){R.isTexture!==!0&&(Gs("WebGLRenderer: copyTextureToTexture function signature has changed."),X=arguments[0]||null,R=arguments[1],z=arguments[2],G=arguments[3]||0,W=null);let ot,mt,wt,bt,Ut,Bt,Et,Zt,le;const ue=R.isCompressedTexture?R.mipmaps[G]:R.image;W!==null?(ot=W.max.x-W.min.x,mt=W.max.y-W.min.y,wt=W.isBox3?W.max.z-W.min.z:1,bt=W.min.x,Ut=W.min.y,Bt=W.isBox3?W.min.z:0):(ot=ue.width,mt=ue.height,wt=ue.depth||1,bt=0,Ut=0,Bt=0),X!==null?(Et=X.x,Zt=X.y,le=X.z):(Et=0,Zt=0,le=0);const Ze=Gt.convert(z.format),Qt=Gt.convert(z.type);let At;z.isData3DTexture?(D.setTexture3D(z,0),At=H.TEXTURE_3D):z.isDataArrayTexture||z.isCompressedArrayTexture?(D.setTexture2DArray(z,0),At=H.TEXTURE_2D_ARRAY):(D.setTexture2D(z,0),At=H.TEXTURE_2D),H.pixelStorei(H.UNPACK_FLIP_Y_WEBGL,z.flipY),H.pixelStorei(H.UNPACK_PREMULTIPLY_ALPHA_WEBGL,z.premultiplyAlpha),H.pixelStorei(H.UNPACK_ALIGNMENT,z.unpackAlignment);const Fn=H.getParameter(H.UNPACK_ROW_LENGTH),te=H.getParameter(H.UNPACK_IMAGE_HEIGHT),mn=H.getParameter(H.UNPACK_SKIP_PIXELS),Fi=H.getParameter(H.UNPACK_SKIP_ROWS),sn=H.getParameter(H.UNPACK_SKIP_IMAGES);H.pixelStorei(H.UNPACK_ROW_LENGTH,ue.width),H.pixelStorei(H.UNPACK_IMAGE_HEIGHT,ue.height),H.pixelStorei(H.UNPACK_SKIP_PIXELS,bt),H.pixelStorei(H.UNPACK_SKIP_ROWS,Ut),H.pixelStorei(H.UNPACK_SKIP_IMAGES,Bt);const As=R.isDataArrayTexture||R.isData3DTexture,fe=z.isDataArrayTexture||z.isData3DTexture;if(R.isRenderTargetTexture||R.isDepthTexture){const En=Pt.get(R),Rs=Pt.get(z),hn=Pt.get(En.__renderTarget),Yn=Pt.get(Rs.__renderTarget);Lt.bindFramebuffer(H.READ_FRAMEBUFFER,hn.__webglFramebuffer),Lt.bindFramebuffer(H.DRAW_FRAMEBUFFER,Yn.__webglFramebuffer);for(let jn=0;jn<wt;jn++)As&&H.framebufferTextureLayer(H.READ_FRAMEBUFFER,H.COLOR_ATTACHMENT0,Pt.get(R).__webglTexture,G,Bt+jn),R.isDepthTexture?(fe&&H.framebufferTextureLayer(H.DRAW_FRAMEBUFFER,H.COLOR_ATTACHMENT0,Pt.get(z).__webglTexture,G,le+jn),H.blitFramebuffer(bt,Ut,ot,mt,Et,Zt,ot,mt,H.DEPTH_BUFFER_BIT,H.NEAREST)):fe?H.copyTexSubImage3D(At,G,Et,Zt,le+jn,bt,Ut,ot,mt):H.copyTexSubImage2D(At,G,Et,Zt,le+jn,bt,Ut,ot,mt);Lt.bindFramebuffer(H.READ_FRAMEBUFFER,null),Lt.bindFramebuffer(H.DRAW_FRAMEBUFFER,null)}else fe?R.isDataTexture||R.isData3DTexture?H.texSubImage3D(At,G,Et,Zt,le,ot,mt,wt,Ze,Qt,ue.data):z.isCompressedArrayTexture?H.compressedTexSubImage3D(At,G,Et,Zt,le,ot,mt,wt,Ze,ue.data):H.texSubImage3D(At,G,Et,Zt,le,ot,mt,wt,Ze,Qt,ue):R.isDataTexture?H.texSubImage2D(H.TEXTURE_2D,G,Et,Zt,ot,mt,Ze,Qt,ue.data):R.isCompressedTexture?H.compressedTexSubImage2D(H.TEXTURE_2D,G,Et,Zt,ue.width,ue.height,Ze,ue.data):H.texSubImage2D(H.TEXTURE_2D,G,Et,Zt,ot,mt,Ze,Qt,ue);H.pixelStorei(H.UNPACK_ROW_LENGTH,Fn),H.pixelStorei(H.UNPACK_IMAGE_HEIGHT,te),H.pixelStorei(H.UNPACK_SKIP_PIXELS,mn),H.pixelStorei(H.UNPACK_SKIP_ROWS,Fi),H.pixelStorei(H.UNPACK_SKIP_IMAGES,sn),G===0&&z.generateMipmaps&&H.generateMipmap(At),Lt.unbindTexture()},this.copyTextureToTexture3D=function(R,z,W=null,X=null,G=0){return R.isTexture!==!0&&(Gs("WebGLRenderer: copyTextureToTexture3D function signature has changed."),W=arguments[0]||null,X=arguments[1]||null,R=arguments[2],z=arguments[3],G=arguments[4]||0),Gs('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(R,z,W,X,G)},this.initRenderTarget=function(R){Pt.get(R).__webglFramebuffer===void 0&&D.setupRenderTarget(R)},this.initTexture=function(R){R.isCubeTexture?D.setTextureCube(R,0):R.isData3DTexture?D.setTexture3D(R,0):R.isDataArrayTexture||R.isCompressedArrayTexture?D.setTexture2DArray(R,0):D.setTexture2D(R,0),Lt.unbindTexture()},this.resetState=function(){A=0,S=0,M=null,Lt.reset(),ce.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Vn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const e=this.getContext();e.drawingBufferColorspace=Kt._getDrawingBufferColorSpace(t),e.unpackColorSpace=Kt._getUnpackColorSpace()}}class co{constructor(t,e=1,n=1e3){this.isFog=!0,this.name="",this.color=new _t(t),this.near=e,this.far=n}clone(){return new co(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}}class _c extends we{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Dn,this.environmentIntensity=1,this.environmentRotation=new Dn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(e.object.environmentIntensity=this.environmentIntensity),e.object.environmentRotation=this.environmentRotation.toArray(),e}}class J_{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=$a,this.updateRanges=[],this.version=0,this.uuid=Wn()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,n){t*=this.stride,n*=e.stride;for(let s=0,r=this.stride;s<r;s++)this.array[t+s]=e.array[n+s];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Wn()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(e,this.stride);return n.setUsage(this.usage),n}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Wn()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const $e=new I;class Jr{constructor(t,e,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=n,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,n=this.data.count;e<n;e++)$e.fromBufferAttribute(this,e),$e.applyMatrix4(t),this.setXYZ(e,$e.x,$e.y,$e.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)$e.fromBufferAttribute(this,e),$e.applyNormalMatrix(t),this.setXYZ(e,$e.x,$e.y,$e.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)$e.fromBufferAttribute(this,e),$e.transformDirection(t),this.setXYZ(e,$e.x,$e.y,$e.z);return this}getComponent(t,e){let n=this.array[t*this.data.stride+this.offset+e];return this.normalized&&(n=yn(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=se(n,this.array)),this.data.array[t*this.data.stride+this.offset+e]=n,this}setX(t,e){return this.normalized&&(e=se(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=se(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=se(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=se(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=yn(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=yn(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=yn(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=yn(e,this.array)),e}setXY(t,e,n){return t=t*this.data.stride+this.offset,this.normalized&&(e=se(e,this.array),n=se(n,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this}setXYZ(t,e,n,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=se(e,this.array),n=se(n,this.array),s=se(s,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t=t*this.data.stride+this.offset,this.normalized&&(e=se(e,this.array),n=se(n,this.array),s=se(s,this.array),r=se(r,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this.data.array[t+3]=r,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return new ve(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new Jr(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class _u extends fi{static get type(){return"SpriteMaterial"}constructor(t){super(),this.isSpriteMaterial=!0,this.color=new _t(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}let Zi;const Is=new I,Ji=new I,Qi=new I,ts=new Ft,Us=new Ft,xu=new Wt,Pr=new I,Ns=new I,Lr=new I,$l=new Ft,qo=new Ft,ql=new Ft;class Q_ extends we{constructor(t=new _u){if(super(),this.isSprite=!0,this.type="Sprite",Zi===void 0){Zi=new Me;const e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new J_(e,5);Zi.setIndex([0,1,2,0,2,3]),Zi.setAttribute("position",new Jr(n,3,0,!1)),Zi.setAttribute("uv",new Jr(n,2,3,!1))}this.geometry=Zi,this.material=t,this.center=new Ft(.5,.5)}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Ji.setFromMatrixScale(this.matrixWorld),xu.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),Qi.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Ji.multiplyScalar(-Qi.z);const n=this.material.rotation;let s,r;n!==0&&(r=Math.cos(n),s=Math.sin(n));const o=this.center;Dr(Pr.set(-.5,-.5,0),Qi,o,Ji,s,r),Dr(Ns.set(.5,-.5,0),Qi,o,Ji,s,r),Dr(Lr.set(.5,.5,0),Qi,o,Ji,s,r),$l.set(0,0),qo.set(1,0),ql.set(1,1);let a=t.ray.intersectTriangle(Pr,Ns,Lr,!1,Is);if(a===null&&(Dr(Ns.set(-.5,.5,0),Qi,o,Ji,s,r),qo.set(0,1),a=t.ray.intersectTriangle(Pr,Lr,Ns,!1,Is),a===null))return;const c=t.ray.origin.distanceTo(Is);c<t.near||c>t.far||e.push({distance:c,point:Is.clone(),uv:dn.getInterpolation(Is,Pr,Ns,Lr,$l,qo,ql,new Ft),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}}function Dr(i,t,e,n,s,r){ts.subVectors(i,e).addScalar(.5).multiply(n),s!==void 0?(Us.x=r*ts.x-s*ts.y,Us.y=s*ts.x+r*ts.y):Us.copy(ts),i.copy(t),i.x+=Us.x,i.y+=Us.y,i.applyMatrix4(xu)}class tx extends Xe{constructor(t=null,e=1,n=1,s,r,o,a,c,l=tn,h=tn,u,f){super(null,o,a,c,l,h,s,r,u,f),this.isDataTexture=!0,this.image={data:t,width:e,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Yl extends ve{constructor(t,e,n,s=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){const t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}}const es=new Wt,jl=new Wt,Ir=[],Kl=new Ii,ex=new Wt,Fs=new tt,Os=new Ui;class Re extends tt{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new Yl(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,ex)}computeBoundingBox(){const t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new Ii),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,es),Kl.copy(t.boundingBox).applyMatrix4(es),this.boundingBox.union(Kl)}computeBoundingSphere(){const t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Ui),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,es),Os.copy(t.boundingSphere).applyMatrix4(es),this.boundingSphere.union(Os)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.morphTexture!==null&&(this.morphTexture=t.morphTexture.clone()),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){const n=e.morphTargetInfluences,s=this.morphTexture.source.data.data,r=n.length+1,o=t*r+1;for(let a=0;a<n.length;a++)n[a]=s[o+a]}raycast(t,e){const n=this.matrixWorld,s=this.count;if(Fs.geometry=this.geometry,Fs.material=this.material,Fs.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Os.copy(this.boundingSphere),Os.applyMatrix4(n),t.ray.intersectsSphere(Os)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,es),jl.multiplyMatrices(n,es),Fs.matrixWorld=jl,Fs.raycast(t,Ir);for(let o=0,a=Ir.length;o<a;o++){const c=Ir[o];c.instanceId=r,c.object=this,e.push(c)}Ir.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new Yl(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}setMorphAt(t,e){const n=e.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new tx(new Float32Array(s*this.count),s,this.count,lc,Cn));const r=this.morphTexture.source.data.data;let o=0;for(let l=0;l<n.length;l++)o+=n[l];const a=this.geometry.morphTargetsRelative?1:1-o,c=s*t;r[c]=a,r.set(n,c+1)}updateMorphTargets(){}dispose(){return this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null),this}}class vu extends fi{static get type(){return"LineBasicMaterial"}constructor(t){super(),this.isLineBasicMaterial=!0,this.color=new _t(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}}const Qr=new I,to=new I,Zl=new Wt,ks=new pc,Ur=new Ui,Yo=new I,Jl=new I;class nx extends we{constructor(t=new Me,e=new vu){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[0];for(let s=1,r=e.count;s<r;s++)Qr.fromBufferAttribute(e,s-1),to.fromBufferAttribute(e,s),n[s]=n[s-1],n[s]+=Qr.distanceTo(to);t.setAttribute("lineDistance",new re(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(t,e){const n=this.geometry,s=this.matrixWorld,r=t.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ur.copy(n.boundingSphere),Ur.applyMatrix4(s),Ur.radius+=r,t.ray.intersectsSphere(Ur)===!1)return;Zl.copy(s).invert(),ks.copy(t.ray).applyMatrix4(Zl);const a=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=a*a,l=this.isLineSegments?2:1,h=n.index,f=n.attributes.position;if(h!==null){const m=Math.max(0,o.start),g=Math.min(h.count,o.start+o.count);for(let _=m,p=g-1;_<p;_+=l){const d=h.getX(_),y=h.getX(_+1),b=Nr(this,t,ks,c,d,y);b&&e.push(b)}if(this.isLineLoop){const _=h.getX(g-1),p=h.getX(m),d=Nr(this,t,ks,c,_,p);d&&e.push(d)}}else{const m=Math.max(0,o.start),g=Math.min(f.count,o.start+o.count);for(let _=m,p=g-1;_<p;_+=l){const d=Nr(this,t,ks,c,_,_+1);d&&e.push(d)}if(this.isLineLoop){const _=Nr(this,t,ks,c,g-1,m);_&&e.push(_)}}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){const a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}}function Nr(i,t,e,n,s,r){const o=i.geometry.attributes.position;if(Qr.fromBufferAttribute(o,s),to.fromBufferAttribute(o,r),e.distanceSqToSegment(Qr,to,Yo,Jl)>n)return;Yo.applyMatrix4(i.matrixWorld);const c=t.ray.origin.distanceTo(Yo);if(!(c<t.near||c>t.far))return{distance:c,point:Jl.clone().applyMatrix4(i.matrixWorld),index:s,face:null,faceIndex:null,barycoord:null,object:i}}const Ql=new I,th=new I;class ix extends nx{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[];for(let s=0,r=e.count;s<r;s+=2)Ql.fromBufferAttribute(e,s),th.fromBufferAttribute(e,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+Ql.distanceTo(th);t.setAttribute("lineDistance",new re(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class xc extends fi{static get type(){return"PointsMaterial"}constructor(t){super(),this.isPointsMaterial=!0,this.color=new _t(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const eh=new Wt,Ya=new pc,Fr=new Ui,Or=new I;class Mu extends we{constructor(t=new Me,e=new xc){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){const n=this.geometry,s=this.matrixWorld,r=t.params.Points.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Fr.copy(n.boundingSphere),Fr.applyMatrix4(s),Fr.radius+=r,t.ray.intersectsSphere(Fr)===!1)return;eh.copy(s).invert(),Ya.copy(t.ray).applyMatrix4(eh);const a=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=a*a,l=n.index,u=n.attributes.position;if(l!==null){const f=Math.max(0,o.start),m=Math.min(l.count,o.start+o.count);for(let g=f,_=m;g<_;g++){const p=l.getX(g);Or.fromBufferAttribute(u,p),nh(Or,p,c,s,t,e,this)}}else{const f=Math.max(0,o.start),m=Math.min(u.count,o.start+o.count);for(let g=f,_=m;g<_;g++)Or.fromBufferAttribute(u,g),nh(Or,g,c,s,t,e,this)}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){const a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}}function nh(i,t,e,n,s,r,o){const a=Ya.distanceSqToPoint(i);if(a<e){const c=new I;Ya.closestPointToPoint(i,c),c.applyMatrix4(n);const l=s.ray.origin.distanceTo(c);if(l<s.near||l>s.far)return;r.push({distance:l,distanceToRay:Math.sqrt(a),point:c,index:t,face:null,faceIndex:null,barycoord:null,object:o})}}class Ni extends Xe{constructor(t,e,n,s,r,o,a,c,l){super(t,e,n,s,r,o,a,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}}class lo extends Me{constructor(t=1,e=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:s},e=Math.max(3,e);const r=[],o=[],a=[],c=[],l=new I,h=new Ft;o.push(0,0,0),a.push(0,0,1),c.push(.5,.5);for(let u=0,f=3;u<=e;u++,f+=3){const m=n+u/e*s;l.x=t*Math.cos(m),l.y=t*Math.sin(m),o.push(l.x,l.y,l.z),a.push(0,0,1),h.x=(o[f]/t+1)/2,h.y=(o[f+1]/t+1)/2,c.push(h.x,h.y)}for(let u=1;u<=e;u++)r.push(u,u+1,0);this.setIndex(r),this.setAttribute("position",new re(o,3)),this.setAttribute("normal",new re(a,3)),this.setAttribute("uv",new re(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new lo(t.radius,t.segments,t.thetaStart,t.thetaLength)}}class xe extends Me{constructor(t=1,e=1,n=1,s=32,r=1,o=!1,a=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:s,heightSegments:r,openEnded:o,thetaStart:a,thetaLength:c};const l=this;s=Math.floor(s),r=Math.floor(r);const h=[],u=[],f=[],m=[];let g=0;const _=[],p=n/2;let d=0;y(),o===!1&&(t>0&&b(!0),e>0&&b(!1)),this.setIndex(h),this.setAttribute("position",new re(u,3)),this.setAttribute("normal",new re(f,3)),this.setAttribute("uv",new re(m,2));function y(){const w=new I,C=new I;let A=0;const S=(e-t)/n;for(let M=0;M<=r;M++){const x=[],v=M/r,E=v*(e-t)+t;for(let P=0;P<=s;P++){const L=P/s,N=L*c+a,F=Math.sin(N),U=Math.cos(N);C.x=E*F,C.y=-v*n+p,C.z=E*U,u.push(C.x,C.y,C.z),w.set(F,S,U).normalize(),f.push(w.x,w.y,w.z),m.push(L,1-v),x.push(g++)}_.push(x)}for(let M=0;M<s;M++)for(let x=0;x<r;x++){const v=_[x][M],E=_[x+1][M],P=_[x+1][M+1],L=_[x][M+1];(t>0||x!==0)&&(h.push(v,E,L),A+=3),(e>0||x!==r-1)&&(h.push(E,P,L),A+=3)}l.addGroup(d,A,0),d+=A}function b(w){const C=g,A=new Ft,S=new I;let M=0;const x=w===!0?t:e,v=w===!0?1:-1;for(let P=1;P<=s;P++)u.push(0,p*v,0),f.push(0,v,0),m.push(.5,.5),g++;const E=g;for(let P=0;P<=s;P++){const N=P/s*c+a,F=Math.cos(N),U=Math.sin(N);S.x=x*U,S.y=p*v,S.z=x*F,u.push(S.x,S.y,S.z),f.push(0,v,0),A.x=F*.5+.5,A.y=U*.5*v+.5,m.push(A.x,A.y),g++}for(let P=0;P<s;P++){const L=C+P,N=E+P;w===!0?h.push(N,N+1,L):h.push(N+1,N,L),M+=3}l.addGroup(d,M,w===!0?1:2),d+=M}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new xe(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class bn extends xe{constructor(t=1,e=1,n=32,s=1,r=!1,o=0,a=Math.PI*2){super(0,t,e,n,s,r,o,a),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:n,heightSegments:s,openEnded:r,thetaStart:o,thetaLength:a}}static fromJSON(t){return new bn(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class ir extends Me{constructor(t=[],e=[],n=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:n,detail:s};const r=[],o=[];a(s),l(n),h(),this.setAttribute("position",new re(r,3)),this.setAttribute("normal",new re(r.slice(),3)),this.setAttribute("uv",new re(o,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function a(y){const b=new I,w=new I,C=new I;for(let A=0;A<e.length;A+=3)m(e[A+0],b),m(e[A+1],w),m(e[A+2],C),c(b,w,C,y)}function c(y,b,w,C){const A=C+1,S=[];for(let M=0;M<=A;M++){S[M]=[];const x=y.clone().lerp(w,M/A),v=b.clone().lerp(w,M/A),E=A-M;for(let P=0;P<=E;P++)P===0&&M===A?S[M][P]=x:S[M][P]=x.clone().lerp(v,P/E)}for(let M=0;M<A;M++)for(let x=0;x<2*(A-M)-1;x++){const v=Math.floor(x/2);x%2===0?(f(S[M][v+1]),f(S[M+1][v]),f(S[M][v])):(f(S[M][v+1]),f(S[M+1][v+1]),f(S[M+1][v]))}}function l(y){const b=new I;for(let w=0;w<r.length;w+=3)b.x=r[w+0],b.y=r[w+1],b.z=r[w+2],b.normalize().multiplyScalar(y),r[w+0]=b.x,r[w+1]=b.y,r[w+2]=b.z}function h(){const y=new I;for(let b=0;b<r.length;b+=3){y.x=r[b+0],y.y=r[b+1],y.z=r[b+2];const w=p(y)/2/Math.PI+.5,C=d(y)/Math.PI+.5;o.push(w,1-C)}g(),u()}function u(){for(let y=0;y<o.length;y+=6){const b=o[y+0],w=o[y+2],C=o[y+4],A=Math.max(b,w,C),S=Math.min(b,w,C);A>.9&&S<.1&&(b<.2&&(o[y+0]+=1),w<.2&&(o[y+2]+=1),C<.2&&(o[y+4]+=1))}}function f(y){r.push(y.x,y.y,y.z)}function m(y,b){const w=y*3;b.x=t[w+0],b.y=t[w+1],b.z=t[w+2]}function g(){const y=new I,b=new I,w=new I,C=new I,A=new Ft,S=new Ft,M=new Ft;for(let x=0,v=0;x<r.length;x+=9,v+=6){y.set(r[x+0],r[x+1],r[x+2]),b.set(r[x+3],r[x+4],r[x+5]),w.set(r[x+6],r[x+7],r[x+8]),A.set(o[v+0],o[v+1]),S.set(o[v+2],o[v+3]),M.set(o[v+4],o[v+5]),C.copy(y).add(b).add(w).divideScalar(3);const E=p(C);_(A,v+0,y,E),_(S,v+2,b,E),_(M,v+4,w,E)}}function _(y,b,w,C){C<0&&y.x===1&&(o[b]=y.x-1),w.x===0&&w.z===0&&(o[b]=C/2/Math.PI+.5)}function p(y){return Math.atan2(y.z,-y.x)}function d(y){return Math.atan2(-y.y,Math.sqrt(y.x*y.x+y.z*y.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ir(t.vertices,t.indices,t.radius,t.details)}}class eo extends ir{constructor(t=1,e=0){const n=(1+Math.sqrt(5))/2,s=1/n,r=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-s,-n,0,-s,n,0,s,-n,0,s,n,-s,-n,0,-s,n,0,s,-n,0,s,n,0,-n,0,-s,n,0,-s,-n,0,s,n,0,s],o=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(r,o,t,e),this.type="DodecahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new eo(t.radius,t.detail)}}class Es extends ir{constructor(t=1,e=0){const n=(1+Math.sqrt(5))/2,s=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Es(t.radius,t.detail)}}class vc extends ir{constructor(t=1,e=0){const n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],s=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,s,t,e),this.type="OctahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new vc(t.radius,t.detail)}}class Mc extends Me{constructor(t=.5,e=1,n=32,s=1,r=0,o=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:n,phiSegments:s,thetaStart:r,thetaLength:o},n=Math.max(3,n),s=Math.max(1,s);const a=[],c=[],l=[],h=[];let u=t;const f=(e-t)/s,m=new I,g=new Ft;for(let _=0;_<=s;_++){for(let p=0;p<=n;p++){const d=r+p/n*o;m.x=u*Math.cos(d),m.y=u*Math.sin(d),c.push(m.x,m.y,m.z),l.push(0,0,1),g.x=(m.x/e+1)/2,g.y=(m.y/e+1)/2,h.push(g.x,g.y)}u+=f}for(let _=0;_<s;_++){const p=_*(n+1);for(let d=0;d<n;d++){const y=d+p,b=y,w=y+n+1,C=y+n+2,A=y+1;a.push(b,w,A),a.push(w,C,A)}}this.setIndex(a),this.setAttribute("position",new re(c,3)),this.setAttribute("normal",new re(l,3)),this.setAttribute("uv",new re(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Mc(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}}class Ce extends Me{constructor(t=1,e=32,n=16,s=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:s,phiLength:r,thetaStart:o,thetaLength:a},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));const c=Math.min(o+a,Math.PI);let l=0;const h=[],u=new I,f=new I,m=[],g=[],_=[],p=[];for(let d=0;d<=n;d++){const y=[],b=d/n;let w=0;d===0&&o===0?w=.5/e:d===n&&c===Math.PI&&(w=-.5/e);for(let C=0;C<=e;C++){const A=C/e;u.x=-t*Math.cos(s+A*r)*Math.sin(o+b*a),u.y=t*Math.cos(o+b*a),u.z=t*Math.sin(s+A*r)*Math.sin(o+b*a),g.push(u.x,u.y,u.z),f.copy(u).normalize(),_.push(f.x,f.y,f.z),p.push(A+w,1-b),y.push(l++)}h.push(y)}for(let d=0;d<n;d++)for(let y=0;y<e;y++){const b=h[d][y+1],w=h[d][y],C=h[d+1][y],A=h[d+1][y+1];(d!==0||o>0)&&m.push(b,w,A),(d!==n-1||c<Math.PI)&&m.push(w,C,A)}this.setIndex(m),this.setAttribute("position",new re(g,3)),this.setAttribute("normal",new re(_,3)),this.setAttribute("uv",new re(p,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Ce(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class ho extends Me{constructor(t=1,e=.4,n=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:n,tubularSegments:s,arc:r},n=Math.floor(n),s=Math.floor(s);const o=[],a=[],c=[],l=[],h=new I,u=new I,f=new I;for(let m=0;m<=n;m++)for(let g=0;g<=s;g++){const _=g/s*r,p=m/n*Math.PI*2;u.x=(t+e*Math.cos(p))*Math.cos(_),u.y=(t+e*Math.cos(p))*Math.sin(_),u.z=e*Math.sin(p),a.push(u.x,u.y,u.z),h.x=t*Math.cos(_),h.y=t*Math.sin(_),f.subVectors(u,h).normalize(),c.push(f.x,f.y,f.z),l.push(g/s),l.push(m/n)}for(let m=1;m<=n;m++)for(let g=1;g<=s;g++){const _=(s+1)*m+g-1,p=(s+1)*(m-1)+g-1,d=(s+1)*(m-1)+g,y=(s+1)*m+g;o.push(_,p,y),o.push(p,d,y)}this.setIndex(o),this.setAttribute("position",new re(a,3)),this.setAttribute("normal",new re(c,3)),this.setAttribute("uv",new re(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ho(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}}class Ue extends fi{static get type(){return"MeshLambertMaterial"}constructor(t){super(),this.isMeshLambertMaterial=!0,this.color=new _t(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new _t(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Kh,this.normalScale=new Ft(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Dn,this.combine=rc,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class yc extends we{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new _t(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(e.object.target=this.target.uuid),e}}class Sc extends yc{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(we.DEFAULT_UP),this.updateMatrix(),this.groundColor=new _t(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}}const jo=new Wt,ih=new I,sh=new I;class yu{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Ft(512,512),this.map=null,this.mapPass=null,this.matrix=new Wt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new mc,this._frameExtents=new Ft(1,1),this._viewportCount=1,this._viewports=[new Se(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){const e=this.camera,n=this.matrix;ih.setFromMatrixPosition(t.matrixWorld),e.position.copy(ih),sh.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(sh),e.updateMatrixWorld(),jo.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(jo),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(jo)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return this.intensity!==1&&(t.intensity=this.intensity),this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}class sx extends yu{constructor(){super(new je(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(t){const e=this.camera,n=_s*2*t.angle*this.focus,s=this.mapSize.width/this.mapSize.height,r=t.distance||e.far;(n!==e.fov||s!==e.aspect||r!==e.far)&&(e.fov=n,e.aspect=s,e.far=r,e.updateProjectionMatrix()),super.updateMatrices(t)}copy(t){return super.copy(t),this.focus=t.focus,this}}class rx extends yc{constructor(t,e,n=0,s=Math.PI/3,r=0,o=2){super(t,e),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(we.DEFAULT_UP),this.updateMatrix(),this.target=new we,this.distance=n,this.angle=s,this.penumbra=r,this.decay=o,this.map=null,this.shadow=new sx}get power(){return this.intensity*Math.PI}set power(t){this.intensity=t/Math.PI}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.angle=t.angle,this.penumbra=t.penumbra,this.decay=t.decay,this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}}class ox extends yu{constructor(){super(new hu(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class wc extends yc{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(we.DEFAULT_UP),this.updateMatrix(),this.target=new we,this.shadow=new ox}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:sc}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=sc);function Ie(i,t=!1){const e=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),s=new Set(Object.keys(i[0].morphAttributes)),r={},o={},a=i[0].morphTargetsRelative,c=new Me;let l=0;for(let h=0;h<i.length;++h){const u=i[h];let f=0;if(e!==(u.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const m in u.attributes){if(!n.has(m))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have compatible attributes; make sure "'+m+'" attribute exists among all geometries, or in none of them.'),null;r[m]===void 0&&(r[m]=[]),r[m].push(u.attributes[m]),f++}if(f!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of attributes."),null;if(a!==u.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const m in u.morphAttributes){if(!s.has(m))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+".  .morphAttributes must be consistent throughout all geometries."),null;o[m]===void 0&&(o[m]=[]),o[m].push(u.morphAttributes[m])}if(t){let m;if(e)m=u.index.count;else if(u.attributes.position!==void 0)m=u.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". The geometry must have either an index or a position attribute"),null;c.addGroup(l,m,h),l+=m}}if(e){let h=0;const u=[];for(let f=0;f<i.length;++f){const m=i[f].index;for(let g=0;g<m.count;++g)u.push(m.getX(g)+h);h+=i[f].attributes.position.count}c.setIndex(u)}for(const h in r){const u=rh(r[h]);if(!u)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" attribute."),null;c.setAttribute(h,u)}for(const h in o){const u=o[h][0].length;if(u===0)break;c.morphAttributes=c.morphAttributes||{},c.morphAttributes[h]=[];for(let f=0;f<u;++f){const m=[];for(let _=0;_<o[h].length;++_)m.push(o[h][_][f]);const g=rh(m);if(!g)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" morphAttribute."),null;c.morphAttributes[h].push(g)}}return c}function rh(i){let t,e,n,s=-1,r=0;for(let l=0;l<i.length;++l){const h=i[l];if(t===void 0&&(t=h.array.constructor),t!==h.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(e===void 0&&(e=h.itemSize),e!==h.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=h.normalized),n!==h.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=h.gpuType),s!==h.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=h.count*e}const o=new t(r),a=new ve(o,e,n);let c=0;for(let l=0;l<i.length;++l){const h=i[l];if(h.isInterleavedBufferAttribute){const u=c/e;for(let f=0,m=h.count;f<m;f++)for(let g=0;g<e;g++){const _=h.getComponent(f,g);a.setComponent(f+u,g,_)}}else o.set(h.array,c);c+=h.count*e}return s!==void 0&&(a.gpuType=s),a}const no=[{id:"auto",emoji:"🛺",name:"Auto-rickshaw",ride:"city"},{id:"cab",emoji:"🚕",name:"Yellow Cab",ride:"city"},{id:"signal",emoji:"🚦",name:"Traffic Light",ride:"city"},{id:"eagle",emoji:"🦅",name:"Eagle",ride:"mountain"},{id:"bear",emoji:"🐻",name:"Bear",ride:"mountain"},{id:"deer",emoji:"🦌",name:"Deer",ride:"mountain"},{id:"peacock",emoji:"🦚",name:"Peacock",ride:"mud"},{id:"elephant",emoji:"🐘",name:"Elephant",ride:"mud"},{id:"mango",emoji:"🥭",name:"Mango",ride:"mud"},{id:"board",emoji:"🛹",name:"Skateboard",ride:"skatepark"},{id:"liberty",emoji:"🗽",name:"Statue of Liberty",ride:"skatepark"},{id:"cricket",emoji:"🏏",name:"Cricket Bat",ride:"skatepark"},{id:"baseball",emoji:"⚾",name:"Baseball",ride:"pump"},{id:"tiger",emoji:"🐅",name:"Tiger",ride:"pump"},{id:"taj",emoji:"🕌",name:"Taj Mahal",ride:"pump"}],bc=i=>no.find(t=>t.id===i),In=new I(0,1,0),st=(i,t={})=>new Ue({color:i,...t});function Su(){const i=document.createElement("canvas");i.width=128,i.height=32;const t=i.getContext("2d");for(let n=0;n<16;n++)for(let s=0;s<4;s++)t.fillStyle=(n+s)%2?"#111":"#fff",t.fillRect(n*8,s*8,8,8);const e=new Ni(i);return e.colorSpace=Te,e.magFilter=tn,e}function de(i,t,e,n){const s=new tt(new xe(e,e,1,8),n);return Vs(s,i,t),s}function Vs(i,t,e){const n=new I().subVectors(e,t),s=n.length()||.001;i.position.copy(t).addScaledVector(n,.5),i.scale.set(1,s,1),i.quaternion.setFromUnitVectors(In,n.normalize())}function ja(i,t,e,n,s){const r=t.y-i.y,o=t.z-i.z,a=Math.min(Math.hypot(r,o),e+n-.001),c=Math.atan2(r,o),l=Math.max(-1,Math.min(1,(e*e+a*a-n*n)/(2*e*a||1))),h=Math.acos(l)*(s?-1:1);return new I(i.x,i.y+Math.sin(c+h)*e,i.z+Math.cos(c+h)*e)}function uo(i){const t=new me;t.rotation.order="YXZ";const e=new me;t.add(e);const n=st(i.bike),s=st(i.helmet),r=st("#1f2328"),o=st("#c9ced4"),a=st("#c68a5e"),c=st("#f97316"),l=st("#334155"),h=st("#222"),u=.33,f=[];for(const P of[.55,-.55]){const L=new me;L.position.set(0,u,P);const N=new tt(new ho(u-.03,.045,8,24),r);N.rotation.y=Math.PI/2,L.add(N);for(let F=0;F<3;F++){const U=new tt(new Nt(.01,.58,.012),o);U.rotation.x=F*Math.PI/3,L.add(U)}e.add(L),f.push(L)}const m=(P,L,N=0)=>new I(N,P,L),g=m(u,.55),_=m(u,-.55),p=m(.32,.08),d=m(.85,.22),y=m(.85,-.38);e.add(de(g,p,.025,n),de(p,d,.03,n),de(d,g,.022,n)),e.add(de(p,y,.032,n),de(d,y,.03,n),de(y,_,.028,n)),e.add(de(y,m(1,-.36),.022,h)),e.add(de(m(1,-.36,-.28),m(1,-.36,.28),.02,h));const b=new tt(new Nt(.16,.05,.26),h);b.position.set(0,.89,.24),e.add(b);const w=m(.98,.18),C=m(1.42,-.1),A=de(w,C,.13,c);e.add(A);const S=new tt(new Ce(.13,16,12),a);S.position.set(0,1.63,-.17),e.add(S);const M=new tt(new Ce(.16,16,10,0,Math.PI*2,0,Math.PI/2),s);M.position.set(0,1.66,-.15),e.add(M);const x=[];for(const P of[-1,1]){const L=m(1.38,-.1,P*.17),N=m(1,-.36,P*.26),F=ja(L,N,.3,.3,!1),U=de(L,F,.045,a),O=de(F,N,.04,a);e.add(U,O),x.push([U,O])}const v=[],E=[];for(let P=0;P<2;P++){const L=new tt(new xe(.065,.065,1,8),l),N=new tt(new xe(.05,.05,1,8),l);e.add(L,N),v.push(L),E.push(N)}return t.traverse(P=>{P.isMesh&&(P.castShadow=!0)}),{root:t,lean:e,wheels:f,thighs:v,shins:E,arms:x,bikeMat:n,helmetMat:s}}function os(i,t,e){for(const o of i.wheels)o.rotation.x=-t;const n=.32,s=.08,r=(e==null?void 0:e.k)??0;for(let o=0;o<2;o++){const a=t*.6+o*Math.PI,c=o?1:-1,l=new I(c*.1,.98,.18),h=new I(c*.13,n+Math.sin(a)*.17,s+Math.cos(a)*.17);(e==null?void 0:e.name)==="Superman"&&h.lerp(new I(c*.15,1.1,.95),r);const u=ja(l,h,.42,.42,!0);Vs(i.thighs[o],l,u),Vs(i.shins[o],u,h)}for(let o=0;o<2;o++){const a=o?1:-1,c=new I(a*.17,1.38,-.1),l=new I(a*.26,1,-.36);(e==null?void 0:e.name)==="No Hander"&&l.lerp(new I(a*.38,1.95,-.05),r);const h=ja(c,l,.3,.3,!1);Vs(i.arms[o][0],c,h),Vs(i.arms[o][1],h,l)}}function ax(i){const t=new gu({canvas:i,antialias:!0,powerPreference:"high-performance"});return t.setPixelRatio(Math.min(window.devicePixelRatio||1,1.75)),t.shadowMap.enabled=!0,t.shadowMap.type=Bh,t}const Ka=i=>-i;function cx(){const i=document.createElement("canvas");i.width=i.height=64;const t=i.getContext("2d");t.fillStyle="#000",t.fillRect(0,0,64,64),t.fillStyle="#ffcf7a",t.fillRect(14,12,36,38);const e=new Ni(i);return e.wrapS=e.wrapT=ps,e.colorSpace=Te,e}function oh(i,t,e){const n=[];for(let a=-20;a<Rn+40;a+=1.4)if(!t.intersections.some(c=>Math.abs(a-c.s)<Be+8))for(const c of[-1,1])n.push(new I(c*7.9,5+Math.sin(a*.9)*.35,Ka(a)));const s=new Re(new Ce(.09,6,4),new cn,n.length),r=new Wt,o=new _t;n.forEach((a,c)=>{s.setMatrixAt(c,r.makeTranslation(a.x,a.y,a.z)),s.setColorAt(c,o.set(e[c%e.length]))}),i.add(s)}function lx(i){const e=new Float32Array(4500),n=new Float32Array(1500*3);for(let a=0;a<1500;a++)n[a*3]=(Math.random()-.5)*60,n[a*3+1]=Math.random()*25,n[a*3+2]=(Math.random()-.5)*60;const s=new Me;s.setAttribute("position",new ve(e,3));const r=new Mu(s,new xc({color:"#ffffff",size:.12,transparent:!0,opacity:.9}));r.frustumCulled=!1,i.add(r);let o=0;return(a,c)=>{o+=a;for(let l=0;l<1500;l++){let h=n[l*3+1]-a*2.2;h<0&&(h+=25),n[l*3+1]=h,e[l*3]=c.position.x+n[l*3]+Math.sin(o+l)*.4,e[l*3+1]=c.position.y-8+h,e[l*3+2]=c.position.z+n[l*3+2]}s.attributes.position.needsUpdate=!0}}function hx(i,t,e,n,s,r){var c,l,h,u,f,m;const o=t.fog,a=g=>e.getObjectByName(g);if(i==="diwali"){t.background=new _t("#0b1026"),o.color.set("#141a3a"),o.near=40,o.far=190,s.hemi.intensity=.45,s.hemi.color.set("#9db4ff"),s.sun.intensity=.35,s.sun.color.set("#b8c6ff");const g=(c=a("buildings"))==null?void 0:c.material;g&&(g.emissive.set("#ffffff"),g.emissiveMap=cx(),g.emissiveMap.repeat.copy(g.map.repeat),g.emissiveIntensity=.9,g.needsUpdate=!0);const _=(l=a("lampHeads"))==null?void 0:l.material;_==null||_.emissive.set("#fff1c1");const p=[];for(let O=-10;O<Rn+20;O+=2.5)if(!n.intersections.some(k=>Math.abs(O-k.s)<Be+1))for(const k of[-1,1])p.push(new I(k*(ie+.45),.17,Ka(O)));const d=new xe(.1,.06,.07,8),y=new Ce(.05,6,4);y.scale(1,1.8,1);const b=new Re(d,st("#b45309"),p.length),w=new Re(y,new cn({color:"#ffb020"}),p.length),C=new Wt;p.forEach((O,k)=>{b.setMatrixAt(k,C.makeTranslation(O.x,O.y,O.z)),w.setMatrixAt(k,C.makeTranslation(O.x,O.y+.11,O.z))}),e.add(b,w),oh(e,n,["#ffb020","#ff4d6d","#ffd60a","#ff7b00","#f72585"]);const A=new rx("#fff4d6",40,30,.45,.5,1.2);A.position.set(0,1.1,-.5),A.target.position.set(0,0,-12),r.add(A,A.target);const S=600,M=new Float32Array(S*3),x=new Float32Array(S*3),v=Array.from({length:S},()=>new I),E=new Float32Array(S),P=new Me;P.setAttribute("position",new ve(M,3)),P.setAttribute("color",new ve(x,3));const L=new Mu(P,new xc({size:.5,vertexColors:!0,transparent:!0,blending:aa,depthWrite:!1,fog:!1}));L.frustumCulled=!1,e.add(L);let N=0,F=0;const U=["#ff4d6d","#ffd60a","#4cc9f0","#80ffdb","#f72585","#ffb020"].map(O=>new _t(O));return{update(O,k){if(N-=O,N<=0){N=.9+Math.random()*.9;const K=k.x+(Math.random()-.5)*50,Y=28+Math.random()*14,it=k.z-60-Math.random()*50,ct=U[Math.floor(Math.random()*U.length)];for(let xt=0;xt<90;xt++){const $=F++%S;M.set([K,Y,it],$*3),v[$].randomDirection().multiplyScalar(8+Math.random()*4),E[$]=1.6,ct.toArray(x,$*3)}}for(let K=0;K<S;K++){if(E[K]<=0){M[K*3+1]=-999;continue}E[K]-=O,v[K].y-=4*O,v[K].multiplyScalar(1-1.2*O),M[K*3]+=v[K].x*O,M[K*3+1]+=v[K].y*O,M[K*3+2]+=v[K].z*O;const Y=Math.max(0,E[K]/1.6);x[K*3]*=.995+.005*Y}P.attributes.position.needsUpdate=!0,P.attributes.color.needsUpdate=!0}}}if(i==="christmas"){t.background=new _t("#c9d6e3"),o.color.set("#e2e8f0"),o.near=50,o.far=210,s.hemi.intensity=1.1,s.sun.intensity=.8,(u=(h=a("walk"))==null?void 0:h.material)==null||u.color.set("#f1f5f9"),(m=(f=a("roofs"))==null?void 0:f.material)==null||m.color.set("#ffffff");const g=a("crowns");if(g){g.material.color.set("#ffffff");const w=new _t("#eef4ee");for(let C=0;C<g.count;C++)g.setColorAt(C,w);g.instanceColor.needsUpdate=!0}oh(e,n,["#ef4444","#22c55e","#facc15","#3b82f6","#ffffff"]);const _=new me,p=st("#166534",{flatShading:!0});for(let w=0;w<4;w++){const C=new tt(new bn(4-w*.8,4,10),p);C.position.y=3+w*2.6,_.add(C)}const d=new tt(new vc(.8),new cn({color:"#fde047"}));d.position.y=13.6,_.add(d);const y=["#ef4444","#facc15","#3b82f6","#f472b6"];for(let w=0;w<40;w++){const C=2+Math.random()*10,A=(4-C/12*3.4)*.95,S=Math.random()*Math.PI*2,M=new tt(new Ce(.22,8,6),new cn({color:y[w%4]}));M.position.set(Math.cos(S)*A,C,Math.sin(S)*A),_.add(M)}_.position.set(n.sign*-9,0,Ka(n.finishS+18)),e.add(_);const b=lx(e);return{update:(w,C,A)=>b(w,A)}}return null}function Ec(i){i.traverse(t=>t.isMesh?t.castShadow=!0:null)}function fn(i,t,e,n,s=0,r=0,o=0){const a=new tt(new Nt(i,t,e),n);return a.position.set(s,r,o),a}function wu(i,t){const e=new I;let n=!0;return{update(s,r,o,a,c){const h=new I(r.x+Math.cos(o)*1-Math.sin(o)*.7,r.y,r.z+Math.sin(o)*1+Math.cos(o)*.7);n&&(e.copy(h),n=!1),e.lerp(h,1-Math.exp(-10*s)),i.position.set(e.x,r.y+t(c,a),e.z),i.rotation.y=-o},dispose(){i.removeFromParent()}}}function ux(i){const t=new me,e=st("#b7793f"),n=st("#5b3a1e");t.add(fn(.26,.24,.55,e,0,.36,0));const s=new me;s.position.set(0,.52,-.33),s.add(fn(.22,.2,.22,e),fn(.12,.1,.14,e,0,-.04,-.15),fn(.05,.05,.03,n,0,-.02,-.23)),s.add(fn(.06,.12,.04,n,-.09,.12,.02),fn(.06,.12,.04,n,.09,.12,.02)),t.add(s);const r=fn(.05,.05,.22,e,0,.46,.33);r.rotation.x=-.6,t.add(r);const o=[-1,1].flatMap(a=>[-1,1].map(c=>fn(.07,.26,.07,e,a*.09,.13,c*.2)));return t.add(...o),Ec(t),i.add(t),wu(t,(a,c)=>{const l=Math.min(1,c/3);return o.forEach((h,u)=>h.rotation.x=Math.sin(a*14+(u%2?Math.PI:0))*.8*l),r.rotation.y=Math.sin(a*16)*.6,Math.abs(Math.sin(a*14))*.06*l})}function fx(i){const t=new me,e=st("#f8fafc"),n=st("#f9a8d4"),s=new tt(new Ce(.2,12,10),e);s.scale.set(1,.9,1.25),s.position.y=.22;const r=new tt(new Ce(.13,12,10),e);r.position.set(0,.42,-.2),t.add(s,r);for(const a of[-.05,.05]){const c=fn(.05,.22,.03,e,a,.62,-.18);c.add(fn(.025,.16,.01,n,0,0,-.02)),t.add(c)}const o=new tt(new Ce(.06,8,6),e);return o.position.set(0,.25,.25),t.add(o),Ec(t),i.add(t),wu(t,(a,c)=>c>.5?Math.abs(Math.sin(a*7))*.35:0)}function dx(i){const t=new me,e=st("#22c55e"),n=st("#ef4444"),s=st("#facc15"),r=new tt(new Ce(.09,10,8),e);r.scale.set(1,1.3,1);const o=new tt(new Ce(.065,10,8),e);o.position.set(0,.12,-.03);const a=new tt(new bn(.025,.06,6),n);a.rotation.x=-Math.PI/2,a.position.set(0,.11,-.1);const c=fn(.05,.02,.18,s,0,-.05,.12);c.rotation.x=.5;const l=[-1,1].map(h=>fn(.02,.12,.14,e,h*.09,.02,.01));return t.add(r,o,a,c,...l),t.position.set(0,1.12,-.38),Ec(t),i.lean.add(t),{update(h,u,f,m,g){const _=m>4?Math.sin(g*30)*.7:Math.sin(g*3)*.1;l[0].rotation.z=_,l[1].rotation.z=-_},dispose(){t.removeFromParent()}}}function bu(i,t,e){return i==="dog"?ux(t):i==="bunny"?fx(t):i==="parrot"?dx(e):null}const ah=new Map;function px(i){const t=ah.get(i);if(t)return t;const e=document.createElement("canvas");e.width=e.height=128;const n=e.getContext("2d");n.fillStyle="#ffffff",n.beginPath(),n.roundRect(4,4,120,120,24),n.fill(),n.lineWidth=8,n.strokeStyle="#f472b6",n.stroke(),n.font="80px system-ui, 'Apple Color Emoji', 'Segoe UI Emoji', 'Noto Color Emoji', sans-serif",n.textAlign="center",n.textBaseline="middle",n.fillText(i,64,70);const s=new Ni(e);return s.colorSpace=Te,ah.set(i,s),s}function Eu(i){const t=new me,e=new tt(new Ae(.85,.85),new cn({map:px(i),side:ze,transparent:!0})),n=new tt(new Mc(.55,.75,32),new cn({color:"#fde047",transparent:!0,opacity:.55,side:ze}));return t.add(n,e),t}function Tu(i,t,e){i.rotation.y=t*2+e,i.children[0].scale.setScalar(1+Math.sin(t*5+e)*.08)}const ee=i=>-i;function mx(){const i=document.createElement("canvas");i.width=i.height=64;const t=i.getContext("2d");t.fillStyle="#ffffff",t.fillRect(0,0,64,64),t.fillStyle="#3b4b5e",t.fillRect(14,12,36,38),t.fillStyle="#8fb3cf",t.fillRect(17,15,30,14),t.fillStyle="#e9edf1",t.fillRect(12,50,40,4);const e=new Ni(i);return e.wrapS=e.wrapT=ps,e.colorSpace=Te,e.magFilter=Sn,e.anisotropy=4,e}function ch(i){const t=new me,e=st(i);t.userData.paint=e;const n=new tt(new Nt(1.8,.62,4.3),e);n.position.y=.58;const s=new tt(new Nt(1.62,.56,2.2),st("#d8e6ef"));s.position.set(0,1.16,.25);const r=new tt(new Nt(1.66,.08,2),e);r.position.set(0,1.47,.25),t.add(n,s,r);const o=st("#1b1b1b");for(const[l,h]of[[-.85,-1.35],[.85,-1.35],[-.85,1.35],[.85,1.35]]){const u=new tt(new xe(.34,.34,.24,14),o);u.rotation.z=Math.PI/2,u.position.set(l,.34,h),t.add(u)}const a=st("#fff7c2",{emissive:"#fff3a0",emissiveIntensity:.6}),c=st("#ff4d4d",{emissive:"#ff2020",emissiveIntensity:.4});for(const l of[-.6,.6]){const h=new tt(new Nt(.34,.14,.05),a);h.position.set(l,.66,-2.16);const u=new tt(new Nt(.34,.14,.05),c);u.position.set(l,.66,2.16),t.add(h,u)}return t.traverse(l=>{l.isMesh&&(l.castShadow=!0)}),t}function gx(){const i=new me,t=[],e=st("#1f2937");for(const a of[-.08,.08]){const c=new tt(new Nt(.11,.5,.11),e);c.geometry.translate(0,-.25,0),c.position.set(a,.55,0),i.add(c),t.push(c)}const n=new tt(new Nt(.36,.48,.22),st("#e11d48"));n.position.y=.82;const s=new tt(new Nt(.28,.34,.14),st("#facc15"));s.position.set(0,.84,.17);const r=new tt(new Ce(.13,12,10),st("#a0673f"));r.position.y=1.2;const o=new tt(new Ce(.135,12,8,0,Math.PI*2,0,Math.PI/2),st("#1f2937"));return o.position.y=1.22,i.add(n,s,r,o),i.traverse(a=>{a.isMesh&&(a.castShadow=!0)}),{root:i,legs:t}}class _x{constructor(t){q(this,"renderer");q(this,"scene",new _c);q(this,"camera",new je(60,1,.1,400));q(this,"sun",new wc("#ffffff",1.7));q(this,"dynamic",new me);q(this,"staticGroup",new me);q(this,"rider");q(this,"carPool",[]);q(this,"peds",[]);q(this,"coinMeshes",[]);q(this,"stickerMeshes",[]);q(this,"pet",null);q(this,"opts",{pet:"none",festival:null});q(this,"lightRigs",[]);q(this,"camPos",new I);q(this,"camLook",new I);q(this,"winTex",mx());q(this,"hemi",new Sc("#e6f4ff","#7c8a6a",1.25));q(this,"fx",null);q(this,"clock",0);this.renderer=t,this.scene.background=new _t("#9fd6ff"),this.scene.fog=new co("#cde8fb",70,240),this.scene.add(this.hemi),this.sun.castShadow=!0,this.sun.shadow.mapSize.set(1024,1024);const e=this.sun.shadow.camera;e.left=-35,e.right=35,e.top=35,e.bottom=-35,e.near=1,e.far=160,this.sun.shadow.bias=-8e-4,this.scene.add(this.sun,this.sun.target,this.staticGroup,this.dynamic)}resize(t,e){this.camera.aspect=t/e,this.camera.fov=t/e<1.2?75:60,this.camera.updateProjectionMatrix()}build(t,e,n={pet:"none",festival:null}){var c;this.opts=n;for(const l of[this.staticGroup,this.dynamic])l.traverse(h=>{const u=h;u.isMesh&&u.geometry.dispose()}),l.clear();this.carPool=[],this.peds=[],this.coinMeshes=[],this.stickerMeshes=[],this.lightRigs=[];const s=t.layout;this.buildGround(s),this.buildMarkings(s),this.buildBuildings(s),this.buildStreetFurniture(s),this.resetSky(),this.rider=uo(e),this.dynamic.add(this.rider.root);for(const l of s.parked){const h=ch(l.color);h.position.set(l.x,0,ee(l.s)),this.staticGroup.add(h)}for(let l=0;l<14;l++){const h=ch("#888");h.visible=!1,this.dynamic.add(h),this.carPool.push({mesh:h,car:null})}for(let l=0;l<s.zebras.length;l++){const h=gx();h.root.visible=!1,this.dynamic.add(h.root),this.peds.push(h)}(c=this.pet)==null||c.dispose(),this.pet=bu(n.pet,this.dynamic,this.rider),this.fx=n.festival?hx(n.festival,this.scene,this.staticGroup,s,{hemi:this.hemi,sun:this.sun},this.rider.root):null;for(const l of s.stickers){const h=Eu(bc(l.id).emoji);h.position.set(l.d,l.lift+.2,ee(l.s)),this.dynamic.add(h),this.stickerMeshes.push(h)}const r=new xe(.32,.32,.07,20);r.rotateX(Math.PI/2);const o=st("#fbbf24",{emissive:"#b45309",emissiveIntensity:.35});for(const l of s.coins){const h=new tt(r,o);h.position.set(l.x,.75,ee(l.s)),h.castShadow=!0,this.dynamic.add(h),this.coinMeshes.push(h)}const a=t.player;this.camPos.set(a.x,4.4,ee(a.s)+6.8),this.camLook.set(a.x,1,ee(a.s)-5)}resetSky(){this.scene.background=new _t("#9fd6ff");const t=this.scene.fog;t.color.set("#cde8fb"),t.near=70,t.far=240,this.hemi.intensity=1.25,this.hemi.color.set("#e6f4ff"),this.sun.intensity=1.7,this.sun.color.set("#ffffff")}setColors(t){var e,n;(e=this.rider)==null||e.bikeMat.color.set(t.bike),(n=this.rider)==null||n.helmetMat.color.set(t.helmet)}buildGround(t){const e=Rn+200,n=ee(Rn/2),s=new tt(new Ae(400,e),st("#8fbf6f"));s.rotation.x=-Math.PI/2,s.position.set(0,-.02,n),s.receiveShadow=!0;const r=st("#41474f"),o=new tt(new Ae(ie*2,e),r);o.rotation.x=-Math.PI/2,o.position.set(0,0,n),o.receiveShadow=!0,this.staticGroup.add(s,o);for(const m of t.intersections){const g=new tt(new Ae(200,Be*2),r);g.rotation.x=-Math.PI/2,g.position.set(0,.001,ee(m.s)),g.receiveShadow=!0,this.staticGroup.add(g)}const a=[],c=[];let l=-100;const h=[];for(const m of t.intersections)h.push([l,m.s-Be]),l=m.s+Be;h.push([l,Rn+100]);for(const[m,g]of h)for(const _ of[-1,1]){const p=new Nt(_o+1.5,.16,g-m);p.translate(_*(ie+(_o+1.5)/2),.08,ee((m+g)/2)),a.push(p);const d=new Nt(.2,.18,g-m);d.translate(_*(ie+.1),.09,ee((m+g)/2)),c.push(d)}for(const m of t.intersections)for(const g of[-1,1])for(const _ of[-1,1]){const p=new Nt(95,.16,3);p.translate(_*(ie+_o+1.5+47.5),.08,ee(m.s+g*(Be+1.5))),a.push(p)}const u=new tt(Ie(a),st("#cfcdc6"));u.name="walk",u.receiveShadow=!0;const f=new tt(Ie(c),st("#9a9a94"));this.staticGroup.add(u,f)}buildMarkings(t){const e=[],n=[],s=(c,l,h,u,f=e)=>{const m=new Ae(c,l);m.rotateX(-Math.PI/2),m.translate(h,.012,ee(u)),f.push(m)},r=(c,l=0)=>t.intersections.some(h=>Math.abs(c-h.s)<Be+l);for(let c=-60;c<Rn+100;c+=3)r(c,1)||(s(.12,3.02,-ie+.25,c),s(.12,3.02,ie-.25,c),t.side==="right"?(s(.1,3.02,-.12,c,n),s(.1,3.02,.12,c,n)):Math.floor(c/3)%3===0&&s(.14,3,0,c));for(const c of t.intersections){s(ie,.4,t.sign*ie/2,c.stopS),s(ie,.4,-t.sign*ie/2,c.s+Be+5);for(const l of[c.zebraS,c.s+Be+2.5])for(let h=-ie+.5;h<ie;h+=1)s(.5,3,h,l);for(let l=ie+2;l<100;l+=6)s(2.5,.14,l,c.s),s(2.5,.14,-l,c.s)}for(const c of t.zebras)for(let l=-ie+.5;l<ie;l+=1)s(.5,3,l,c.s);this.staticGroup.add(new tt(Ie(e),st("#f4f4f4"))),n.length&&this.staticGroup.add(new tt(Ie(n),st("#f2c230")));const o=[],a=[];for(const c of t.bumps){const l=new xe(.35,.35,ie*2,12,1,!1,0,Math.PI);l.rotateZ(Math.PI/2),l.rotateX(-Math.PI/2),l.scale(1,.25,1),l.translate(0,0,ee(c)),o.push(l);for(let h=-ie+.4;h<ie;h+=1.2){const u=new Nt(.5,.1,.72);u.translate(h,.04,ee(c)),a.push(u)}}this.staticGroup.add(new tt(Ie(o),st("#2b2b2b"))),this.staticGroup.add(new tt(Ie(a),st("#facc15")))}buildBuildings(t){const e=[],n=[],s=[],r=new _t,o=["#e63946","#2a9d8f","#f4a261","#457b9d","#ffb703"];t.buildings.forEach((l,h)=>{const u=l.cross?l.len:l.depth,f=l.cross?l.depth:l.len,m=new Nt(u,l.height,f).toNonIndexed(),g=m.getAttribute("uv"),_=m.getAttribute("normal");for(let y=0;y<g.count;y++){const b=Math.abs(_.getX(y));Math.abs(_.getY(y))>.5?g.setXY(y,.02,.02):g.setXY(y,g.getX(y)*((b>.5?f:u)/3.2),g.getY(y)*(l.height/3.4))}r.set(l.color);const p=new Float32Array(g.count*3);for(let y=0;y<g.count;y++)r.toArray(p,y*3);m.setAttribute("color",new ve(p,3)),m.translate(l.x,l.height/2,ee(l.s)),e.push(m);const d=new Nt(u+.3,.3,f+.3);if(d.translate(l.x,l.height+.15,ee(l.s)),n.push(d),!l.cross&&l.height<30){const y=l.x-Math.sign(l.x)*(l.depth/2+.6),b=new Nt(1.2,.12,l.len*.8);b.rotateZ(Math.sign(l.x)*.35),b.translate(y,3.2,ee(l.s));const w=new _t(o[h%o.length]),C=new Float32Array(b.getAttribute("position").count*3);for(let A=0;A<C.length/3;A++)w.toArray(C,A*3);b.setAttribute("color",new ve(C,3)),s.push(b.toNonIndexed())}});const a=new tt(Ie(e),new Ue({map:this.winTex,vertexColors:!0}));a.name="buildings",a.castShadow=!0,a.receiveShadow=!0;const c=new tt(Ie(n),st("#7a7f87"));c.name="roofs",this.staticGroup.add(a,c),s.length&&this.staticGroup.add(new tt(Ie(s),new Ue({vertexColors:!0})))}buildStreetFurniture(t){const e=new xe(.12,.16,2.2,6);e.translate(0,1.1,0);const n=new Es(1.3,0);n.translate(0,3,0);const s=new Re(e,st("#7a5230"),t.trees.length),r=new Re(n,st("#4caf50",{flatShading:!0}),t.trees.length);r.name="crowns";const o=new Wt,a=new Un,c=new I,l=new I;t.trees.forEach((y,b)=>{const w=.85+b*37%10/25;a.setFromAxisAngle(In,b),o.compose(c.set(y.x,.16,ee(y.s)),a,l.set(w,w,w)),s.setMatrixAt(b,o),r.setMatrixAt(b,o),r.setColorAt(b,new _t(b%3?"#4caf50":"#3d9a46"))}),s.castShadow=r.castShadow=!0,this.staticGroup.add(s,r);const h=new xe(.07,.09,5,6);h.translate(0,2.5,0);const u=new Re(h,st("#5b6470"),t.lamps.length),f=new Nt(.9,.15,.3);f.translate(-.35,5,0);const m=new Re(f,st("#e5e7eb"),t.lamps.length);m.name="lampHeads",t.lamps.forEach((y,b)=>{a.setFromAxisAngle(In,y.x>0?0:Math.PI),o.compose(c.set(y.x,.16,ee(y.s)),a,l.set(1,1,1)),u.setMatrixAt(b,o),m.setMatrixAt(b,o)}),u.castShadow=!0,this.staticGroup.add(u,m);const g=st("#3a3f45");for(const y of t.intersections){const b=new me,w=t.sign*(ie+.7);b.add(de(new I(w,0,ee(y.stopS)),new I(w,5,ee(y.stopS)),.1,g)),b.add(de(new I(w,4.9,ee(y.stopS)),new I(t.sign*1.2,4.9,ee(y.stopS)),.07,g));const C=new tt(new Nt(.5,1.4,.4),st("#1d1d1d"));C.position.set(t.sign*1.5,4.3,ee(y.stopS)),b.add(C);const A=C.clone();A.scale.setScalar(.6),A.position.set(w,2.6,ee(y.stopS)+.1),b.add(A);const S={};["red","yellow","green"].forEach((M,x)=>{const v=st("#333");S[M]=v;for(const[E,P,L]of[[t.sign*1.5,4.75-x*.43,.15],[w,2.87-x*.26,.09]]){const N=new tt(new Ce(L,12,8),v);N.position.set(E,P,ee(y.stopS)+(L>.1?.22:.25)),b.add(N)}}),b.traverse(M=>{M.isMesh&&(M.castShadow=!0)}),this.staticGroup.add(b),this.lightRigs.push({lamps:S})}const _=ee(t.finishS),p=st("#f97316");this.staticGroup.add(de(new I(-ie-.4,0,_),new I(-ie-.4,5.5,_),.18,p)),this.staticGroup.add(de(new I(ie+.4,0,_),new I(ie+.4,5.5,_),.18,p));const d=new tt(new Nt(ie*2+1.2,1,.15),new Ue({map:Su()}));d.position.set(0,5.2,_),this.staticGroup.add(d)}render(t,e){var m,g;this.clock+=e;const n=t.player,s=t.layout,r=this.rider,o=n.bumpT>0?Math.sin(n.bumpT/.35*Math.PI)*.12:0;if(r.root.position.set(n.x,o,ee(n.s)),r.root.rotation.y=-n.heading,n.crashed){const _=Math.min(1,n.crashT/.35);r.lean.rotation.z=1.35*_,r.lean.position.y=-.05*_}else r.lean.rotation.z=Jh.lerp(r.lean.rotation.z,-n.heading*.7,1-Math.exp(-8*e)),r.lean.position.y=0;os(r,n.crank),(m=this.pet)==null||m.update(e,r.root.position,n.heading,n.speed,this.clock),this.stickerMeshes.forEach((_,p)=>{_.visible=!t.stickerGot[p],Tu(_,this.clock,p)});for(const _ of this.carPool)_.car&&!t.cars.includes(_.car)&&(_.car=null);for(const _ of t.cars){let p=this.carPool.find(d=>d.car===_);if(!p){if(p=this.carPool.find(d=>!d.car),!p)continue;p.car=_,p.mesh.userData.paint.color.set(_.color)}p.mesh.visible=!0,p.mesh.position.set(_.x,0,ee(_.s)),p.mesh.rotation.y=_.axis==="main"?Math.PI:_.dir>0?-Math.PI/2:Math.PI/2}for(const _ of this.carPool)_.car||(_.mesh.visible=!1);s.zebras.forEach((_,p)=>{const d=t.peds[p],y=this.peds[p];if(y.root.visible=d.t>=0&&!d.done,!y.root.visible)return;y.root.position.set(d.x,.02,ee(_.s)),y.root.rotation.y=d.from>0?Math.PI/2:-Math.PI/2;const b=Math.sin(this.clock*9)*.5;y.legs[0].rotation.x=b,y.legs[1].rotation.x=-b}),t.lights.forEach((_,p)=>{const d=this.lightRigs[p];for(const y of["red","yellow","green"]){const b=_.phase===y,w=y==="red"?"#ff3b30":y==="yellow"?"#ffcc00":"#34c759";d.lamps[y].color.set(b?w:"#3a3a3a"),d.lamps[y].emissive.set(b?w:"#000000"),d.lamps[y].emissiveIntensity=b?1:0}}),this.coinMeshes.forEach((_,p)=>{_.visible=!t.coins[p],_.rotation.y=this.clock*3+p,_.position.y=.75+Math.sin(this.clock*3+p)*.06});const a=n.heading*.5,c=new I(Math.sin(a),0,-Math.cos(a)),l=new I(n.x,0,ee(n.s)),h=l.clone().addScaledVector(c,-6.8).add(new I(0,4.4,0)),u=l.clone().addScaledVector(c,7).add(new I(0,.6,0)),f=1-Math.exp(-6*e);this.camPos.lerp(h,f),this.camLook.lerp(u,f),this.camera.position.copy(this.camPos),this.camera.lookAt(this.camLook),(g=this.fx)==null||g.update(e,l,this.camera),this.sun.position.set(l.x+25,45,l.z+15),this.sun.target.position.set(l.x,0,l.z-10),this.renderer.render(this.scene,this.camera)}}const vs=[{id:"holi",name:"Holi Colour Ride",emoji:"🎨",ride:"mud",blurb:"Splash through colour puddles and paint your bike!",from:[3,1],to:[3,31]},{id:"diwali",name:"Diwali Night Ride",emoji:"🪔",ride:"city",blurb:"Ride the city at night among diyas, lights and fireworks!",from:[10,15],to:[11,20]},{id:"halloween",name:"Halloween Trail",emoji:"🎃",ride:"mountain",blurb:"A spooky dusk forest full of glowing pumpkins and bats!",from:[10,20],to:[11,2]},{id:"christmas",name:"Christmas Snow Ride",emoji:"🎄",ride:"city",blurb:"Snowy streets, twinkling lights and a giant tree!",from:[12,10],to:[1,6]}],Au=i=>vs.find(t=>t.id===i);function Zs(i,t){const e=(t.getMonth()+1)*100+t.getDate(),n=i.from[0]*100+i.from[1],s=i.to[0]*100+i.to[1];return n<=s?e>=n&&e<=s:e>=n||e<=s}function xx(i=new Date){const t=new URLSearchParams(location.search).get("festival");return t&&vs.some(e=>e.id===t)?[t]:vs.filter(e=>Zs(e,i)).map(e=>e.id)}function vx(i=new Date){for(let t=1;t<=366;t++){const e=new Date(i.getFullYear(),i.getMonth(),i.getDate()+t),n=vs.find(s=>Zs(s,e)&&!Zs(s,i));if(n)return{info:n,days:t}}return{info:vs[0],days:0}}function Mx(i,t=new Date){const e=Au(i);if(Zs(e,t))return 0;for(let n=1;n<=366;n++){const s=new Date(t.getFullYear(),t.getMonth(),t.getDate()+n);if(Zs(e,s))return n}return 0}const lh={ArrowLeft:"left",KeyA:"left",ArrowRight:"right",KeyD:"right",ArrowUp:"up",KeyW:"up",ArrowDown:"down",KeyS:"down",Space:"action",KeyB:"bell"};class yx{constructor(...t){q(this,"held",new Set);q(this,"pointers",new Map);q(this,"actionWasDown",!1);q(this,"onBell",()=>{});q(this,"onPause",()=>{});window.addEventListener("keydown",e=>{if(e.code==="Escape"||e.code==="KeyP")return this.onPause();const n=lh[e.code];n&&(e.preventDefault(),n==="bell"&&!e.repeat&&this.onBell(),this.held.add(n))}),window.addEventListener("keyup",e=>{const n=lh[e.code];n&&this.held.delete(n)}),window.addEventListener("blur",()=>{this.held.clear(),this.pointers.clear()});for(const e of t.flatMap(n=>[...n.querySelectorAll("[data-key]")])){const n=e.dataset.key;e.addEventListener("pointerdown",r=>{r.preventDefault(),e.setPointerCapture(r.pointerId),this.pointers.set(r.pointerId,n),e.classList.add("down"),n==="bell"&&this.onBell()});const s=r=>{this.pointers.delete(r.pointerId),[...this.pointers.values()].includes(n)||e.classList.remove("down")};e.addEventListener("pointerup",s),e.addEventListener("pointercancel",s),e.addEventListener("contextmenu",r=>r.preventDefault())}}isDown(t){return this.held.has(t)||[...this.pointers.values()].includes(t)}poll(){const t=this.isDown("action"),e=t&&!this.actionWasDown;return this.actionWasDown=t,{up:this.isDown("up"),down:this.isDown("down"),left:this.isDown("left"),right:this.isDown("right"),trick:e,pump:t}}reset(){this.held.clear(),this.pointers.clear(),this.actionWasDown=!1}}const Sx=["🚦 Stops at red lights","🚸 Waits for people crossing","↔️ Rides on the correct side","🪖 Always wears a helmet","💥 Rides without crashing"];function Ru(i,t,e){var h,u,f;const n=i.getContext("2d"),s=i.width,r=i.height,o=(((h=t.licence)==null?void 0:h.side)??t.side)==="left",a=!!t.licence;n.clearRect(0,0,s,r);const c=n.createLinearGradient(0,0,s,r);c.addColorStop(0,o?"#fff7ed":"#eff6ff"),c.addColorStop(1,o?"#ffedd5":"#dbeafe"),n.fillStyle=c,n.beginPath(),n.roundRect(0,0,s,r,28),n.fill(),(o?["#ff9933","#ffffff","#138808"]:["#b22234","#ffffff","#3c3b6e"]).forEach((m,g)=>{n.fillStyle=m,n.fillRect(0,g*22,s,22)}),n.fillStyle="#0f172a",n.font="900 34px system-ui, sans-serif",n.textAlign="left",n.fillText(`${o?"🇮🇳":"🇺🇸"}  Junior Cycling Licence`,28,112),n.fillStyle="#ffffff",n.strokeStyle="#cbd5e1",n.lineWidth=4,n.beginPath(),n.roundRect(28,136,190,190,18),n.fill(),n.stroke(),e&&n.drawImage(e,32,166,182,182*(e.height/e.width)),n.fillStyle="#334155",n.font="700 18px system-ui, sans-serif",n.fillText("NAME",244,158),n.fillStyle="#0f172a",n.font="900 38px system-ui, sans-serif",n.fillText(t.kidName||"Your name",244,200),n.fillStyle="#334155",n.font="700 18px system-ui, sans-serif",n.fillText("LICENCE NO.",244,240),n.fillText("ISSUED",444,240),n.fillStyle="#0f172a",n.font="800 22px system-ui, sans-serif",n.fillText(((u=t.licence)==null?void 0:u.number)??"-",244,268),n.fillText(((f=t.licence)==null?void 0:f.date)??"-",444,268),n.font="700 17px system-ui, sans-serif",n.fillStyle="#166534",n.fillText(a?"✔ Safe rider: passed the City Ride road test":"Pass the City Ride with no mistakes to earn it!",244,306),n.save(),n.translate(s-110,r-70),n.rotate(-.25),n.strokeStyle=a?"#dc2626":"#94a3b8",n.fillStyle=a?"#dc2626":"#94a3b8",n.lineWidth=5,n.beginPath(),n.arc(0,0,54,0,Math.PI*2),n.stroke(),n.font="900 22px system-ui, sans-serif",n.textAlign="center",n.fillText(a?"PASSED":"NOT YET",0,0),n.font="800 14px system-ui, sans-serif",n.fillText("⭐ ROAD SAFE ⭐",0,22),n.restore(),n.fillStyle="#475569",n.font="600 15px system-ui, sans-serif",n.textAlign="left",n.fillText("Cycle Champs • for fun, not a government document",28,r-22)}const an=.5,Js=25/Math.PI,wx=.5,Rt=1.8,Ln=Rt+3.2;function bx(i){return()=>{i=i+1831565813|0;let t=Math.imul(i^i>>>15,1|i);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}class sr{constructor(){q(this,"base",[0]);q(this,"feat",[0]);q(this,"coins",[]);q(this,"rocks",[]);q(this,"logs",[]);q(this,"lips",[]);q(this,"mud",[]);q(this,"puddles",[]);q(this,"bridge",null);q(this,"stickers",[]);q(this,"checkpoints",[])}get s(){return(this.base.length-1)*an}get y(){return this.base[this.base.length-1]}n(t){return Math.max(1,Math.round(t/an))}feature(t,e,n,s="linear"){const r=this.y,o=this.n(t);for(let a=1;a<=o;a++){const c=a/o,l=s==="flat"?0:s==="linear"?c:s==="ease"?(1-Math.cos(Math.PI*c))/2:c*c;this.push(r,e+(n-e)*l)}return this}lip(){return this.lips.push(this.s),this}sticker(t,e,n,s=.9){return this.stickers.push({id:t,s:this.s+e,d:n,lift:s}),this}streamBridge(t,e,n){const s=this.y,r=this.s,o=this.n(t),a=c=>(1-Math.cos(Math.PI*c))/2;for(let c=1;c<=o;c++)this.push(s-n*a(c/o),n*a(c/o));for(let c=0,l=this.n(e);c<l;c++)this.push(s-n,n);for(let c=1;c<=o;c++)this.push(s-n*(1-a(c/o)),n*(1-a(c/o)));return this.bridge=[r,this.s],this}push(t,e=0){this.base.push(t),this.feat.push(e)}flat(t){const e=this.y;for(let n=0,s=this.n(t);n<s;n++)this.push(e);return this}slope(t,e){const n=this.y,s=this.n(t);for(let r=1;r<=s;r++)this.push(n+e*(1-Math.cos(Math.PI*r/s))/2);return this}hills(t,e){const n=this.y,s=this.n(t);for(let r=1;r<=s;r++){const o=r*an,a=Math.min(1,o/30,(t-o)/30),c=e.reduce((l,[h,u])=>l+h*Math.sin(2*Math.PI*o/u),0);this.push(n+c*Math.max(0,a))}return this}tabletop(t,e,n,s){const r=this.y,o=this.n(t);for(let c=1;c<=o;c++)this.push(r,e*(c/o)**2);for(let c=0,l=this.n(n);c<l;c++)this.push(r,e);const a=this.n(s);for(let c=1;c<=a;c++)this.push(r,e*(1+Math.cos(Math.PI*c/a))/2);return this}gap(t,e,n,s){const r=this.y,o=this.n(t);for(let a=1;a<=o;a++)this.push(r,e*(a/o)**2);return this.slope(n,-s)}log(t=1.2,e=.32){const n=this.y;this.logs.push(this.s+t/2);const s=this.n(t);for(let r=1;r<=s;r++)this.push(n,e*(1-Math.cos(2*Math.PI*r/s))/2);return this}rollers(t,e,n){const s=this.y,r=this.n(e);for(let o=0;o<t;o++)for(let a=1;a<=r;a++)this.push(s,n*(1-Math.cos(2*Math.PI*a/r))/2);return this}coinRun(t,e,n=0,s=.8){for(let r=0;r<t;r++)this.coins.push({s:this.s+r*e,d:n,lift:s});return this}airCoins(t,e=0){for(const[n,s]of t)this.coins.push({s:this.s+n,d:e,lift:s});return this}checkpoint(){return this.checkpoints.push(this.s),this}}const Ex=[[40,0],[60,-70],[40,0],[55,60],[60,0],[70,-90],[50,0],[40,55],[90,0],[60,-60],[40,0],[80,80],[60,0],[50,-55],[70,0],[60,75],[80,0],[50,-65],[100,0],[60,70],[200,0]];function Cu(){const i=new sr;i.flat(10).coinRun(5,4).flat(20),i.slope(70,6).coinRun(4,6,.6).flat(20).checkpoint(),i.slope(90,-14).coinRun(6,8,-.5).flat(15),i.airCoins([[5,1.4],[7,1.6],[9,1.1]]),i.tabletop(4,1.4,4,5).flat(25);const t=i.s;i.sticker("bear",19,1.35),i.flat(10).slope(90,-4).flat(10);for(let o=0;o<6;o++){const a=o%2?1:-1;i.rocks.push({s:t+12+o*14,d:a*1.15,r:.45}),i.coins.push({s:t+12+o*14,d:-a*1,lift:.8})}i.log().flat(12).log().flat(12).log().flat(10),i.slope(80,8).coinRun(5,8,-.4).flat(15).checkpoint(),i.sticker("deer",60,-1.5).coinRun(8,10,.5).slope(120,-20).flat(10),i.airCoins([[5,2.5],[8,3.3],[10,3],[12,1.9]]).sticker("eagle",9,0,3.3),i.gap(4,1.2,12,2.5).flat(30),i.coinRun(4,12,0,1.3).rollers(4,12,.7).flat(15).checkpoint(),i.hills(150,[[2.5,75],[.8,25]]).coinRun(5,10,.7),i.slope(60,-8),i.airCoins([[6,1.4],[8,1.6],[9.5,1.3]]),i.tabletop(5,1.8,5,7).flat(25).checkpoint();const e=i.s;i.flat(40);for(const[o,a]of[[8,1.15],[22,-1.15],[36,1.15]])i.rocks.push({s:e+o,d:a,r:.45});i.coinRun(5,10,0).slope(80,-6).flat(20);const n=i.s;i.flat(70);const s=bx(11),r=[];for(let o=-20;o<i.s+40;o+=3)for(const a of[-1,1]){const c=Ln+1.2+s()*4;r.push({s:o+s()*2,d:a*c,k:.8+s()*.6}),s()<.8&&r.push({s:o+s()*3,d:a*(Ln+6+s()*38),k:.8+s()*.9})}return rr(i,"forest",Ex,n,r)}function rr(i,t,e,n,s=[],r=0){const o=i.base.length,a=(o-1)*an,c=new Float32Array(o),l=new Float32Array(o),h=new Float32Array(o);let u=0,f=e[0][0],m=0;for(let g=1;g<o;g++){for(;f<=0&&u<e.length-1;)u++,f+=e[u][0];const _=e[u][1];m+=_?an/_:0,f-=an,c[g]=m,l[g]=l[g-1]+Math.sin(m)*an,h[g]=h[g-1]-Math.cos(m)*an}return{kind:t,lapLength:r,base:Float32Array.from(i.base),feat:Float32Array.from(i.feat),heading:c,px:l,pz:h,length:a,rocks:i.rocks,logs:i.logs,lips:i.lips,mud:i.mud,puddles:i.puddles,bridge:i.bridge,stickers:i.stickers,coins:i.coins,trees:s,checkpoints:[3,...i.checkpoints],finishS:n}}function Je(i,t){const e=t/an,n=i.length-1;if(e<=0)return i[0];if(e>=n)return i[n];const s=Math.floor(e),r=e-s;return i[s]*(1-r)+i[s+1]*r}function pe(i,t,e){const n=Math.abs(e);if(i.kind==="pump"){const l=n<=Rt?1:Math.max(0,1-(n-Rt)/.8),h=(Je(i.heading,t+3)-Je(i.heading,t-3))/6,f=Math.max(0,-Math.sign(h)*Math.min(e,Math.sign(e)*Rt))*wx*Math.min(1,Math.abs(h)*Js)*l;return Je(i.base,t)+Je(i.feat,t)*l+f}if(i.kind==="park"){const l=n<=Rt?1:Math.max(0,1-(n-Rt)/.12);return Je(i.base,t)+Je(i.feat,t)*l}const s=n<=Rt?1:Math.max(0,1-(n-Rt)/(i.kind==="mud"?.15:.6)),o=.06*Math.max(0,n-Rt-1)**1.3,a=Math.min(1,Math.max(0,(n-Ln)/12)),c=(Math.sin(t*.07+e*.11)+Math.sin(t*.023-e*.05)*1.6+Math.sin(e*.21+t*.13)*.4)*2.2*a;return Je(i.base,t)+Je(i.feat,t)*s+o+c}const Ei=.6;function Tx(i,t){if(i.kind!=="forest"&&i.kind!=="mud")return Rt-.35;const e=i.bridge;if(e){if(t>=e[0]&&t<=e[1])return Ei;if(t>e[0]-8&&t<e[0])return Ei+(e[0]-t)/8*(Ln-Ei);if(t>e[1]&&t<e[1]+4)return Ei+(t-e[1])/4*(Ln-Ei)}return Ln}function Ax(i,t,e){return Math.abs(e)<=Rt+.5&&i.mud.some(([n,s])=>t>=n&&t<=s)}function Fe(i,t){return Je(i.heading,t)}function _e(i,t,e){const n=Je(i.heading,t),s=Je(i.px,t),r=Je(i.pz,t);return[s+Math.cos(n)*e,r+Math.sin(n)*e]}function Rx(i,t){return(Je(i.heading,t+1)-Je(i.heading,t-1))/2}const Cx=[[40,0],[50,70],[40,0],[60,-80],[60,0],[40,60],[70,0],[50,-70],[60,0],[50,75],[300,0]];function Px(){const i=new sr;i.flat(10).coinRun(4,4).flat(10),i.slope(40,2).flat(8);let t=i.s;for(let c=0;c<6;c++)i.coins.push({s:t+4+c*7,d:c%2?1.05:-1.05,lift:.8});i.sticker("peacock",32,1.45).slope(45,-3),i.mud.push([t,i.s]),i.flat(10).checkpoint();const e=i.s;for(let c=0;c<4;c++){const l={s:e+8+c*12,d:c%2?1.05:-1.05,r:.95};i.puddles.push(l),i.coins.push({s:l.s,d:l.d,lift:.8})}i.flat(56),i.slope(50,4).coinRun(4,8,.4).flat(10).checkpoint(),i.coinRun(5,8,-.3).slope(60,-6).flat(12),i.coinRun(3,4,0,.8),i.sticker("elephant",11,0).streamBridge(4,14,1.6).flat(12).checkpoint(),i.airCoins([[4.5,1.4],[6.5,1.6],[8.5,1.2]]),i.tabletop(4,1.2,3,4).flat(15),i.log().flat(10).log().flat(12),t=i.s;for(let c=0;c<6;c++)i.coins.push({s:t+6+c*9,d:c%2?1.05:-1.05,lift:.8});i.slope(60,-5),i.mud.push([t,i.s]),i.flat(15).checkpoint();const n=i.s;for(let c=0;c<3;c++){const l={s:n+8+c*11,d:c%2?-1.05:1.05,r:.95};i.puddles.push(l),i.coins.push({s:l.s,d:l.d,lift:.8}),c===2&&i.stickers.push({id:"mango",s:l.s+1.2,d:l.d,lift:.9})}i.flat(45),i.coinRun(4,10,0).hills(80,[[1.2,40],[.4,15]]),i.flat(15);const s=i.s;i.flat(60);const r=[];let o=5;const a=()=>(o=(o*9301+49297)%233280)/233280;for(let c=-20;c<i.s+40;c+=6)for(const l of[-1,1])a()<.6&&r.push({s:c+a()*4,d:l*(7+a()*6),k:.9+a()*.5}),a()<.5&&r.push({s:c+a()*4,d:l*(25+a()*30),k:.9+a()*.6});return rr(i,"mud",Cx,s,r)}function Lx(i){return new Promise((t,e)=>{const n=new Image,s=URL.createObjectURL(i);n.onload=()=>{URL.revokeObjectURL(s);const r=document.createElement("canvas"),o=96;r.width=r.height=o;const a=r.getContext("2d");a.drawImage(n,0,0,o,o);const c=a.getImageData(0,0,o,o).data,l=new Array(36).fill(0).map(()=>({w:0,r:0,g:0,b:0}));for(let f=0;f<o;f++)for(let m=0;m<o;m++){const g=(f*o+m)*4,_=c[g]/255,p=c[g+1]/255,d=c[g+2]/255,y=Math.max(_,p,d),b=Math.min(_,p,d),w=y===0?0:(y-b)/y;if(w<.35||y<.2)continue;let C=0;y===_?C=(p-d)/(y-b)%6:y===p?C=(d-_)/(y-b)+2:C=(_-p)/(y-b)+4;const A=Math.floor((C*60+360)%360/360*36),S=1-Math.hypot(m/o-.5,f/o-.5),M=w*y*S*S,x=l[A];x.w+=M,x.r+=c[g]*M,x.g+=c[g+1]*M,x.b+=c[g+2]*M}const h=l.reduce((f,m)=>m.w>f.w?m:f);if(h.w===0)return e(new Error("No clear colour found"));const u=f=>Math.round(f/h.w).toString(16).padStart(2,"0");t(`#${u(h.r)}${u(h.g)}${u(h.b)}`)},n.onerror=()=>e(new Error("Could not read the photo")),n.src=s})}const Ko=28,Bs=25,Zo=3;function Dx(){const i=new sr;for(let n=0;n<Zo;n++)i.flat(2).rollers(1,8,.6).coinRun(1,0,0,.8),i.airCoins([[4,1.3]]).rollers(2,8,.5).airCoins([[-4,1.2],[-12,1.2]]).flat(2),i.flat(Bs),i.flat(1).airCoins([[4,1.3],[12,1.3]]).rollers(2,8,.55).airCoins([[5,1.6]]).rollers(1,10,.75).flat(1),i.flat(Bs),n===1&&i.sticker("baseball",-60,1.2).sticker("taj",-40,-1.2),n===2&&i.sticker("tiger",-84,-1.2),n<Zo-1&&i.checkpoint();const t=i.s;i.flat(20);const e=[];for(let n=0;n<=Zo;n++)e.push([Ko,0],[Bs,Js],[Ko,0],[Bs,Js]);return rr(i,"pump",e,t,[],Ko*2+Bs*2)}const Pu="cycle-champs:v1",Ix="pedal-pals:v1",Lu=[{color:"#ef4444",stars:0},{color:"#3b82f6",stars:0},{color:"#22c55e",stars:2},{color:"#a855f7",stars:4},{color:"#f97316",stars:6},{color:"#ec4899",stars:8},{color:"#14b8a6",stars:10},{color:"#eab308",stars:12}],Du=[{color:"#facc15",stars:0},{color:"#f43f5e",stars:0},{color:"#0ea5e9",stars:3},{color:"#84cc16",stars:5},{color:"#ffffff",stars:7},{color:"#7c3aed",stars:9},{color:"#111827",stars:11}],Ux=()=>(typeof navigator<"u"?navigator.languages??[navigator.language]:[]).some(t=>/-IN$|^(hi|ta|te|mr|bn|gu|kn|ml|pa)\b/i.test(t))?"left":"right",Jo={stars:{},best:{},bike:Lu[0].color,helmet:Du[0].color,muted:!1,side:Ux(),ghosts:{},stickers:[],kidName:"",licence:null,tyre:"allround",frame:"standard",pet:"none",voice:"off",photoColor:null,tracks:[],family:[]};function Nx(){try{const i=localStorage.getItem(Pu)??localStorage.getItem(Ix);return i?{...Jo,...JSON.parse(i)}:{...Jo}}catch{return{...Jo}}}function Fx(i){try{localStorage.setItem(Pu,JSON.stringify(i))}catch{}}function Iu(i){return Object.values(i.stars).reduce((t,e)=>t+e,0)}function Ox(i){i.CapacitorUtils.Synapse=new Proxy({},{get(t,e){return new Proxy({},{get(n,s){return(r,o,a)=>{const c=i.Capacitor.Plugins[e];if(c===void 0){a(new Error(`Capacitor plugin ${e} not found`));return}if(typeof c[s]!="function"){a(new Error(`Method ${s} not found in Capacitor plugin ${e}`));return}(async()=>{try{const l=await c[s](r);o(l)}catch(l){a(l)}})()}}})}})}function kx(i){i.CapacitorUtils.Synapse=new Proxy({},{get(t,e){return i.cordova.plugins[e]}})}function Bx(i=!1){typeof window>"u"||(window.CapacitorUtils=window.CapacitorUtils||{},window.Capacitor!==void 0&&!i?Ox(window):window.cordova!==void 0&&kx(window))}var Za;(function(i){i.Documents="DOCUMENTS",i.Data="DATA",i.Library="LIBRARY",i.Cache="CACHE",i.External="EXTERNAL",i.ExternalStorage="EXTERNAL_STORAGE",i.ExternalCache="EXTERNAL_CACHE",i.LibraryNoCloud="LIBRARY_NO_CLOUD",i.Temporary="TEMPORARY"})(Za||(Za={}));var hh;(function(i){i.UTF8="utf8",i.ASCII="ascii",i.UTF16="utf16"})(hh||(hh={}));const zx=Di("Filesystem",{web:()=>er(()=>import("./web-vjo-rJ-m.js"),[],import.meta.url).then(i=>new i.FilesystemWeb)});Bx();const Gx=Di("Share",{web:()=>er(()=>import("./web-Bn4SMSyV.js"),[],import.meta.url).then(i=>new i.ShareWeb)});function Hx(i){return new Promise((t,e)=>{const n=new FileReader;n.onload=()=>t(String(n.result).split(",")[1]),n.onerror=()=>e(n.error),n.readAsDataURL(i)})}async function Uu(i,t,e){if(Ci.isNativePlatform()){const r=await Hx(i),o=await zx.writeFile({path:t,data:r,directory:Za.Cache});await Gx.share({title:e,files:[o.uri]});return}const n=URL.createObjectURL(i),s=document.createElement("a");s.href=n,s.download=t,s.click(),setTimeout(()=>URL.revokeObjectURL(n),5e3)}function Nu(i,t,e){return new Promise(n=>{i.toBlob(async s=>{s&&await Uu(s,t,e).catch(()=>{}),n()},"image/png")})}function Vx(){const i=new sr;i.feature(.5,5,5).feature(9,5,5,"flat"),i.feature(9,5,0,"ease").feature(3,0,0,"flat"),i.airCoins([[3,1.4],[5.5,2.4],[8,2.6],[10.5,2.2]]).sticker("liberty",6.8,0,2.6),i.feature(4.5,0,2,"kicker").lip().feature(4.5,2,2,"flat").feature(8,2,0,"ease"),i.feature(4,0,0,"flat").coinRun(3,2.5).feature(8,0,0,"flat").checkpoint(),i.airCoins([[3,1.2],[5,1.8],[7,1.6]]),i.feature(4,0,1.1,"kicker").lip().feature(3,1.1,1.1,"flat").feature(5,1.1,0,"ease"),i.feature(12,0,0,"flat"),i.coinRun(3,1.6,0,1.6).sticker("cricket",5,1,.9),i.feature(3,0,1,"linear").lip().feature(4,1,1,"flat").feature(3,1,0,"linear"),i.feature(12,0,0,"flat").checkpoint(),i.airCoins([[2.5,1.6],[4,2],[5.5,1.6]]).sticker("board",4,0,2),i.feature(3,0,1.2,"linear").lip().feature(3,1.2,0,"linear"),i.feature(14,0,0,"flat"),i.airCoins([[3,1.4],[5,2],[7,1.8]]),i.feature(4,0,1.3,"kicker").lip().feature(3,1.3,1.3,"flat").feature(5,1.3,0,"ease"),i.feature(10,0,0,"flat");const t=i.s;return i.feature(30,0,0,"flat"),rr(i,"park",[[1e3,0]],t)}class Fu{constructor(t,e){q(this,"renderer");q(this,"scene",new _c);q(this,"camera",new je(32,1,.1,50));q(this,"rig");this.renderer=new gu({canvas:t,antialias:!0,alpha:!0,preserveDrawingBuffer:!0}),this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2)),this.renderer.setSize(t.width,t.height,!1),this.camera.aspect=t.width/t.height,this.camera.position.set(3.4,1.8,-1.2),this.camera.lookAt(0,.85,-.05),this.camera.updateProjectionMatrix(),this.scene.add(new Sc("#ffffff","#7a8a6a",1.4));const n=new wc("#ffffff",1.4);n.position.set(3,5,2),this.scene.add(n);const s=new tt(new lo(1.4,32),st("#7dc383"));s.rotation.x=-Math.PI/2,this.scene.add(s),this.rig=uo(e),os(this.rig,.4),this.scene.add(this.rig.root)}show(t){this.rig.bikeMat.color.set(t.bike),this.rig.helmetMat.color.set(t.helmet),this.renderer.render(this.scene,this.camera)}}const Mi=10,Ou=.05,uh=.6,Tc="ABCDEFGHIJKLMNOPQRSTUVWXY",ku=12,Bu=70,io="cyclechamps://track/";function Wx(i,t,e){if(i.length<2)return null;let n=0;for(let u=1;u<i.length;u++)n+=Math.hypot(i[u][0]-i[u-1][0],i[u][1]-i[u-1][1]);const s=Math.max(ku,Math.min(Bu,Math.round(n/18)));if(n<120)return null;const r=n/s,o=[i[0]];let a=r;for(let u=1;u<i.length&&o.length<=s;u++){let[f,m]=i[u-1];const[g,_]=i[u];let p=Math.hypot(g-f,_-m);for(;p>=a&&o.length<=s;){const d=a/p;f+=(g-f)*d,m+=(_-m)*d,o.push([f,m]),p-=a,a=r}a-=p}const c=[];for(let u=1;u<o.length;u++)c.push(Math.atan2(o[u][0]-o[u-1][0],-(o[u][1]-o[u-1][1])));let l="";for(let u=0;u<c.length;u++){let f=u===0?0:c[u]-c[u-1];for(;f>Math.PI;)f-=Math.PI*2;for(;f<-Math.PI;)f+=Math.PI*2;const m=Math.round(Math.max(-uh,Math.min(uh,f))/Ou);l+=Tc[m+12]}const h=Math.floor(Math.random()*1296).toString(36).padStart(2,"0");return`${e}${t}${h}${l}`}function Xx(i){return new RegExp(`^[fm][jbm][0-9a-z]{2}[${Tc}]{${ku},${Bu}}$`).test(i)}function $x(i){return[...i.slice(4)].map(t=>(Tc.indexOf(t)-12)*Ou)}function qx(i){const t=i[0],e=i[1];let n=parseInt(i.slice(2,4),36)+1;const s=()=>(n=(n*9301+49297)%233280)/233280,r=$x(i),o=new sr;r.forEach((h,u)=>{const f=o.s,m=Math.abs(h)<.16;if(u<2||u>=r.length-2)o.flat(Mi);else{const g=e==="m"?s()<.5?"j":"b":e;g==="j"&&m&&u%3===0?(o.airCoins([[4,1.3],[6,1.5]]),o.flat(1).tabletop(3,1,2,3).flat(1)):g==="b"?o.rollers(1,Mi,.35+s()*.25):o.slope(Mi,(s()-.5)*1.6),u%2===0&&o.coins.push({s:f+5,d:(s()-.5)*1.6,lift:.8})}t==="m"&&u>2&&u<r.length-3&&(s()<.2?o.mud.push([f,f+Mi]):s()<.15&&o.puddles.push({s:f+5,d:(s()-.5)*1.6,r:.9}))});const a=o.s-Mi*1.5;o.flat(40);const c=r.map(h=>[Mi,Math.abs(h)<.001?0:Mi/h]);c.push([400,0]);const l=[];for(let h=-10;h<o.s+30;h+=4)for(const u of[-1,1])l.push({s:h+s()*3,d:u*(Ln+1.4+s()*5),k:.8+s()*.6}),s()<.6&&l.push({s:h+s()*3,d:u*(Ln+8+s()*30),k:.8+s()*.8});return rr(o,t==="m"?"mud":"forest",c,a,l)}const fh=["No Hander","Superman","Tabletop","360 Spin"],Yx=.6,kr=.05,jx=6,Yr={tricks:!1,tiltAcc:9,tiltMax:4,assistP:18,assistD:5},Ja={tricks:!1,pump:!0,timeTargets:[75,63],tiltAcc:9,tiltMax:4,assistP:18,assistD:5},Qa={tricks:!0,scoreTargets:[1500,2400],tiltAcc:24,tiltMax:10,assistP:45,assistD:12},Qo=9.8,Kx=3.5,dh=8,Zx=4,Jx=8,Qx=.2,tv=.012,ev=2.5,nv=.5,iv=2.4,sv=2,rv=.75,ov=1.5,av=.45,ph=1.2,cv=.7,lv=3,hv=18,uv=.6,fv=4.5,dv=3,pv=1/240;function mh(i){for(;i>Math.PI;)i-=Math.PI*2;for(;i<-Math.PI;)i+=Math.PI*2;return i}class zs{constructor(t=Cu(),e=Yr,n=ic,s=[]){q(this,"layout");q(this,"opts");q(this,"gear");q(this,"rider");q(this,"time",0);q(this,"score",0);q(this,"crashes",0);q(this,"violations",0);q(this,"checkpoint");q(this,"coins");q(this,"finished",!1);q(this,"finishedFor",0);q(this,"result",null);q(this,"sounds",[]);q(this,"message",null);q(this,"messageColor","#fff");q(this,"messageT",0);q(this,"hint",null);q(this,"hintT",0);q(this,"offTrailT",0);q(this,"pedalWhileRolling",!1);q(this,"bestLap",null);q(this,"newBest",!1);q(this,"lapIndex",0);q(this,"lapStart",0);q(this,"recording",[]);q(this,"splashes",[]);q(this,"splashed",new Set);q(this,"mudHinted",new Set);q(this,"recordT",0);q(this,"stickerGot");q(this,"stickerFinds",[]);q(this,"voice",[]);q(this,"splashText","Splash! +25");q(this,"petSaidAt",-10);q(this,"petGrabAt",-10);q(this,"replayReady",null);q(this,"history",[]);q(this,"replayCountdown",0);q(this,"replayAir",0);q(this,"runGhosts",[]);q(this,"runSamples",[]);q(this,"runRecordT",0);this.layout=t,this.opts=e,this.gear=n,this.stickerGot=t.stickers.map(r=>s.includes(r.id)),this.checkpoint=this.layout.checkpoints[0],this.rider=this.spawn(this.checkpoint),this.coins=this.layout.coins.map(()=>!1)}get trickTime(){return Yx*this.gear.trickTime}get coinCount(){return this.coins.filter(Boolean).length}get totalCoins(){return this.layout.coins.length}get laps(){return this.layout.lapLength?Math.round(this.layout.finishS/this.layout.lapLength):0}get lap(){return this.layout.lapLength?Math.min(this.laps,Math.floor(this.rider.s/this.layout.lapLength)+1):0}spawn(t){const e=pe(this.layout,t,0),n=this.opts.pump?fv:0;return{s:t,d:0,rel:0,v:n,y:e,vy:0,grounded:!0,pitch:this.slopeAngle(t,0),pitchVel:0,airTime:0,crank:0,crashed:!1,crashT:0,upArmed:!1,downArmed:!1,airRot:0,trick:null,trickT:0,trickIndex:0,airTricks:[]}}get mudGrip(){return Math.max(.15,1-(1-av)*this.gear.mud)}slopeAngle(t,e){return Math.atan((pe(this.layout,t+.4,e)-pe(this.layout,t-.4,e))/.8)}say(t,e="#ffffff",n=2){this.message=t,this.messageColor=e,this.messageT=n}ringBell(){this.sounds.push("bell")}update(t,e){this.messageT>0&&(this.messageT-=t)<=0&&(this.message=null),this.hintT>0&&(this.hintT-=t)<=0&&(this.hint=null),this.finished?(this.finishedFor+=t,e={up:!1,down:!0,left:!1,right:!1}):this.time+=t;const n=this.rider;if(n.crashed){n.crashT+=t,n.crashT>ov&&(this.rider=this.spawn(this.checkpoint));return}let s=t;for(;s>1e-6&&!this.rider.crashed;){const r=Math.min(pv,s);this.step(r,e),s-=r}this.afterStep(t)}step(t,e){const n=this.rider,s=this.layout,r=Math.abs(n.d)>Rt,o=n.grounded&&Ax(s,n.s,n.d),a=(e.right?1:0)-(e.left?1:0);if(a){const c=a*nv-n.rel;n.rel+=Math.sign(c)*Math.min(Math.abs(c),iv*(o?this.mudGrip:1)*t)}else{const c=Math.max(-.35,Math.min(.35,-n.d*.6));n.rel+=(c-n.rel)*sv*t}if(s.kind!=="pump"&&(n.rel-=Rx(s,n.s)*n.v*t),o&&(n.rel+=Math.sin(this.time*2.3+n.s*.7)*.6*this.gear.mud*t*Math.min(1,n.v/6)),n.rel=Math.max(-.9,Math.min(.9,n.rel)),n.grounded){const c=this.slopeAngle(n.s,n.d);let l=-Qo*Math.sin(c)-Math.sign(n.v)*Qx-tv*n.v*Math.abs(n.v);r&&(l-=Math.sign(n.v)*ev),o&&(l-=Math.sign(n.v)*ph*this.gear.mud);const h=!this.opts.pump||n.v<dv;this.pedalWhileRolling=e.up&&!h;const u=o?Math.max(.3,1-(1-cv)*this.gear.mud):1,f=s.kind==="park"||s.kind==="pump";let m=dh*(f?this.gear.speed:this.gear.dirtSpeed);if(o){const b=dh*Math.max(.35,1-.35*this.gear.mud);m=Math.min(m,b),n.v>b&&(l-=ph*2)}if(e.up&&h&&n.v<(r?Zx:m)&&(l+=Kx*u),this.opts.pump&&e.pump&&(l-=hv*Math.sin(c)*(c>0?uv:1)),n.v+=l*t,e.down){const b=Jx*(o?.5:1)*t;n.v=Math.abs(n.v)<=b?0:n.v-Math.sign(n.v)*b}!e.up&&Math.abs(n.v)<.05&&Math.abs(c)<.03&&(n.v=0);const g=Math.atan((pe(s,n.s,n.d)-pe(s,n.s-.3,n.d))/.3),_=n.v*Math.cos(g),p=n.s+_*Math.cos(n.rel)*t,d=n.d+_*Math.sin(n.rel)*t,y=n.y+n.v*Math.sin(g)*t-.5*Qo*t*t;if(n.v>1.5&&pe(s,p,d)<y-.008){n.grounded=!1,n.vy=n.v*Math.sin(g),n.v=_,n.pitch=g,n.s=p,n.d=d,n.y=y,n.pitchVel=0,n.airTime=0,n.airRot=0,n.airTricks=[],n.upArmed=!e.up,n.downArmed=!e.down,this.fence();return}n.s=p,n.d=d,this.fence(),n.y=pe(s,n.s,n.d),n.pitch=this.slopeAngle(n.s,n.d),n.crank+=n.v*t/.33}else{n.vy-=Qo*t,n.y+=n.vy*t,n.s+=n.v*Math.cos(n.rel)*t,n.d+=n.v*Math.sin(n.rel)*t,this.fence(),n.airTime+=t,e.up||(n.upArmed=!0),e.down||(n.downArmed=!0);const c=e.up&&n.upArmed,l=e.down&&n.downArmed,h=this.opts.tiltAcc*this.gear.spin,u=this.opts.tiltMax*this.gear.spin;if(c&&(n.pitchVel-=h*t),l&&(n.pitchVel+=h*t),!c&&!l){const m=this.slopeAngle(n.s+n.v*.15,n.d);n.pitchVel+=(mh(m-n.pitch)*this.opts.assistP-n.pitchVel*this.opts.assistD)*t}n.pitchVel=Math.max(-u,Math.min(u,n.pitchVel)),n.pitch+=n.pitchVel*t,n.airRot+=n.pitchVel*t,n.trick?(n.trickT+=t,n.trickT>=this.trickTime&&(n.airTricks.push(n.trick),n.trick=null)):e.trick&&this.opts.tricks&&(n.trick=fh[n.trickIndex++%fh.length],n.trickT=0,this.sounds.push("trick"));const f=pe(s,n.s,n.d);if(n.y<=f){const m=this.slopeAngle(n.s,n.d);if(Math.abs(mh(n.pitch-m))>rv+this.gear.landing)return this.crash("Oops! Land on both wheels.");n.v=n.v*Math.cos(m)+n.vy*Math.sin(m),n.y=f,n.vy=0,n.pitch=m,n.grounded=!0,n.trick&&(n.trick=null,this.say("Too late! Start tricks earlier","#fed7aa",1.4)),this.scoreLanding(n)}}this.hitObstacles()}scoreLanding(t){if((t.airTime>=.9||this.opts.tricks&&(t.airTricks.length>0||Math.abs(t.airRot)>4))&&(this.replayCountdown=.9,this.replayAir=t.airTime),!this.opts.scoreTargets){if(t.airTime>.45){const r=50+Math.floor(t.airTime/.5)*50;this.score+=r,this.say(`Big air! +${r}`,"#fde68a",1.2),this.sounds.push("good")}else t.airTime>.15&&this.sounds.push("land");return}if(t.airTime<.35)return;const e=[];let n=Math.floor(t.airTime/.5)*50;const s=Math.round(t.airRot/(Math.PI*2));s&&(n+=500*Math.abs(s),e.push(`${Math.abs(s)>1?`${Math.abs(s)}x `:""}${s>0?"Backflip":"Frontflip"}`));for(const r of t.airTricks)n+=150,e.push(r);n*=Math.max(1,e.length),!(n<=0)&&(this.score+=n,this.say(`${e.length?e.join(" + "):"Big air"}  +${n}`,e.length?"#fde047":"#ffffff",1.6),this.sounds.push(e.length?"good":"land"),e.length&&this.voice.push(s?"flip":"trick"))}fence(){const t=this.rider,e=Tx(this.layout,t.s);Math.abs(t.d)>e&&(e<Ln&&this.layout.kind!=="park"&&this.layout.kind!=="pump"&&this.hintT<=0&&(this.hint="Ride in the middle of the bridge!",this.hintT=2),t.d=Math.sign(t.d)*e,t.rel*=-.3,t.v*=.7),t.s=Math.max(1,Math.min(this.layout.length-1,t.s))}hitObstacles(){const t=this.rider;for(const e of this.layout.rocks){const n=t.s-e.s,s=t.d-e.d;if(n*n+s*s<(e.r+.3)**2&&t.y<pe(this.layout,e.s,e.d)+e.r*1.4){if(Math.abs(t.v)>4+this.gear.rocks)return this.crash("Oops! Steer around the rocks.");t.s-=Math.sign(t.v||1)*.05,t.v=0}}}crash(t){const e=this.rider;e.crashed=!0,e.crashT=0,this.crashes++,this.sounds.push("crash"),this.voice.push("crash"),this.say(t,"#fecaca",2)}afterStep(t){const e=this.rider;for(this.history.push({t:this.time,s:e.s,d:e.d,y:e.y,pitch:e.pitch,rel:e.rel,crank:e.crank,trick:e.trick,trickT:e.trickT});this.history.length&&this.history[0].t<this.time-jx;)this.history.shift();if(this.replayCountdown>0&&(this.replayCountdown-=t)<=0){const a=this.time-this.replayAir-1.9;this.replayReady=this.history.filter(c=>c.t>=a)}if(!this.finished&&this.time>=this.runRecordT&&(this.runSamples.push(+e.s.toFixed(2),+e.d.toFixed(2),+e.y.toFixed(2),+e.pitch.toFixed(3)),this.runRecordT+=kr),e.crashed)return;this.opts.pump&&this.pedalWhileRolling&&this.hintT<=0&&(this.hint="No pedals here! Hold PUMP when going downhill.",this.voice.push("pump"),this.hintT=2.5);const n=this.layout;n.puddles.forEach((a,c)=>{this.splashed.has(c)||!e.grounded||Math.abs(e.s-a.s)<a.r&&Math.abs(e.d-a.d)<a.r+.2&&(this.splashed.add(c),e.v*=.9,this.score+=25,this.splashes.push({s:e.s,d:e.d}),this.say(this.splashText,"#bae6fd",1.2),this.voice.push("splash"),this.sounds.push("splash"))}),n.mud.forEach(([a,c],l)=>{!this.mudHinted.has(l)&&e.s>=a&&e.s<=c&&(this.mudHinted.add(l),this.hint="Slippery mud! Steer gently and slow down.",this.voice.push("mud"),this.hintT=2.5)});const s=(n.kind==="forest"||n.kind==="mud")&&Math.abs(e.d)>Rt+.2&&e.grounded;this.offTrailT=s?this.offTrailT+t:0,this.offTrailT>.8&&this.hintT<=0&&(this.hint="Stay on the brown trail, grass is slow!",this.hintT=2.5);const r=Math.max(1.1,this.gear.magnet),o=Math.max(.9,this.gear.magnet);this.layout.coins.forEach((a,c)=>{if(this.coins[c])return;const l=pe(this.layout,a.s,a.d)+a.lift,h=Math.abs(a.s-e.s),u=Math.abs(a.d-e.d);if(h<r&&u<o&&Math.abs(e.y+.8-l)<1.1+(this.gear.magnet?.4:0)){const f=h>=1.1||u>=.9;if(f&&this.time-this.petGrabAt<lv)return;this.coins[c]=!0,this.score+=50,this.sounds.push("coin"),f&&(this.petGrabAt=this.time,this.time-this.petSaidAt>8&&(this.petSaidAt=this.time,this.say(`${this.gear.petName} grabbed a coin! 🐾`,"#fef3c7",1.2)))}}),this.layout.stickers.forEach((a,c)=>{if(this.stickerGot[c])return;const l=pe(this.layout,a.s,a.d)+a.lift;Math.abs(a.s-e.s)<1.1&&Math.abs(a.d-e.d)<.9&&Math.abs(e.y+.8-l)<.8&&(this.stickerGot[c]=!0,this.stickerFinds.push(a.id),this.sounds.push("good"),this.voice.push("sticker"))});for(const a of this.layout.checkpoints)a>this.checkpoint&&e.s>=a&&(this.checkpoint=a,a>this.layout.checkpoints[0]&&!this.layout.lapLength&&(this.say("Checkpoint!","#a7f3d0",1.2),this.sounds.push("checkpoint")));this.layout.lapLength&&this.recordLap(),!this.finished&&e.s>=this.layout.finishS&&this.finish()}recordLap(){const t=this.rider,e=this.layout.lapLength,n=this.time-this.lapStart,s=Math.floor(t.s/e);if(n>=this.recordT&&(this.recording.push(+(t.s-this.lapIndex*e).toFixed(2),+t.d.toFixed(2),+t.y.toFixed(2),+t.pitch.toFixed(3)),this.recordT+=kr),s<=this.lapIndex)return;const r=this.bestLap;!r||n<r.time?(this.bestLap={time:+n.toFixed(2),samples:this.recording},this.newBest=!0,this.say(r?`New best lap! ${n.toFixed(1)}s 🏆`:`Lap time ${n.toFixed(1)}s, now race your ghost!`,"#fde047",2.2),r&&this.voice.push("newBest"),this.sounds.push("good")):(this.say(`Lap ${n.toFixed(1)}s (+${(n-r.time).toFixed(1)}s behind your ghost)`,"#e0f2fe",2.2),this.sounds.push("lap")),this.lapIndex=s,this.lapStart=this.time,this.recording=[],this.recordT=0}ghostPose(){const t=this.bestLap;if(!t||this.finished)return null;const e=this.time-this.lapStart,n=t.samples.length/4,s=e/kr;if(s>=n-1)return null;const r=Math.floor(s),o=s-r,a=c=>t.samples[r*4+c]*(1-o)+t.samples[(r+1)*4+c]*o;return{s:a(0),d:a(1),y:a(2),pitch:a(3)}}runGhostPoses(){return this.runGhosts.map(t=>{const e=t.samples.length/4,n=Math.min(e-1.001,this.time/kr),s=Math.floor(n),r=n-s,o=a=>t.samples[s*4+a]*(1-r)+t.samples[Math.min(e-1,s+1)*4+a]*r;return{s:o(0),d:o(1),y:o(2),pitch:o(3),name:t.name,color:t.color}})}get lapTime(){return this.time-this.lapStart}finish(){this.finished=!0,this.sounds.push("finish"),this.voice.push("finish");const t=this.coinCount===this.layout.coins.length,e=this.opts.scoreTargets,n=this.opts.timeTargets;this.result={stars:e?1+(this.score>=e[0]?1:0)+(this.score>=e[1]?1:0):n?1+(this.time<=n[0]?1:0)+(this.time<=n[1]?1:0):1+(t?1:0)+(this.crashes===0?1:0),time:this.time,coins:this.coinCount,totalCoins:this.layout.coins.length,score:this.score,crashes:this.crashes,violations:0}}}const Mn=(i,t,e,n=0)=>{const[s,r]=_e(i,t,e);return new I(s,pe(i,t,e)+n,r)},ni=["#ff2d95","#ffd60a","#00c2ff","#7cff3a","#b14bff","#ff7a00"];function mv(i,t,e=!1,n){const s=new Ue({color:"#7d8a92",emissive:"#2b3238",transparent:!0,opacity:.85});if(t.puddles.forEach((M,x)=>{const v=new lo(1,24);v.rotateX(-Math.PI/2),v.scale(M.r*1.25,1,M.r);const E=e?new Ue({color:ni[x%ni.length],emissive:ni[x%ni.length],emissiveIntensity:.35}):s,P=new tt(v,E);P.position.copy(Mn(t,M.s,M.d,.025)),P.rotation.y=-Fe(t,M.s),P.receiveShadow=!0,i.add(P)}),e)for(const M of[8,t.finishS-6,t.finishS+4]){const x=Mn(t,M,-3.2,3.2),v=Mn(t,M,3.2,3.2);for(let E=0;E<14;E++){const P=(E+.5)/14,L=new tt(new bn(.22,.45,3),new cn({color:ni[E%ni.length],side:ze}));L.position.lerpVectors(x,v,P),L.position.y-=Math.sin(Math.PI*P)*.6+.25,L.rotation.x=Math.PI,i.add(L)}i.add(de(x,v,.015,st("#555")))}if(t.bridge){const[M,x]=t.bridge,v=(M+x)/2,E=t.base[Math.round(v/an)],P=new tt(new Ae(140,x-M-3),new Ue({color:"#6f8f8a",emissive:"#1d3a3a",transparent:!0,opacity:.9}));P.rotation.x=-Math.PI/2,P.rotation.z=-Fe(t,v);const[L,N]=_e(t,v,0);P.position.set(L,E+.45,N),i.add(P);const F=[];for(let K=M+.25;K<x;K+=.5){const Y=new Nt(Ei*2+.3,.08,.42);Y.rotateY(-Fe(t,K));const it=Mn(t,K,0,-.03);Y.translate(it.x,it.y,it.z),F.push(Y)}const U=new tt(Ie(F),st("#9c6b3c"));U.castShadow=U.receiveShadow=!0,i.add(U);const O=st("#6b4423"),k=st("#d6c08a");for(const K of[-1,1]){const Y=K*(Ei+.12);let it=null;for(let ct=M;ct<=x+.01;ct+=(x-M)/6){const xt=Mn(t,ct,0),[$,et]=_e(t,ct,Y),ut=new I($,Math.min(xt.y,pe(t,ct,Y))-1.6,et),at=new I($,xt.y+.9,et);i.add(de(ut,at,.06,O)),it&&i.add(de(it,at,.025,k)),it=at}}}const r=st("#c98f5a"),o=st("#b8913f",{flatShading:!0}),a=st("#5b3a1e"),c=[[4,-9],[14,10],[-6,12],[t.finishS+6,-10],[t.finishS-4,11],[t.finishS+18,13]];for(const[M,x]of c){const v=new me,E=new tt(new Nt(3.2,2.2,3.2),r);E.position.y=1.1;const P=new tt(new bn(2.8,1.8,4),o);P.position.y=3.1,P.rotation.y=Math.PI/4;const L=new tt(new Nt(.8,1.4,.05),a);L.position.set(0,.7,1.62),v.add(E,P,L),v.position.copy(Mn(t,M,x)),v.rotation.y=-Fe(t,M)+(x>0?-Math.PI/2:Math.PI/2),v.traverse(N=>N.isMesh?N.castShadow=!0:null),i.add(v)}const l=st("#2b2b2b"),h=st("#d9d2c1");for(const[M,x]of[[60,-16],[160,18],[300,-20],[420,15],[520,-14]]){if(M>t.length)continue;const v=new me,E=new tt(new Nt(.9,.8,1.8),l);E.position.y=.95;const P=new tt(new Nt(.5,.5,.6),l);P.position.set(0,1,-1.1),v.add(E,P);for(const L of[-.3,.3]){const N=new tt(new bn(.06,.4,6),h);N.position.set(L*1.3,1.3,-1.15),N.rotation.z=-L*2.5,v.add(N);for(const F of[-.6,.6]){const U=new tt(new Nt(.16,.6,.16),l);U.position.set(L,.3,F),v.add(U)}}v.position.copy(Mn(t,M,x)),v.rotation.y=M,v.traverse(L=>L.isMesh?L.castShadow=!0:null),i.add(v)}const u=["#ef4444","#f97316","#facc15","#22c55e","#3b82f6","#8b5cf6"],f=Mn(t,t.finishS+25,0);u.forEach((M,x)=>{const v=new tt(new ho(22-x*.9,.45,6,48,Math.PI),new cn({color:M,transparent:!0,opacity:.55,fog:!1}));v.position.copy(f),v.position.y-=2,v.rotation.y=-Fe(t,t.finishS),i.add(v)});const m=1400,g=new Float32Array(m*6),_=new Float32Array(m*3);for(let M=0;M<m;M++)_[M*3]=(Math.random()-.5)*50,_[M*3+1]=Math.random()*25,_[M*3+2]=(Math.random()-.5)*50;const p=new Me;p.setAttribute("position",new ve(g,3));const d=new ix(p,new vu({color:"#dbe7f0",transparent:!0,opacity:.55}));d.frustumCulled=!1,d.visible=!e,i.add(d);const y=60,b=new Re(new Ce(e?.09:.06,6,4),new cn({color:"#ffffff"}),y),w=new _t;b.frustumCulled=!1;const C=[];i.add(b);const A=new Wt,S=new Wt().makeScale(0,0,0);for(let M=0;M<y;M++)b.setMatrixAt(M,S);return{update(M,x,v){const E=v.position;for(let P=0;P<m;P++){let L=_[P*3+1]-M*18;L<0&&(L+=25),_[P*3+1]=L;const N=E.x+_[P*3],F=E.z+_[P*3+2],U=E.y-8+L;g.set([N,U,F,N+.05,U+.6,F],P*6)}p.attributes.position.needsUpdate=!0;for(const P of x.splashes){const L=Mn(t,P.s,P.d,.1),N=t.puddles.reduce((F,U,O)=>Math.abs(U.s-P.s)<Math.abs(t.puddles[F].s-P.s)?O:F,0);w.set(e?ni[N%ni.length]:"#a3b1b8"),e&&(n==null||n(w.clone()));for(let F=0;F<20;F++){const U=Math.random()*Math.PI*2;C.push({p:L.clone(),v:new I(Math.cos(U)*2,2.5+Math.random()*2.5,Math.sin(U)*2),t:0}),b.setColorAt(C.length%y,w)}b.instanceColor&&(b.instanceColor.needsUpdate=!0)}for(x.splashes.length=0;C.length>y;)C.shift();for(let P=0;P<y;P++){const L=C[P];if(!L||L.t>.9){b.setMatrixAt(P,S);continue}L.t+=M,L.v.y-=9.8*M,L.p.addScaledVector(L.v,M),A.makeTranslation(L.p.x,L.p.y,L.p.z),b.setMatrixAt(P,A)}b.instanceMatrix.needsUpdate=!0}}}function gv(i,t){const e=t.trees.filter((p,d)=>d%3!==0),n=t.trees.filter((p,d)=>d%3===0),s=new xe(.14,.22,5.5,6);s.translate(0,2.75,0);const r=[];for(let p=0;p<7;p++){const d=new bn(.35,2.6,4);d.translate(0,1.3,0),d.rotateX(Math.PI/2+.5),d.rotateY(p/7*Math.PI*2),d.translate(0,5.5,0),r.push(d)}const o=Ie(r),a=new Wt,c=new Un,l=new I,h=new Re(s,st("#8a6a45"),e.length),u=new Re(o,st("#3f8f3a",{flatShading:!0}),e.length);e.forEach((p,d)=>{a.compose(Mn(t,p.s,p.d,-.1),c.setFromAxisAngle(In,d*1.3),l.set(p.k,p.k,p.k)),h.setMatrixAt(d,a),u.setMatrixAt(d,a)});const f=new xe(.2,.28,2,6);f.translate(0,1,0);const m=new Es(2.2,0);m.scale(1,.75,1),m.translate(0,3.2,0);const g=new Re(f,st("#6b4423"),n.length),_=new Re(m,st("#2f7d32",{flatShading:!0}),n.length);n.forEach((p,d)=>{a.compose(Mn(t,p.s,p.d,-.1),c.setFromAxisAngle(In,d),l.set(p.k,p.k,p.k)),g.setMatrixAt(d,a),_.setMatrixAt(d,a)});for(const p of[h,u,g,_])p.castShadow=!0;i.add(h,u,g,_)}function _v(i,t,e,n){const s=Math.abs(e),r=(Math.sin(t*.9+e*1.7)+Math.sin(t*.31-e*.6))*.5;if(s<=Rt){const o=i.mud.some(([a,c])=>t>=a&&t<=c);n.set(o?"#4a3220":"#6e4a2c").offsetHSL(0,0,r*.03)}else if(s<=2.3)n.set("#6e4a2c").lerp(new _t("#5da13d"),(s-Rt)/.5);else if(s>6){const o=Math.floor(t/18)+Math.floor(e/9)&1;n.set(o?"#7fbf4a":"#5fa83a").offsetHSL(0,0,r*.04)}else n.set("#5da13d").offsetHSL(0,0,r*.04)}const gh=[-2.6,-Rt,-1.2,-.6,0,.6,1.2,Rt,2.6];function xv(i,t){const e=t.lapLength,[n,s]=_e(t,e/4+12,Js),r=new tt(new Ae(600,600),st("#86c06c"));r.rotation.x=-Math.PI/2,r.position.set(n,-.02,s),r.receiveShadow=!0,i.add(r);const o=gh.length,a=Math.round(e/.5)+2,c=new Float32Array(a*o*3),l=new Float32Array(a*o*3),h=new _t("#b07040"),u=new _t("#8f5a33"),f=new _t;for(let Y=0;Y<a;Y++){const it=Y*.5;for(let ct=0;ct<o;ct++){const xt=gh[ct],[$,et]=_e(t,it,xt),ut=(Y*o+ct)*3;c[ut]=$,c[ut+1]=pe(t,it,xt)+.01,c[ut+2]=et,f.copy(Math.abs(xt)>Rt?u:h).offsetHSL(0,0,Math.sin(it*1.3+xt*2.1)*.02),f.toArray(l,ut)}}const m=[];for(let Y=0;Y<a-1;Y++)for(let it=0;it<o-1;it++){const ct=Y*o+it,xt=ct+o;m.push(ct,ct+1,xt,ct+1,xt+1,xt)}const g=new Me;g.setAttribute("position",new ve(c,3)),g.setAttribute("color",new ve(l,3)),g.setIndex(m),g.computeVertexNormals();const _=new tt(g,new Ue({vertexColors:!0}));_.receiveShadow=!0,i.add(_);const p=new xe(.45,.45,1.1,12);p.rotateZ(Math.PI/2);const d=[];for(const Y of[28,81])for(let it=Y+1;it<Y+25;it+=1.6)d.push([it,-3.2]);const y=new Re(p,st("#e3c16f"),d.length),b=new Wt,w=new Un,C=new I(1,1,1);d.forEach(([Y,it],ct)=>{const[xt,$]=_e(t,Y,it);w.setFromAxisAngle(In,-Fe(t,Y)),b.compose(new I(xt,.42,$),w,C),y.setMatrixAt(ct,b)}),y.castShadow=!0,i.add(y);const A=["#ef4444","#3b82f6","#facc15","#22c55e"],S=new me;for(let Y=0;Y<4;Y++){const it=new tt(new Nt(1,.45*(Y+1),14),st("#9ca3af"));it.position.set(-Y*1,.225*(Y+1),0);const ct=new tt(new Nt(.9,.1,13.6),st(A[Y]));ct.position.set(-Y*1,.45*(Y+1)+.05,0),S.add(it,ct)}const[M,x]=_e(t,14,-8.3);S.position.set(M,0,x),S.rotation.y=-Fe(t,14),S.traverse(Y=>Y.isMesh?Y.castShadow=!0:null),i.add(S);const v=[],E=[],P=Y=>_e(t,Y,-5.8);for(let Y=0;Y<e;Y+=2.5){const[it,ct]=P(Y),xt=new Nt(.12,1,.12);xt.translate(it,.5,ct),v.push(xt);const[$,et]=P(Y+2.5),ut=Math.hypot($-it,et-ct);for(const at of[.45,.85]){const Ct=new Nt(.06,.1,ut);Ct.rotateY(Math.atan2($-it,et-ct)),Ct.translate((it+$)/2,at,(ct+et)/2),E.push(Ct)}}const L=st("#8b5a2b");i.add(new tt(Ie(v),L),new tt(Ie(E),L));const N=new xe(.15,.2,2.2,6);N.translate(0,1.1,0);const F=new Es(1.7,0);F.translate(0,3.3,0);const U=[];for(let Y=0;Y<e;Y+=5)U.push([Y,-(Rt+8+Y%7),1]),U.push([Y+2.5,-(Rt+16+Y%11),1.2]);for(const Y of[6,14,22,59,67,75])U.push([Y,Js,.55]);const O=new Re(N,st("#7a5230"),U.length),k=new Re(F,st("#4caf50",{flatShading:!0}),U.length),K=new I;U.forEach(([Y,it,ct],xt)=>{const[$,et]=_e(t,Y,it);b.compose(new I($,0,et),w.setFromAxisAngle(In,xt),K.set(ct,ct,ct)),O.setMatrixAt(xt,b),k.setMatrixAt(xt,b),k.setColorAt(xt,new _t(xt%3?"#4caf50":"#3d9a46"))}),O.castShadow=k.castShadow=!0,i.add(O,k)}function vv(){const i=document.createElement("canvas");i.width=i.height=64;const t=i.getContext("2d");t.fillStyle="#000",t.fillRect(0,0,64,64),t.fillStyle="#ffd166",t.beginPath(),t.moveTo(14,26),t.lineTo(26,18),t.lineTo(26,30),t.fill(),t.beginPath(),t.moveTo(50,26),t.lineTo(38,18),t.lineTo(38,30),t.fill(),t.beginPath(),t.moveTo(12,38);for(let n=0;n<=8;n++)t.lineTo(12+n*5,n%2?46:40);t.lineTo(52,50),t.lineTo(12,50),t.fill();const e=new Ni(i);return e.colorSpace=Te,e}function Mv(i,t,e,n){i.background=new _t("#2b1748");const s=i.fog;s.color.set("#5b2c55"),s.near=35,s.far=170,n.hemi.intensity=.7,n.hemi.color.set("#b39ddb"),n.sun.intensity=.9,n.sun.color.set("#ff9a4d");const r=vv(),o=new Ce(.42,12,10);o.scale(1.15,.85,1.15);const a=new Ue({color:"#f97316",emissive:"#ffffff",emissiveMap:r,emissiveIntensity:1}),c=st("#3f6212");for(let _=15;_<e.length-20;_+=18){const d=(Math.floor(_/18)%2?1:-1)*(Ln-1.6),[y,b]=_e(e,_,d),w=new tt(o,a);w.position.set(y,pe(e,_,d)+.32,b);const[C,A]=_e(e,_,0);w.lookAt(C,w.position.y,A),w.rotateY(-Math.PI/2);const S=new tt(new xe(.05,.07,.16,6),c);S.position.y=.4,w.add(S),t.add(w)}const[l,h]=_e(e,e.length*.6,-300),u=new tt(new Ce(28,24,16),new cn({color:"#fff7d6",fog:!1}));u.position.set(l,140,h),t.add(u);const f=[],m=new cn({color:"#111111",side:ze});for(let _=0;_<7;_++){const p=new me;for(const d of[-1,1]){const y=new tt(new Ae(.5,.22),m);y.position.x=d*.25,p.add(y)}p.add(new tt(new Ce(.09,6,4),m)),t.add(p),f.push(p)}let g=0;return{update(_,p){g+=_,f.forEach((d,y)=>{const b=g*(.8+y*.1)+y;d.position.set(p.x+Math.cos(b)*(6+y),p.y+6+Math.sin(g*2+y)*1.5,p.z-8+Math.sin(b)*(6+y));const w=Math.sin(g*18+y)*.8;d.children[0].rotation.y=w,d.children[1].rotation.y=-w,d.rotation.y=-b})}}}function Ac(i,t,e,n=!1){const s=document.createElement("canvas");s.width=i,s.height=t,e(s.getContext("2d"));const r=new Ni(s);return r.colorSpace=Te,n&&(r.wrapS=r.wrapT=ps),r.anisotropy=4,r}function yv(){return Ac(128,128,i=>{i.fillStyle="#c9cbcf",i.fillRect(0,0,128,128);for(let t=0;t<400;t++)i.fillStyle=`rgba(0,0,0,${Math.random()*.05})`,i.fillRect(Math.random()*128,Math.random()*128,2,2);i.fillStyle="#a9acb1",i.fillRect(0,0,128,2),i.fillRect(0,0,2,128)},!0)}function Sv(){return Ac(64,64,i=>{i.clearRect(0,0,64,64),i.strokeStyle="rgba(120,124,130,0.95)",i.lineWidth=2,i.beginPath(),i.moveTo(0,0),i.lineTo(64,64),i.moveTo(64,0),i.lineTo(0,64),i.stroke()},!0)}function wv(i){return Ac(256,64,t=>{t.fillStyle="#d8d2c8",t.fillRect(0,0,256,64);const e=["#ff595e","#ffca3a","#8ac926","#1982c4","#6a4c93","#ff924c","#00bbf9"];let n=i;const s=()=>(n=(n*9301+49297)%233280)/233280;for(let r=0;r<9;r++)t.fillStyle=e[Math.floor(s()*e.length)],t.beginPath(),t.ellipse(s()*256,10+s()*44,14+s()*26,8+s()*16,s()*3,0,Math.PI*2),t.fill(),t.strokeStyle="rgba(20,20,20,0.6)",t.lineWidth=3,t.stroke();for(let r=0;r<4;r++){t.strokeStyle=e[Math.floor(s()*e.length)],t.lineWidth=6,t.beginPath();const o=8+s()*48;t.moveTo(s()*80,o),t.bezierCurveTo(80+s()*40,o-20,140+s()*40,o+20,180+s()*70,o),t.stroke()}})}function bv(i){const t=[],e=[],n=(a,c,l,h,u)=>a.push(...c,...l,...h,...c,...h,...u),s=(a,c,l)=>{const[h,u]=_e(i,a,c);return[h,l,u]},r=i.feat.length;for(let a=0;a<r-1;a++){const c=i.feat[a],l=i.feat[a+1];if(c<.002&&l<.002)continue;const h=a*an,u=h+an,f=i.base[a]+c,m=i.base[a+1]+l;n(t,s(h,-Rt,f),s(h,Rt,f),s(u,Rt,m),s(u,-Rt,m)),n(e,s(h,Rt,i.base[a]),s(u,Rt,i.base[a+1]),s(u,Rt,m),s(h,Rt,f)),n(e,s(u,-Rt,i.base[a+1]),s(h,-Rt,i.base[a]),s(h,-Rt,f),s(u,-Rt,m)),l<.002&&c>.05&&n(e,s(u,Rt,i.base[a+1]),s(u,-Rt,i.base[a+1]),s(u,-Rt,f),s(u,Rt,f)),a===0&&c>.05&&n(e,s(h,-Rt,i.base[0]),s(h,Rt,i.base[0]),s(h,Rt,f),s(h,-Rt,f))}const o=(a,c)=>{const l=new Me;l.setAttribute("position",new re(a,3)),l.computeVertexNormals();const h=new tt(l,st(c,{side:ze}));return h.castShadow=!0,h.receiveShadow=!0,h};return[o(t,"#b9bec5"),o(e,"#9aa1aa")]}function Ev(i,t){const e=t.length,n=e/2,[s,r]=_e(t,n,0),o=yv();o.repeat.set(30/3,(e+60)/3);const a=new tt(new Ae(30,e+60),new Ue({map:o}));a.rotation.x=-Math.PI/2,a.position.set(s,0,r),a.receiveShadow=!0;const c=new tt(new Ae(800,800),st("#7fb069"));c.rotation.x=-Math.PI/2,c.position.set(s,-.02,r),c.receiveShadow=!0,i.add(c,a);const l=[];for(const F of[-Rt-.3,Rt+.3]){const U=new Ae(.12,e);U.rotateX(-Math.PI/2),U.translate(F,.01,-n),l.push(U)}i.add(new tt(Ie(l),st("#f2c230"))),i.add(...bv(t));const h=st("#d9dde2",{emissive:"#333333"});for(const F of t.lips){const U=t.feat[Math.round(F/an)],[O,k]=_e(t,F,0),K=new tt(new xe(.05,.05,Rt*2+.06,10),h);K.rotation.z=Math.PI/2,K.position.set(O,U+.02,k),i.add(K)}const u=st("#ef4444"),f=t.feat[10];for(const F of[-Rt,Rt]){for(const U of[.6,4,8])i.add(de(new I(F,f,-U),new I(F,f+1,-U),.04,u));i.add(de(new I(F,f+1,-.6),new I(F,f+1,-8),.04,u))}const m=Sv(),g=st("#6b7280");for(const F of[-15,15]){const U=m.clone();U.repeat.set((e+60)/.4,2.2/.4),U.needsUpdate=!0;const O=new tt(new Ae(e+60,2.2),new Ue({map:U,transparent:!0,alphaTest:.3,side:ze}));O.rotation.y=Math.PI/2,O.position.set(F,1.1,r),i.add(O);for(let k=-30;k<=e+30;k+=4)i.add(de(new I(F,0,-k),new I(F,2.3,-k),.04,g))}for(const F of[-30,e+30]){const U=m.clone();U.repeat.set(30/.4,2.2/.4),U.needsUpdate=!0;const O=new tt(new Ae(30,2.2),new Ue({map:U,transparent:!0,alphaTest:.3,side:ze}));O.position.set(0,1.1,-F),i.add(O)}const _=st("#cfc9bf"),p=st("#a0682f"),d=st("#4b5563");for(let F=6,U=0;F<e+20;F+=24,U++){const O=U%2?1:-1,k=new tt(new Nt(.35,2.2,10),[_,_,_,_,_,_]),K=new Ue({map:wv(U*97+13)});k.material[O>0?1:0]=K,k.position.set(O*11.5,1.1,-F),k.castShadow=!0,i.add(k);const Y=-O*7.5,it=new me,ct=new tt(new Nt(.5,.08,2),p);ct.position.y=.45;const xt=new tt(new Nt(.08,.4,2),p);xt.position.set(-O*.22,.7,0),it.add(ct,xt);for(const et of[-.85,.85]){const ut=new tt(new Nt(.4,.45,.06),d);ut.position.set(0,.22,et),it.add(ut)}it.position.set(Y,0,-F-8),it.traverse(et=>et.isMesh?et.castShadow=!0:null),i.add(it);const $=new tt(new xe(.28,.24,.8,10),st("#16a34a"));$.position.set(Y,.4,-F-10.4),i.add($);for(const et of[-13.5,13.5]){i.add(de(new I(et,0,-F-12),new I(et,6,-F-12),.08,d));const ut=new tt(new Nt(.6,.2,.4),st("#f8fafc",{emissive:"#fff7d6",emissiveIntensity:.4}));ut.position.set(et-Math.sign(et)*.3,6,-F-12),i.add(ut)}}const y=new xe(.15,.2,2.4,6);y.translate(0,1.2,0);const b=new Es(1.8,0);b.translate(0,3.6,0);const w=[];for(let F=-26;F<e+30;F+=7)for(const U of[-18,18,-24,24])w.push([U+Math.sin(F*U)*1.5,F+Math.cos(F+U)*2]);const C=new Re(y,st("#7a5230"),w.length),A=new Re(b,st("#4caf50",{flatShading:!0}),w.length),S=new Wt,M=new Un,x=new I;w.forEach(([F,U],O)=>{const k=.8+O*7%5*.1;S.compose(new I(F,0,-U),M.setFromAxisAngle(In,O),x.set(k,k,k)),C.setMatrixAt(O,S),A.setMatrixAt(O,S),A.setColorAt(O,new _t(O%3?"#4caf50":"#3d9a46"))}),C.castShadow=A.castShadow=!0,i.add(C,A);const v=[],E=["#9db4c8","#b8c4d6","#c9b8a8","#a3b8a0","#d0c3d8"],P=[],L=new _t;for(let F=0;F<70;F++){const U=F%2?1:-1,O=-60+F/70*(e+160),k=15+F*37%45,K=new Nt(14+F%4*4,k,14);K.translate(U*(70+F*13%40),k/2,-O),L.set(E[F%E.length]);for(let Y=0;Y<K.getAttribute("position").count;Y++)P.push(L.r,L.g,L.b);v.push(K)}const N=Ie(v);N.setAttribute("color",new re(P,3)),i.add(new tt(N,new Ue({vertexColors:!0})))}function _h(i){const t=uo({bike:i,helmet:i});return t.root.traverse(e=>{const n=e;if(!n.isMesh)return;const s=n.material.clone();s.transparent=!0,s.opacity=.4,s.depthWrite=!1,s.color.lerp(new _t(i),.6),n.material=s,n.castShadow=!1}),t}function Tv(i,t){const e=document.createElement("canvas");e.width=256,e.height=64;const n=e.getContext("2d");n.fillStyle=t,n.beginPath(),n.roundRect(4,8,248,48,24),n.fill(),n.fillStyle="#fff",n.font="900 32px system-ui, sans-serif",n.textAlign="center",n.textBaseline="middle",n.fillText(i,128,33);const s=new Ni(e);s.colorSpace=Te;const r=new Q_(new _u({map:s,depthTest:!1}));return r.scale.set(1.6,.4,1),r.position.y=2.2,r}const xh=[0,.6,1.2,1.8,2.3,3,4,5.5,7.5,10,14,19,26,35,46,60],vh=.75;function Tn(i,t,e,n=0){const[s,r]=_e(i,t,e);return new I(s,pe(i,t,e)+n,r)}class Av{constructor(t){q(this,"renderer");q(this,"scene",new _c);q(this,"camera",new je(62,1,.1,900));q(this,"sun",new wc("#fff6e5",1.8));q(this,"hemi",new Sc("#eaf6ff","#5d7a3a",1.2));q(this,"updater",null);q(this,"halloween",null);q(this,"group",new me);q(this,"rider");q(this,"ghost",null);q(this,"familyGhosts",[]);q(this,"coinMeshes",[]);q(this,"stickerMeshes",[]);q(this,"pet",null);q(this,"flags",[]);q(this,"camPos",new I);q(this,"camLook",new I);q(this,"clock",0);q(this,"steerLean",0);this.renderer=t,this.scene.background=new _t("#8fd0ff"),this.scene.fog=new co("#cfe8f5",60,260),this.scene.add(this.hemi),this.sun.castShadow=!0,this.sun.shadow.mapSize.set(1024,1024);const e=this.sun.shadow.camera;e.left=-30,e.right=30,e.top=30,e.bottom=-30,e.near=1,e.far=150,this.sun.shadow.bias=-8e-4,this.scene.add(this.sun,this.sun.target,this.group)}resize(t,e){this.camera.aspect=t/e,this.camera.fov=t/e<1.2?76:62,this.camera.updateProjectionMatrix()}build(t,e,n={pet:"none",festival:null}){var m;this.group.traverse(g=>{const _=g;_.isMesh&&_.geometry.dispose()}),this.group.clear(),this.coinMeshes=[],this.stickerMeshes=[],this.flags=[];const s=t.layout,r=this.scene.fog,o=n.festival==="holi"&&s.kind==="mud",a=s.kind==="mud"&&!o;r.near=a?35:60,r.far=a?200:260,this.hemi.intensity=a?1:1.2,this.sun.intensity=a?.9:1.8,this.updater=null,this.halloween=null,s.kind==="park"?(this.scene.background=new _t("#9ad4f5"),this.scene.fog.color.set("#f3e3cf"),Ev(this.group,s)):s.kind==="pump"?(this.scene.background=new _t("#8fd3ff"),this.scene.fog.color.set("#d8efff"),xv(this.group,s)):s.kind==="mud"?(this.scene.background=new _t(o?"#8fd3ff":"#a7b6c4"),r.color.set(o?"#ffe4f1":"#b8c5d0"),this.buildTerrain(s),this.buildMountains(s),gv(this.group,s),this.buildObstacles(s),this.updater=mv(this.group,s,o,g=>{this.rider.bikeMat.color.lerp(g,.55),this.rider.helmetMat.color.lerp(g,.35)})):(this.scene.background=new _t("#8fd0ff"),r.color.set("#cfe8f5"),this.buildTerrain(s),this.buildMountains(s),this.buildForest(s),this.buildObstacles(s),n.festival==="halloween"&&(this.halloween=Mv(this.scene,this.group,s,{hemi:this.hemi,sun:this.sun}))),this.buildMarkers(s),this.rider=uo(e),this.group.add(this.rider.root),(m=this.pet)==null||m.dispose(),this.pet=bu(n.pet,this.group,this.rider);for(const g of s.stickers){const _=Eu(bc(g.id).emoji);_.position.copy(Tn(s,g.s,g.d,g.lift+.2)),this.group.add(_),this.stickerMeshes.push(_)}this.ghost=null,s.lapLength&&!t.runGhosts.length&&(this.ghost=_h("#7dd3fc"),this.ghost.root.visible=!1,this.group.add(this.ghost.root)),this.familyGhosts=t.runGhosts.map(g=>{const _=_h(g.color);return _.root.add(Tv(g.name,g.color)),this.group.add(_.root),_});const c=new xe(.32,.32,.07,20);c.rotateX(Math.PI/2);const l=st("#fbbf24",{emissive:"#b45309",emissiveIntensity:.35});for(const g of s.coins){const _=new tt(c,l);_.position.copy(Tn(s,g.s,g.d,g.lift)),_.castShadow=!0,this.group.add(_),this.coinMeshes.push(_)}const h=t.rider,u=Tn(s,h.s,h.d),f=Fe(s,h.s);this.camPos.set(u.x-Math.sin(f)*7,u.y+4.2,u.z+Math.cos(f)*7),this.camLook.copy(u)}buildTerrain(t){const e=[...xh.slice(1).map(w=>-w).reverse(),...xh],n=e.length,s=-30,r=Math.ceil((t.length+70-s)/vh),o=new Float32Array(r*n*3),a=new Float32Array(r*n*3),c=new _t,l=new _t("#8a5a33"),h=new _t("#b07a45"),u=new _t("#6aa84f"),f=new _t("#4f8a3c");for(let w=0;w<r;w++){const C=s+w*vh,A=Math.round(C/.5),S=A>=0&&A<t.feat.length?t.feat[A]:0;for(let M=0;M<n;M++){const x=e[M],[v,E]=_e(t,C,x),P=(w*n+M)*3;o[P]=v,o[P+1]=pe(t,C,x)-(Math.abs(x)<=Rt?0:.02),o[P+2]=E;const L=Math.abs(x),N=(Math.sin(C*.9+x*1.7)+Math.sin(C*.31-x*.6))*.5;t.kind==="mud"?_v(t,C,x,c):L<=Rt?c.copy(S>.05?h:l).offsetHSL(0,0,N*.03):L<=2.3?c.copy(l).lerp(u,(L-Rt)/.5):c.copy(u).lerp(f,Math.min(1,L/40)*.8+N*.15),c.toArray(a,P)}}const m=[];for(let w=0;w<r-1;w++)for(let C=0;C<n-1;C++){const A=w*n+C,S=A+n;m.push(A,A+1,S,A+1,S+1,S)}const g=new Me;g.setAttribute("position",new ve(o,3)),g.setAttribute("color",new ve(a,3)),g.setIndex(m),g.computeVertexNormals();const _=new tt(g,new Ue({vertexColors:!0}));_.receiveShadow=!0,this.group.add(_);const p=new tt(new Ae(4e3,4e3),st("#4f8a3c"));p.rotation.x=-Math.PI/2;const[d,y]=_e(t,t.length/2,0);let b=1/0;for(let w=0;w<t.base.length;w+=10)b=Math.min(b,t.base[w]);p.position.set(d,b-6,y),this.group.add(p)}buildMountains(t){const[e,n]=_e(t,t.length/2,0),s=[],r=[];let o=-1/0;for(let l=0;l<t.base.length;l+=10)o=Math.max(o,t.base[l]);for(let l=0;l<26;l++){const h=l/26*Math.PI*2+Math.sin(l*3.1)*.1,u=750+Math.sin(l*1.7)*120,f=140+l*53%90,m=150+l*37%70,g=e+Math.cos(h)*u,_=n+Math.sin(h)*u,p=new bn(m,f,7);p.translate(g,o-20+f/2,_),s.push(p);const d=new bn(m*.32,f*.32,7);d.translate(g,o-20+f-f*.16+.5,_),r.push(d)}const a=t.kind==="mud",c=new Ue({color:a?"#7d9a86":"#8aa3b8",flatShading:!0,fog:!1});if(this.group.add(new tt(Ie(s),c)),!a){const l=new Ue({color:"#f5f8fb",flatShading:!0,fog:!1});this.group.add(new tt(Ie(r),l))}}buildForest(t){const e=new xe(.15,.22,1.6,6);e.translate(0,.8,0);const n=[];for(let u=0;u<3;u++){const f=new bn(1.6-u*.4,2.2,7);f.translate(0,2.2+u*1.15,0),n.push(f)}const s=Ie(n),r=new Re(e,st("#6b4423"),t.trees.length),o=new Re(s,st("#2f7d4a",{flatShading:!0}),t.trees.length),a=new Wt,c=new Un,l=new I,h=["#2f7d4a","#2a6e41","#3b8f55","#26603a"].map(u=>new _t(u));t.trees.forEach((u,f)=>{const m=Tn(t,u.s,u.d,-.1);c.setFromAxisAngle(In,f*1.7),a.compose(m,c,l.set(u.k,u.k*(.9+f%5*.08),u.k)),r.setMatrixAt(f,a),o.setMatrixAt(f,a),o.setColorAt(f,h[f%h.length])}),r.castShadow=o.castShadow=!0,this.group.add(r,o)}buildObstacles(t){const e=st("#8d8f94",{flatShading:!0});for(const s of t.rocks){const r=new eo(s.r,0);r.scale(1.1,.8,1);const o=new tt(r,e);o.position.copy(Tn(t,s.s,s.d,s.r*.45)),o.rotation.set(s.s,s.s*2,0),o.castShadow=!0,this.group.add(o)}for(let s=20;s<t.length;s+=37){const r=Math.sin(s)>0?1:-1,o=.4+s%7*.08,a=new tt(new eo(o,0),e);a.position.copy(Tn(t,s,r*(Rt+1.6+s%3),o*.3)),a.castShadow=!0,this.group.add(a)}const n=st("#7a4e2a");for(const s of t.logs){const r=Fe(t,s),o=new tt(new xe(.17,.17,Rt*2+.8,10),n);o.position.copy(Tn(t,s,0,0)),o.position.y=pe(t,s-.6,0)+.17,o.quaternion.setFromUnitVectors(In,new I(Math.cos(r),0,Math.sin(r))),o.castShadow=!0,this.group.add(o)}}buildMarkers(t){const e=st("#e5e7eb");for(const c of t.kind==="pump"?[]:t.checkpoints.slice(1)){const l=Tn(t,c,Rt+.5);this.group.add(de(l,l.clone().add(new I(0,2.6,0)),.05,e));const h=st("#f8fafc",{side:ze}),u=new tt(new Ae(.9,.55),h),f=Fe(t,c);u.position.copy(l).add(new I(0,2.3,0)),u.rotation.y=-f,u.position.add(new I(Math.cos(f)*.45,0,Math.sin(f)*.45)),this.group.add(u),this.flags.push(h)}const n=st("#f97316"),s=Tn(t,t.finishS,-Rt-.6),r=Tn(t,t.finishS,Rt+.6),o=Math.max(s.y,r.y)+4.5;this.group.add(de(s,new I(s.x,o,s.z),.16,n),de(r,new I(r.x,o,r.z),.16,n));const a=new tt(new Nt(Rt*2+1.2,.9,.12),new Ue({map:Su()}));a.position.set((s.x+r.x)/2,o-.4,(s.z+r.z)/2),a.rotation.y=-Fe(t,t.finishS),this.group.add(a)}renderReplay(t,e,n){const s=t.layout,r=this.rider,[o,a]=_e(s,e.s,e.d);r.root.position.set(o,e.y,a),r.root.rotation.y=-(Fe(s,e.s)+e.rel),r.root.rotation.x=e.pitch;const c=e.trick?Math.min(1,e.trickT/t.trickTime):0,l=Math.sin(Math.PI*c);r.lean.rotation.z=e.trick==="Tabletop"?1.1*l:0,r.lean.rotation.y=e.trick==="360 Spin"?Math.PI*2*c:0,os(r,e.crank,e.trick?{name:e.trick,k:l}:void 0);const h=Fe(s,e.s)+n;this.camera.position.set(o+Math.cos(h)*5.5,e.y+1.8,a+Math.sin(h)*5.5),this.camera.lookAt(o,e.y+.9,a),this.renderer.render(this.scene,this.camera)}render(t,e){var b,w,C;this.clock+=e;const n=t.layout,s=t.rider,r=this.rider,[o,a]=_e(n,s.s,s.d),c=Fe(n,s.s)+s.rel;r.root.position.set(o,s.y,a),r.root.rotation.y=-c,r.root.rotation.x=s.pitch;const l=s.trick?Math.min(1,s.trickT/t.trickTime):0,h=Math.sin(Math.PI*l);if(s.crashed){const A=Math.min(1,s.crashT/.35);r.lean.rotation.z=1.35*A,r.lean.rotation.y=0}else{this.steerLean=Jh.lerp(this.steerLean,-s.rel*.6,1-Math.exp(-8*e));const A=Math.atan((pe(n,s.s,s.d+.3)-pe(n,s.s,s.d-.3))/.6);r.lean.rotation.z=s.trick==="Tabletop"?-s.rel*.6+1.1*h:this.steerLean+(s.grounded?A*.6:0),r.lean.rotation.y=s.trick==="360 Spin"?Math.PI*2*l:0}if(os(r,s.crank,s.trick?{name:s.trick,k:h}:void 0),(b=this.pet)==null||b.update(e,r.root.position,c,s.v,this.clock),this.stickerMeshes.forEach((A,S)=>{A.visible=!t.stickerGot[S],Tu(A,this.clock,S)}),t.runGhostPoses().forEach((A,S)=>{const M=this.familyGhosts[S],[x,v]=_e(n,A.s,A.d);M.root.position.set(x,A.y,v),M.root.rotation.y=-Fe(n,A.s),M.root.rotation.x=A.pitch,os(M,A.s/.33)}),this.ghost){const A=t.ghostPose();if(this.ghost.root.visible=!!A,A){const[S,M]=_e(n,A.s,A.d);this.ghost.root.position.set(S,A.y,M),this.ghost.root.rotation.y=-Fe(n,A.s),this.ghost.root.rotation.x=A.pitch,os(this.ghost,A.s/.33)}}this.coinMeshes.forEach((A,S)=>{A.visible=!t.coins[S],A.rotation.y=this.clock*3+S}),this.flags.forEach((A,S)=>A.color.set(t.checkpoint>=n.checkpoints[S+1]?"#22c55e":"#f8fafc"));const u=Fe(n,s.s)+s.rel*.4,f=new I(Math.sin(u),0,-Math.cos(u)),m=new I(o,s.y,a),g=pe(n,s.s,s.d),_=m.clone().addScaledVector(f,-7);_.y=Math.max(s.y,g)+4.2;const p=m.clone().addScaledVector(f,7);p.y=pe(n,s.s+7,s.d)+.6;const d=1-Math.exp(-5*e);this.camPos.lerp(_,d),this.camLook.lerp(p,d);const y=pe(n,s.s-7,s.d)+1.5;this.camPos.y<y&&(this.camPos.y=y),this.camera.position.copy(this.camPos),this.camera.lookAt(this.camLook),(w=this.updater)==null||w.update(e,t,this.camera),(C=this.halloween)==null||C.update(e,m),this.sun.position.set(o+25,s.y+45,a+15),this.sun.target.position.set(o,s.y,a-10),this.renderer.render(this.scene,this.camera)}}const Rv="__capgo_keep_url_path_after_reload",ta="__capgo_history_stack__",Mh=100,Cv=typeof window<"u"&&typeof document<"u"&&typeof history<"u";if(Cv){const i=window;if(!i.__capgoHistoryPatched){i.__capgoHistoryPatched=!0;const t=()=>{try{if(i.__capgoKeepUrlPathAfterReload)return!0}catch{}try{return window.localStorage.getItem(Rv)==="1"}catch{return!1}},e=()=>{try{const C=window.sessionStorage.getItem(ta);if(!C)return{stack:[],index:-1};const A=JSON.parse(C);return!A||!Array.isArray(A.stack)||typeof A.index!="number"?{stack:[],index:-1}:A}catch{return{stack:[],index:-1}}},n=(C,A)=>{try{window.sessionStorage.setItem(ta,JSON.stringify({stack:C,index:A}))}catch{}},s=()=>{try{window.sessionStorage.removeItem(ta)}catch{}},r=C=>{try{const A=C??window.location.href,S=new URL(A instanceof URL?A.toString():A,window.location.href);return`${S.pathname}${S.search}${S.hash}`}catch{return null}},o=(C,A)=>{if(C.length<=Mh)return{stack:C,index:A};const S=C.length-Mh,M=C.slice(S),x=Math.max(0,A-S);return{stack:M,index:x}},a=C=>{document.readyState==="complete"||document.readyState==="interactive"?C():window.addEventListener("DOMContentLoaded",C,{once:!0})};let c=!1,l=!1,h=!1;const u=()=>{if(!c)return;const C=e(),A=r();if(A){if(C.stack.length===0){C.stack.push(A),C.index=0,n(C.stack,C.index);return}(C.index<0||C.index>=C.stack.length)&&(C.index=C.stack.length-1),C.stack[C.index]!==A&&(C.stack[C.index]=A,n(C.stack,C.index))}},f=(C,A)=>{if(!c||l)return;const S=r(C);if(!S)return;let{stack:M,index:x}=e();M.length===0?(M.push(S),x=M.length-1):A?((x<0||x>=M.length)&&(x=M.length-1),M[x]=S):x>=M.length-1?(M.push(S),x=M.length-1):(M=M.slice(0,x+1),M.push(S),x=M.length-1),{stack:M,index:x}=o(M,x),n(M,x)},m=()=>{if(!c||l)return;const C=e();if(C.stack.length===0){u();return}const A=C.index>=0&&C.index<C.stack.length?C.index:C.stack.length-1,S=r();if(C.stack.length===1&&S===C.stack[0])return;const M=C.stack[0];if(!M)return;l=!0;try{history.replaceState(history.state,document.title,M);for(let E=1;E<C.stack.length;E+=1)history.pushState(history.state,document.title,C.stack[E])}catch{l=!1;return}l=!1;const x=C.stack.length-1,v=A-x;v!==0?history.go(v):(history.replaceState(history.state,document.title,C.stack[A]),window.dispatchEvent(new PopStateEvent("popstate")))},g=()=>{!c||h||(h=!0,a(()=>{h=!1,m()}))};let _=null,p=null;const d=()=>{if(!c||l)return;const C=r();if(!C)return;const A=e(),S=A.stack.lastIndexOf(C);S>=0?A.index=S:(A.stack.push(C),A.index=A.stack.length-1);const M=o(A.stack,A.index);n(M.stack,M.index)},y=()=>{_&&p||(_=history.pushState,p=history.replaceState,history.pushState=function(A,S,M){const x=_==null?void 0:_.call(history,A,S,M);return f(M,!1),x},history.replaceState=function(A,S,M){const x=p==null?void 0:p.call(history,A,S,M);return f(M,!0),x},window.addEventListener("popstate",d))},b=()=>{_&&(history.pushState=_,_=null),p&&(history.replaceState=p,p=null),window.removeEventListener("popstate",d)},w=C=>{if(c===C){c&&(u(),g());return}c=C,c?(y(),u(),g()):(b(),s())};window.addEventListener("CapacitorUpdaterKeepUrlPathAfterReload",C=>{var A;const S=C,M=(A=S==null?void 0:S.detail)===null||A===void 0?void 0:A.enabled;typeof M=="boolean"?(i.__capgoKeepUrlPathAfterReload=M,w(M)):(i.__capgoKeepUrlPathAfterReload=!0,w(!0))}),w(t())}}var yh;(function(i){i[i.UNKNOWN=0]="UNKNOWN",i[i.UPDATE_NOT_AVAILABLE=1]="UPDATE_NOT_AVAILABLE",i[i.UPDATE_AVAILABLE=2]="UPDATE_AVAILABLE",i[i.UPDATE_IN_PROGRESS=3]="UPDATE_IN_PROGRESS"})(yh||(yh={}));var Sh;(function(i){i[i.UNKNOWN=0]="UNKNOWN",i[i.PENDING=1]="PENDING",i[i.DOWNLOADING=2]="DOWNLOADING",i[i.INSTALLING=3]="INSTALLING",i[i.INSTALLED=4]="INSTALLED",i[i.FAILED=5]="FAILED",i[i.CANCELED=6]="CANCELED",i[i.DOWNLOADED=11]="DOWNLOADED"})(Sh||(Sh={}));var wh;(function(i){i[i.OK=0]="OK",i[i.CANCELED=1]="CANCELED",i[i.FAILED=2]="FAILED",i[i.NOT_AVAILABLE=3]="NOT_AVAILABLE",i[i.NOT_ALLOWED=4]="NOT_ALLOWED",i[i.INFO_MISSING=5]="INFO_MISSING"})(wh||(wh={}));const ns=Di("CapacitorUpdater",{web:()=>er(()=>import("./web-8M9PONp1.js"),[],import.meta.url).then(i=>new i.CapacitorUpdaterWeb)}),Pv=4,Lv="v1.0.0 · update 4";async function Dv(){if(Ci.isNativePlatform()){await ns.notifyAppReady().catch(()=>{});try{const i=await fetch(`https://manirajyadav-1.github.io/cycle-champs-site/updates/version.json?t=${Date.now()}`,{cache:"no-store"});if(!i.ok)return;const t=await i.json(),e=await ra.getInfo(),{bundles:n}=await ns.list(),{bundle:s}=await ns.current(),r=[s.id];if(t.webBuild>Pv&&Number(e.build)>=t.minNativeBuild){const o=String(t.webBuild),c=n.find(l=>l.version===o&&(l.status==="success"||l.status==="pending"))??await ns.download({url:t.url,version:o,checksum:t.checksum});await ns.next({id:c.id}),r.push(c.id)}for(const o of n)!r.includes(o.id)&&o.status!=="downloading"&&await ns.delete({id:o.id}).catch(()=>{})}catch{}}}const Ts=function(i,t){let s=i;const r=Ws[t];let o=null,a=0,c=null;const l=[],h={},u=function(S,M){a=s*4+17,o=(function(x){const v=new Array(x);for(let E=0;E<x;E+=1){v[E]=new Array(x);for(let P=0;P<x;P+=1)v[E][P]=null}return v})(a),f(0,0),f(a-7,0),f(0,a-7),_(),g(),d(S,M),s>=7&&p(S),c==null&&(c=w(s,r,l)),y(c,M)},f=function(S,M){for(let x=-1;x<=7;x+=1)if(!(S+x<=-1||a<=S+x))for(let v=-1;v<=7;v+=1)M+v<=-1||a<=M+v||(0<=x&&x<=6&&(v==0||v==6)||0<=v&&v<=6&&(x==0||x==6)||2<=x&&x<=4&&2<=v&&v<=4?o[S+x][M+v]=!0:o[S+x][M+v]=!1)},m=function(){let S=0,M=0;for(let x=0;x<8;x+=1){u(!0,x);const v=si.getLostPoint(h);(x==0||S>v)&&(S=v,M=x)}return M},g=function(){for(let S=8;S<a-8;S+=1)o[S][6]==null&&(o[S][6]=S%2==0);for(let S=8;S<a-8;S+=1)o[6][S]==null&&(o[6][S]=S%2==0)},_=function(){const S=si.getPatternPosition(s);for(let M=0;M<S.length;M+=1)for(let x=0;x<S.length;x+=1){const v=S[M],E=S[x];if(o[v][E]==null)for(let P=-2;P<=2;P+=1)for(let L=-2;L<=2;L+=1)P==-2||P==2||L==-2||L==2||P==0&&L==0?o[v+P][E+L]=!0:o[v+P][E+L]=!1}},p=function(S){const M=si.getBCHTypeNumber(s);for(let x=0;x<18;x+=1){const v=!S&&(M>>x&1)==1;o[Math.floor(x/3)][x%3+a-8-3]=v}for(let x=0;x<18;x+=1){const v=!S&&(M>>x&1)==1;o[x%3+a-8-3][Math.floor(x/3)]=v}},d=function(S,M){const x=r<<3|M,v=si.getBCHTypeInfo(x);for(let E=0;E<15;E+=1){const P=!S&&(v>>E&1)==1;E<6?o[E][8]=P:E<8?o[E+1][8]=P:o[a-15+E][8]=P}for(let E=0;E<15;E+=1){const P=!S&&(v>>E&1)==1;E<8?o[8][a-E-1]=P:E<9?o[8][15-E-1+1]=P:o[8][15-E-1]=P}o[a-8][8]=!S},y=function(S,M){let x=-1,v=a-1,E=7,P=0;const L=si.getMaskFunction(M);for(let N=a-1;N>0;N-=2)for(N==6&&(N-=1);;){for(let F=0;F<2;F+=1)if(o[v][N-F]==null){let U=!1;P<S.length&&(U=(S[P]>>>E&1)==1),L(v,N-F)&&(U=!U),o[v][N-F]=U,E-=1,E==-1&&(P+=1,E=7)}if(v+=x,v<0||a<=v){v-=x,x=-x;break}}},b=function(S,M){let x=0,v=0,E=0;const P=new Array(M.length),L=new Array(M.length);for(let O=0;O<M.length;O+=1){const k=M[O].dataCount,K=M[O].totalCount-k;v=Math.max(v,k),E=Math.max(E,K),P[O]=new Array(k);for(let xt=0;xt<P[O].length;xt+=1)P[O][xt]=255&S.getBuffer()[xt+x];x+=k;const Y=si.getErrorCorrectPolynomial(K),ct=Qs(P[O],Y.getLength()-1).mod(Y);L[O]=new Array(Y.getLength()-1);for(let xt=0;xt<L[O].length;xt+=1){const $=xt+ct.getLength()-L[O].length;L[O][xt]=$>=0?ct.getAt($):0}}let N=0;for(let O=0;O<M.length;O+=1)N+=M[O].totalCount;const F=new Array(N);let U=0;for(let O=0;O<v;O+=1)for(let k=0;k<M.length;k+=1)O<P[k].length&&(F[U]=P[k][O],U+=1);for(let O=0;O<E;O+=1)for(let k=0;k<M.length;k+=1)O<L[k].length&&(F[U]=L[k][O],U+=1);return F},w=function(S,M,x){const v=bh.getRSBlocks(S,M),E=Eh();for(let L=0;L<x.length;L+=1){const N=x[L];E.put(N.getMode(),4),E.put(N.getLength(),si.getLengthInBits(N.getMode(),S)),N.write(E)}let P=0;for(let L=0;L<v.length;L+=1)P+=v[L].dataCount;if(E.getLengthInBits()>P*8)throw"code length overflow. ("+E.getLengthInBits()+">"+P*8+")";for(E.getLengthInBits()+4<=P*8&&E.put(0,4);E.getLengthInBits()%8!=0;)E.putBit(!1);for(;!(E.getLengthInBits()>=P*8||(E.put(236,8),E.getLengthInBits()>=P*8));)E.put(17,8);return b(E,v)};h.addData=function(S,M){M=M||"Byte";let x=null;switch(M){case"Numeric":x=Iv(S);break;case"Alphanumeric":x=Uv(S);break;case"Byte":x=Nv(S);break;case"Kanji":x=Fv(S);break;default:throw"mode:"+M}l.push(x),c=null},h.isDark=function(S,M){if(S<0||a<=S||M<0||a<=M)throw S+","+M;return o[S][M]},h.getModuleCount=function(){return a},h.make=function(){if(s<1){let S=1;for(;S<40;S++){const M=bh.getRSBlocks(S,r),x=Eh();for(let E=0;E<l.length;E++){const P=l[E];x.put(P.getMode(),4),x.put(P.getLength(),si.getLengthInBits(P.getMode(),S)),P.write(x)}let v=0;for(let E=0;E<M.length;E++)v+=M[E].dataCount;if(x.getLengthInBits()<=v*8)break}s=S}u(!1,m())},h.createTableTag=function(S,M){S=S||2,M=typeof M>"u"?S*4:M;let x="";x+='<table style="',x+=" border-width: 0px; border-style: none;",x+=" border-collapse: collapse;",x+=" padding: 0px; margin: "+M+"px;",x+='">',x+="<tbody>";for(let v=0;v<h.getModuleCount();v+=1){x+="<tr>";for(let E=0;E<h.getModuleCount();E+=1)x+='<td style="',x+=" border-width: 0px; border-style: none;",x+=" border-collapse: collapse;",x+=" padding: 0px; margin: 0px;",x+=" width: "+S+"px;",x+=" height: "+S+"px;",x+=" background-color: ",x+=h.isDark(v,E)?"#000000":"#ffffff",x+=";",x+='"/>';x+="</tr>"}return x+="</tbody>",x+="</table>",x},h.createSvgTag=function(S,M,x,v){let E={};typeof arguments[0]=="object"&&(E=arguments[0],S=E.cellSize,M=E.margin,x=E.alt,v=E.title),S=S||2,M=typeof M>"u"?S*4:M,x=typeof x=="string"?{text:x}:x||{},x.text=x.text||null,x.id=x.text?x.id||"qrcode-description":null,v=typeof v=="string"?{text:v}:v||{},v.text=v.text||null,v.id=v.text?v.id||"qrcode-title":null;const P=h.getModuleCount()*S+M*2;let L,N,F,U,O="",k;for(k="l"+S+",0 0,"+S+" -"+S+",0 0,-"+S+"z ",O+='<svg version="1.1" xmlns="http://www.w3.org/2000/svg"',O+=E.scalable?"":' width="'+P+'px" height="'+P+'px"',O+=' viewBox="0 0 '+P+" "+P+'" ',O+=' preserveAspectRatio="xMinYMin meet"',O+=v.text||x.text?' role="img" aria-labelledby="'+C([v.id,x.id].join(" ").trim())+'"':"",O+=">",O+=v.text?'<title id="'+C(v.id)+'">'+C(v.text)+"</title>":"",O+=x.text?'<description id="'+C(x.id)+'">'+C(x.text)+"</description>":"",O+='<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>',O+='<path d="',F=0;F<h.getModuleCount();F+=1)for(U=F*S+M,L=0;L<h.getModuleCount();L+=1)h.isDark(F,L)&&(N=L*S+M,O+="M"+N+","+U+k);return O+='" stroke="transparent" fill="black"/>',O+="</svg>",O},h.createDataURL=function(S,M){S=S||2,M=typeof M>"u"?S*4:M;const x=h.getModuleCount()*S+M*2,v=M,E=x-M;return zv(x,x,function(P,L){if(v<=P&&P<E&&v<=L&&L<E){const N=Math.floor((P-v)/S),F=Math.floor((L-v)/S);return h.isDark(F,N)?0:1}else return 1})},h.createImgTag=function(S,M,x){S=S||2,M=typeof M>"u"?S*4:M;const v=h.getModuleCount()*S+M*2;let E="";return E+="<img",E+=' src="',E+=h.createDataURL(S,M),E+='"',E+=' width="',E+=v,E+='"',E+=' height="',E+=v,E+='"',x&&(E+=' alt="',E+=C(x),E+='"'),E+="/>",E};const C=function(S){let M="";for(let x=0;x<S.length;x+=1){const v=S.charAt(x);switch(v){case"<":M+="&lt;";break;case">":M+="&gt;";break;case"&":M+="&amp;";break;case'"':M+="&quot;";break;default:M+=v;break}}return M},A=function(S){S=typeof S>"u"?2:S;const x=h.getModuleCount()*1+S*2,v=S,E=x-S;let P,L,N,F,U;const O={"██":"█","█ ":"▀"," █":"▄","  ":" "},k={"██":"▀","█ ":"▀"," █":" ","  ":" "};let K="";for(P=0;P<x;P+=2){for(N=Math.floor((P-v)/1),F=Math.floor((P+1-v)/1),L=0;L<x;L+=1)U="█",v<=L&&L<E&&v<=P&&P<E&&h.isDark(N,Math.floor((L-v)/1))&&(U=" "),v<=L&&L<E&&v<=P+1&&P+1<E&&h.isDark(F,Math.floor((L-v)/1))?U+=" ":U+="█",K+=S<1&&P+1>=E?k[U]:O[U];K+=`
`}return x%2&&S>0?K.substring(0,K.length-x-1)+Array(x+1).join("▀"):K.substring(0,K.length-1)};return h.createASCII=function(S,M){if(S=S||1,S<2)return A(M);S-=1,M=typeof M>"u"?S*2:M;const x=h.getModuleCount()*S+M*2,v=M,E=x-M;let P,L,N,F;const U=Array(S+1).join("██"),O=Array(S+1).join("  ");let k="",K="";for(P=0;P<x;P+=1){for(N=Math.floor((P-v)/S),K="",L=0;L<x;L+=1)F=1,v<=L&&L<E&&v<=P&&P<E&&h.isDark(N,Math.floor((L-v)/S))&&(F=0),K+=F?U:O;for(N=0;N<S;N+=1)k+=K+`
`}return k.substring(0,k.length-1)},h.renderTo2dContext=function(S,M){M=M||2;const x=h.getModuleCount();for(let v=0;v<x;v++)for(let E=0;E<x;E++)S.fillStyle=h.isDark(v,E)?"black":"white",S.fillRect(E*M,v*M,M,M)},h};Ts.stringToBytes=function(i){const t=[];for(let e=0;e<i.length;e+=1){const n=i.charCodeAt(e);t.push(n&255)}return t};Ts.createStringToBytes=function(i,t){const e=(function(){const s=kv(i),r=function(){const c=s.read();if(c==-1)throw"eof";return c};let o=0;const a={};for(;;){const c=s.read();if(c==-1)break;const l=r(),h=r(),u=r(),f=String.fromCharCode(c<<8|l),m=h<<8|u;a[f]=m,o+=1}if(o!=t)throw o+" != "+t;return a})(),n=63;return function(s){const r=[];for(let o=0;o<s.length;o+=1){const a=s.charCodeAt(o);if(a<128)r.push(a);else{const c=e[s.charAt(o)];typeof c=="number"?(c&255)==c?r.push(c):(r.push(c>>>8),r.push(c&255)):r.push(n)}}return r}};const We={MODE_NUMBER:1,MODE_ALPHA_NUM:2,MODE_8BIT_BYTE:4,MODE_KANJI:8},Ws={L:1,M:0,Q:3,H:2},ii={PATTERN000:0,PATTERN001:1,PATTERN010:2,PATTERN011:3,PATTERN100:4,PATTERN101:5,PATTERN110:6,PATTERN111:7},si=(function(){const i=[[],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50],[6,30,54],[6,32,58],[6,34,62],[6,26,46,66],[6,26,48,70],[6,26,50,74],[6,30,54,78],[6,30,56,82],[6,30,58,86],[6,34,62,90],[6,28,50,72,94],[6,26,50,74,98],[6,30,54,78,102],[6,28,54,80,106],[6,32,58,84,110],[6,30,58,86,114],[6,34,62,90,118],[6,26,50,74,98,122],[6,30,54,78,102,126],[6,26,52,78,104,130],[6,30,56,82,108,134],[6,34,60,86,112,138],[6,30,58,86,114,142],[6,34,62,90,118,146],[6,30,54,78,102,126,150],[6,24,50,76,102,128,154],[6,28,54,80,106,132,158],[6,32,58,84,110,136,162],[6,26,54,82,110,138,166],[6,30,58,86,114,142,170]],t=1335,e=7973,n=21522,s={},r=function(o){let a=0;for(;o!=0;)a+=1,o>>>=1;return a};return s.getBCHTypeInfo=function(o){let a=o<<10;for(;r(a)-r(t)>=0;)a^=t<<r(a)-r(t);return(o<<10|a)^n},s.getBCHTypeNumber=function(o){let a=o<<12;for(;r(a)-r(e)>=0;)a^=e<<r(a)-r(e);return o<<12|a},s.getPatternPosition=function(o){return i[o-1]},s.getMaskFunction=function(o){switch(o){case ii.PATTERN000:return function(a,c){return(a+c)%2==0};case ii.PATTERN001:return function(a,c){return a%2==0};case ii.PATTERN010:return function(a,c){return c%3==0};case ii.PATTERN011:return function(a,c){return(a+c)%3==0};case ii.PATTERN100:return function(a,c){return(Math.floor(a/2)+Math.floor(c/3))%2==0};case ii.PATTERN101:return function(a,c){return a*c%2+a*c%3==0};case ii.PATTERN110:return function(a,c){return(a*c%2+a*c%3)%2==0};case ii.PATTERN111:return function(a,c){return(a*c%3+(a+c)%2)%2==0};default:throw"bad maskPattern:"+o}},s.getErrorCorrectPolynomial=function(o){let a=Qs([1],0);for(let c=0;c<o;c+=1)a=a.multiply(Qs([1,ri.gexp(c)],0));return a},s.getLengthInBits=function(o,a){if(1<=a&&a<10)switch(o){case We.MODE_NUMBER:return 10;case We.MODE_ALPHA_NUM:return 9;case We.MODE_8BIT_BYTE:return 8;case We.MODE_KANJI:return 8;default:throw"mode:"+o}else if(a<27)switch(o){case We.MODE_NUMBER:return 12;case We.MODE_ALPHA_NUM:return 11;case We.MODE_8BIT_BYTE:return 16;case We.MODE_KANJI:return 10;default:throw"mode:"+o}else if(a<41)switch(o){case We.MODE_NUMBER:return 14;case We.MODE_ALPHA_NUM:return 13;case We.MODE_8BIT_BYTE:return 16;case We.MODE_KANJI:return 12;default:throw"mode:"+o}else throw"type:"+a},s.getLostPoint=function(o){const a=o.getModuleCount();let c=0;for(let u=0;u<a;u+=1)for(let f=0;f<a;f+=1){let m=0;const g=o.isDark(u,f);for(let _=-1;_<=1;_+=1)if(!(u+_<0||a<=u+_))for(let p=-1;p<=1;p+=1)f+p<0||a<=f+p||_==0&&p==0||g==o.isDark(u+_,f+p)&&(m+=1);m>5&&(c+=3+m-5)}for(let u=0;u<a-1;u+=1)for(let f=0;f<a-1;f+=1){let m=0;o.isDark(u,f)&&(m+=1),o.isDark(u+1,f)&&(m+=1),o.isDark(u,f+1)&&(m+=1),o.isDark(u+1,f+1)&&(m+=1),(m==0||m==4)&&(c+=3)}for(let u=0;u<a;u+=1)for(let f=0;f<a-6;f+=1)o.isDark(u,f)&&!o.isDark(u,f+1)&&o.isDark(u,f+2)&&o.isDark(u,f+3)&&o.isDark(u,f+4)&&!o.isDark(u,f+5)&&o.isDark(u,f+6)&&(c+=40);for(let u=0;u<a;u+=1)for(let f=0;f<a-6;f+=1)o.isDark(f,u)&&!o.isDark(f+1,u)&&o.isDark(f+2,u)&&o.isDark(f+3,u)&&o.isDark(f+4,u)&&!o.isDark(f+5,u)&&o.isDark(f+6,u)&&(c+=40);let l=0;for(let u=0;u<a;u+=1)for(let f=0;f<a;f+=1)o.isDark(f,u)&&(l+=1);const h=Math.abs(100*l/a/a-50)/5;return c+=h*10,c},s})(),ri=(function(){const i=new Array(256),t=new Array(256);for(let n=0;n<8;n+=1)i[n]=1<<n;for(let n=8;n<256;n+=1)i[n]=i[n-4]^i[n-5]^i[n-6]^i[n-8];for(let n=0;n<255;n+=1)t[i[n]]=n;const e={};return e.glog=function(n){if(n<1)throw"glog("+n+")";return t[n]},e.gexp=function(n){for(;n<0;)n+=255;for(;n>=256;)n-=255;return i[n]},e})(),Qs=function(i,t){if(typeof i.length>"u")throw i.length+"/"+t;const e=(function(){let s=0;for(;s<i.length&&i[s]==0;)s+=1;const r=new Array(i.length-s+t);for(let o=0;o<i.length-s;o+=1)r[o]=i[o+s];return r})(),n={};return n.getAt=function(s){return e[s]},n.getLength=function(){return e.length},n.multiply=function(s){const r=new Array(n.getLength()+s.getLength()-1);for(let o=0;o<n.getLength();o+=1)for(let a=0;a<s.getLength();a+=1)r[o+a]^=ri.gexp(ri.glog(n.getAt(o))+ri.glog(s.getAt(a)));return Qs(r,0)},n.mod=function(s){if(n.getLength()-s.getLength()<0)return n;const r=ri.glog(n.getAt(0))-ri.glog(s.getAt(0)),o=new Array(n.getLength());for(let a=0;a<n.getLength();a+=1)o[a]=n.getAt(a);for(let a=0;a<s.getLength();a+=1)o[a]^=ri.gexp(ri.glog(s.getAt(a))+r);return Qs(o,0).mod(s)},n},bh=(function(){const i=[[1,26,19],[1,26,16],[1,26,13],[1,26,9],[1,44,34],[1,44,28],[1,44,22],[1,44,16],[1,70,55],[1,70,44],[2,35,17],[2,35,13],[1,100,80],[2,50,32],[2,50,24],[4,25,9],[1,134,108],[2,67,43],[2,33,15,2,34,16],[2,33,11,2,34,12],[2,86,68],[4,43,27],[4,43,19],[4,43,15],[2,98,78],[4,49,31],[2,32,14,4,33,15],[4,39,13,1,40,14],[2,121,97],[2,60,38,2,61,39],[4,40,18,2,41,19],[4,40,14,2,41,15],[2,146,116],[3,58,36,2,59,37],[4,36,16,4,37,17],[4,36,12,4,37,13],[2,86,68,2,87,69],[4,69,43,1,70,44],[6,43,19,2,44,20],[6,43,15,2,44,16],[4,101,81],[1,80,50,4,81,51],[4,50,22,4,51,23],[3,36,12,8,37,13],[2,116,92,2,117,93],[6,58,36,2,59,37],[4,46,20,6,47,21],[7,42,14,4,43,15],[4,133,107],[8,59,37,1,60,38],[8,44,20,4,45,21],[12,33,11,4,34,12],[3,145,115,1,146,116],[4,64,40,5,65,41],[11,36,16,5,37,17],[11,36,12,5,37,13],[5,109,87,1,110,88],[5,65,41,5,66,42],[5,54,24,7,55,25],[11,36,12,7,37,13],[5,122,98,1,123,99],[7,73,45,3,74,46],[15,43,19,2,44,20],[3,45,15,13,46,16],[1,135,107,5,136,108],[10,74,46,1,75,47],[1,50,22,15,51,23],[2,42,14,17,43,15],[5,150,120,1,151,121],[9,69,43,4,70,44],[17,50,22,1,51,23],[2,42,14,19,43,15],[3,141,113,4,142,114],[3,70,44,11,71,45],[17,47,21,4,48,22],[9,39,13,16,40,14],[3,135,107,5,136,108],[3,67,41,13,68,42],[15,54,24,5,55,25],[15,43,15,10,44,16],[4,144,116,4,145,117],[17,68,42],[17,50,22,6,51,23],[19,46,16,6,47,17],[2,139,111,7,140,112],[17,74,46],[7,54,24,16,55,25],[34,37,13],[4,151,121,5,152,122],[4,75,47,14,76,48],[11,54,24,14,55,25],[16,45,15,14,46,16],[6,147,117,4,148,118],[6,73,45,14,74,46],[11,54,24,16,55,25],[30,46,16,2,47,17],[8,132,106,4,133,107],[8,75,47,13,76,48],[7,54,24,22,55,25],[22,45,15,13,46,16],[10,142,114,2,143,115],[19,74,46,4,75,47],[28,50,22,6,51,23],[33,46,16,4,47,17],[8,152,122,4,153,123],[22,73,45,3,74,46],[8,53,23,26,54,24],[12,45,15,28,46,16],[3,147,117,10,148,118],[3,73,45,23,74,46],[4,54,24,31,55,25],[11,45,15,31,46,16],[7,146,116,7,147,117],[21,73,45,7,74,46],[1,53,23,37,54,24],[19,45,15,26,46,16],[5,145,115,10,146,116],[19,75,47,10,76,48],[15,54,24,25,55,25],[23,45,15,25,46,16],[13,145,115,3,146,116],[2,74,46,29,75,47],[42,54,24,1,55,25],[23,45,15,28,46,16],[17,145,115],[10,74,46,23,75,47],[10,54,24,35,55,25],[19,45,15,35,46,16],[17,145,115,1,146,116],[14,74,46,21,75,47],[29,54,24,19,55,25],[11,45,15,46,46,16],[13,145,115,6,146,116],[14,74,46,23,75,47],[44,54,24,7,55,25],[59,46,16,1,47,17],[12,151,121,7,152,122],[12,75,47,26,76,48],[39,54,24,14,55,25],[22,45,15,41,46,16],[6,151,121,14,152,122],[6,75,47,34,76,48],[46,54,24,10,55,25],[2,45,15,64,46,16],[17,152,122,4,153,123],[29,74,46,14,75,47],[49,54,24,10,55,25],[24,45,15,46,46,16],[4,152,122,18,153,123],[13,74,46,32,75,47],[48,54,24,14,55,25],[42,45,15,32,46,16],[20,147,117,4,148,118],[40,75,47,7,76,48],[43,54,24,22,55,25],[10,45,15,67,46,16],[19,148,118,6,149,119],[18,75,47,31,76,48],[34,54,24,34,55,25],[20,45,15,61,46,16]],t=function(s,r){const o={};return o.totalCount=s,o.dataCount=r,o},e={},n=function(s,r){switch(r){case Ws.L:return i[(s-1)*4+0];case Ws.M:return i[(s-1)*4+1];case Ws.Q:return i[(s-1)*4+2];case Ws.H:return i[(s-1)*4+3];default:return}};return e.getRSBlocks=function(s,r){const o=n(s,r);if(typeof o>"u")throw"bad rs block @ typeNumber:"+s+"/errorCorrectionLevel:"+r;const a=o.length/3,c=[];for(let l=0;l<a;l+=1){const h=o[l*3+0],u=o[l*3+1],f=o[l*3+2];for(let m=0;m<h;m+=1)c.push(t(u,f))}return c},e})(),Eh=function(){const i=[];let t=0;const e={};return e.getBuffer=function(){return i},e.getAt=function(n){const s=Math.floor(n/8);return(i[s]>>>7-n%8&1)==1},e.put=function(n,s){for(let r=0;r<s;r+=1)e.putBit((n>>>s-r-1&1)==1)},e.getLengthInBits=function(){return t},e.putBit=function(n){const s=Math.floor(t/8);i.length<=s&&i.push(0),n&&(i[s]|=128>>>t%8),t+=1},e},Iv=function(i){const t=We.MODE_NUMBER,e=i,n={};n.getMode=function(){return t},n.getLength=function(o){return e.length},n.write=function(o){const a=e;let c=0;for(;c+2<a.length;)o.put(s(a.substring(c,c+3)),10),c+=3;c<a.length&&(a.length-c==1?o.put(s(a.substring(c,c+1)),4):a.length-c==2&&o.put(s(a.substring(c,c+2)),7))};const s=function(o){let a=0;for(let c=0;c<o.length;c+=1)a=a*10+r(o.charAt(c));return a},r=function(o){if("0"<=o&&o<="9")return o.charCodeAt(0)-48;throw"illegal char :"+o};return n},Uv=function(i){const t=We.MODE_ALPHA_NUM,e=i,n={};n.getMode=function(){return t},n.getLength=function(r){return e.length},n.write=function(r){const o=e;let a=0;for(;a+1<o.length;)r.put(s(o.charAt(a))*45+s(o.charAt(a+1)),11),a+=2;a<o.length&&r.put(s(o.charAt(a)),6)};const s=function(r){if("0"<=r&&r<="9")return r.charCodeAt(0)-48;if("A"<=r&&r<="Z")return r.charCodeAt(0)-65+10;switch(r){case" ":return 36;case"$":return 37;case"%":return 38;case"*":return 39;case"+":return 40;case"-":return 41;case".":return 42;case"/":return 43;case":":return 44;default:throw"illegal char :"+r}};return n},Nv=function(i){const t=We.MODE_8BIT_BYTE,e=Ts.stringToBytes(i),n={};return n.getMode=function(){return t},n.getLength=function(s){return e.length},n.write=function(s){for(let r=0;r<e.length;r+=1)s.put(e[r],8)},n},Fv=function(i){const t=We.MODE_KANJI,e=Ts.stringToBytes;(function(r,o){const a=e(r);if(a.length!=2||(a[0]<<8|a[1])!=o)throw"sjis not supported."})("友",38726);const n=e(i),s={};return s.getMode=function(){return t},s.getLength=function(r){return~~(n.length/2)},s.write=function(r){const o=n;let a=0;for(;a+1<o.length;){let c=(255&o[a])<<8|255&o[a+1];if(33088<=c&&c<=40956)c-=33088;else if(57408<=c&&c<=60351)c-=49472;else throw"illegal char at "+(a+1)+"/"+c;c=(c>>>8&255)*192+(c&255),r.put(c,13),a+=2}if(a<o.length)throw"illegal char at "+(a+1)},s},zu=function(){const i=[],t={};return t.writeByte=function(e){i.push(e&255)},t.writeShort=function(e){t.writeByte(e),t.writeByte(e>>>8)},t.writeBytes=function(e,n,s){n=n||0,s=s||e.length;for(let r=0;r<s;r+=1)t.writeByte(e[r+n])},t.writeString=function(e){for(let n=0;n<e.length;n+=1)t.writeByte(e.charCodeAt(n))},t.toByteArray=function(){return i},t.toString=function(){let e="";e+="[";for(let n=0;n<i.length;n+=1)n>0&&(e+=","),e+=i[n];return e+="]",e},t},Ov=function(){let i=0,t=0,e=0,n="";const s={},r=function(a){n+=String.fromCharCode(o(a&63))},o=function(a){if(a<0)throw"n:"+a;if(a<26)return 65+a;if(a<52)return 97+(a-26);if(a<62)return 48+(a-52);if(a==62)return 43;if(a==63)return 47;throw"n:"+a};return s.writeByte=function(a){for(i=i<<8|a&255,t+=8,e+=1;t>=6;)r(i>>>t-6),t-=6},s.flush=function(){if(t>0&&(r(i<<6-t),i=0,t=0),e%3!=0){const a=3-e%3;for(let c=0;c<a;c+=1)n+="="}},s.toString=function(){return n},s},kv=function(i){const t=i;let e=0,n=0,s=0;const r={};r.read=function(){for(;s<8;){if(e>=t.length){if(s==0)return-1;throw"unexpected end of file./"+s}const c=t.charAt(e);if(e+=1,c=="=")return s=0,-1;if(c.match(/^\s$/))continue;n=n<<6|o(c.charCodeAt(0)),s+=6}const a=n>>>s-8&255;return s-=8,a};const o=function(a){if(65<=a&&a<=90)return a-65;if(97<=a&&a<=122)return a-97+26;if(48<=a&&a<=57)return a-48+52;if(a==43)return 62;if(a==47)return 63;throw"c:"+a};return r},Bv=function(i,t){const e=i,n=t,s=new Array(i*t),r={};r.setPixel=function(l,h,u){s[h*e+l]=u},r.write=function(l){l.writeString("GIF87a"),l.writeShort(e),l.writeShort(n),l.writeByte(128),l.writeByte(0),l.writeByte(0),l.writeByte(0),l.writeByte(0),l.writeByte(0),l.writeByte(255),l.writeByte(255),l.writeByte(255),l.writeString(","),l.writeShort(0),l.writeShort(0),l.writeShort(e),l.writeShort(n),l.writeByte(0);const h=2,u=a(h);l.writeByte(h);let f=0;for(;u.length-f>255;)l.writeByte(255),l.writeBytes(u,f,255),f+=255;l.writeByte(u.length-f),l.writeBytes(u,f,u.length-f),l.writeByte(0),l.writeString(";")};const o=function(l){const h=l;let u=0,f=0;const m={};return m.write=function(g,_){if(g>>>_)throw"length over";for(;u+_>=8;)h.writeByte(255&(g<<u|f)),_-=8-u,g>>>=8-u,f=0,u=0;f=g<<u|f,u=u+_},m.flush=function(){u>0&&h.writeByte(f)},m},a=function(l){const h=1<<l,u=(1<<l)+1;let f=l+1;const m=c();for(let y=0;y<h;y+=1)m.add(String.fromCharCode(y));m.add(String.fromCharCode(h)),m.add(String.fromCharCode(u));const g=zu(),_=o(g);_.write(h,f);let p=0,d=String.fromCharCode(s[p]);for(p+=1;p<s.length;){const y=String.fromCharCode(s[p]);p+=1,m.contains(d+y)?d=d+y:(_.write(m.indexOf(d),f),m.size()<4095&&(m.size()==1<<f&&(f+=1),m.add(d+y)),d=y)}return _.write(m.indexOf(d),f),_.write(u,f),_.flush(),g.toByteArray()},c=function(){const l={};let h=0;const u={};return u.add=function(f){if(u.contains(f))throw"dup key:"+f;l[f]=h,h+=1},u.size=function(){return h},u.indexOf=function(f){return l[f]},u.contains=function(f){return typeof l[f]<"u"},u};return r},zv=function(i,t,e){const n=Bv(i,t);for(let a=0;a<t;a+=1)for(let c=0;c<i;c+=1)n.setPixel(c,a,e(c,a));const s=zu();n.write(s);const r=Ov(),o=s.toByteArray();for(let a=0;a<o.length;a+=1)r.writeByte(o[a]);return r.flush(),"data:image/gif;base64,"+r};Ts.stringToBytes;const Br=i=>document.getElementById(i);function Rc(){return new Promise(i=>{const t=3+Math.floor(Math.random()*7),e=3+Math.floor(Math.random()*7),n=t*e,s=new Set([n]);for(;s.size<4;)s.add(n+(Math.floor(Math.random()*9)-4)*(Math.random()<.5?1:t));const r=Br("parent-gate");Br("gate-question").textContent=`What is ${t} × ${e}?`;const o=Br("gate-answers");o.innerHTML="";const a=c=>{r.classList.add("hidden"),i(c)};for(const c of[...s].sort(()=>Math.random()-.5)){const l=document.createElement("button");l.className="btn",l.textContent=String(c),l.addEventListener("click",()=>a(c===n)),o.appendChild(l)}Br("gate-cancel").onclick=()=>a(!1),r.classList.remove("hidden")})}const vn=i=>document.getElementById(i);function Gv(i){const t=vn("builder-canvas"),e=t.getContext("2d");let n="m",s="f",r=[],o=!1,a=null;const c=[50,t.height/2],l=p=>{const d=t.getBoundingClientRect();return[(p.clientX-d.left)/d.width*t.width,(p.clientY-d.top)/d.height*t.height]};function h(){e.fillStyle=s==="m"?"#5fa83a":"#86c06c",e.fillRect(0,0,t.width,t.height),e.fillStyle="rgba(0,0,0,0.06)";for(let p=0;p<160;p++)e.fillRect(p*97%t.width,p*53%t.height,4,4);if(r.length>1){e.lineCap="round",e.lineJoin="round",e.strokeStyle=s==="m"?"#5a3b22":"#8a5a33",e.lineWidth=22,e.beginPath(),r.forEach(([y,b],w)=>w?e.lineTo(y,b):e.moveTo(y,b)),e.stroke(),e.strokeStyle="rgba(255,255,255,0.7)",e.lineWidth=2,e.setLineDash([10,10]),e.stroke(),e.setLineDash([]);const[p,d]=r[r.length-1];e.font="28px system-ui, sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText("🏁",p,d-18)}e.fillStyle="#22c55e",e.strokeStyle="#fff",e.lineWidth=4,e.beginPath(),e.arc(c[0],c[1],14,0,Math.PI*2),e.fill(),e.stroke(),r.length<2&&(e.fillStyle="rgba(15,23,42,0.6)",e.font="800 22px system-ui, sans-serif",e.textAlign="center",e.fillText("👆 Draw your track from the green dot",t.width/2,40))}function u(){a=r.length>1?Wx(r,n,s):null,vn("btn-builder-ride").toggleAttribute("disabled",!a),vn("btn-builder-share").toggleAttribute("disabled",!a),vn("builder-qr").classList.add("hidden")}t.addEventListener("pointerdown",p=>{t.setPointerCapture(p.pointerId),o=!0,r=[c,l(p)],h()}),t.addEventListener("pointermove",p=>{if(!o)return;const d=l(p),y=r[r.length-1];Math.hypot(d[0]-y[0],d[1]-y[1])>4&&r.push(d),h()});const f=()=>{o&&(o=!1,u())};t.addEventListener("pointerup",f),t.addEventListener("pointercancel",f);const m=()=>{document.querySelectorAll("[data-style]").forEach(p=>p.classList.toggle("on",p.dataset.style===n)),document.querySelectorAll("[data-theme]").forEach(p=>p.classList.toggle("on",p.dataset.theme===s))};document.querySelectorAll("[data-style]").forEach(p=>p.addEventListener("click",()=>{n=p.dataset.style,m(),u()})),document.querySelectorAll("[data-theme]").forEach(p=>p.addEventListener("click",()=>{s=p.dataset.theme,m(),h(),u()}));const g=p=>(i.data.tracks.some(d=>d.code===p)||(i.data.tracks.unshift({code:p,name:`My track ${i.data.tracks.length+1}`}),i.data.tracks=i.data.tracks.slice(0,12),i.save()),i.data.tracks.find(d=>d.code===p));vn("btn-builder-clear").addEventListener("click",()=>{r=[],u(),h()}),vn("btn-builder-ride").addEventListener("click",()=>{if(!a)return;const p=g(a);i.ride(a,p.name)}),vn("btn-builder-share").addEventListener("click",()=>{a&&(g(a),Th(vn("qr-canvas"),io+a),vn("builder-qr").classList.remove("hidden"),_())}),vn("btn-qr-save").addEventListener("click",async()=>{if(!a||!await Rc())return;const p=document.createElement("canvas");p.width=600,p.height=720;const d=p.getContext("2d");d.fillStyle="#fff7ed",d.fillRect(0,0,600,720),d.fillStyle="#f97316",d.font="900 44px system-ui, sans-serif",d.textAlign="center",d.fillText("Ride my track! 🚲",300,70);const y=document.createElement("canvas");y.width=y.height=480,Th(y,io+a),d.drawImage(y,60,110),d.fillStyle="#475569",d.font="700 22px system-ui, sans-serif",d.fillText("Scan with your phone camera to open it in Cycle Champs",300,640),Nu(p,"my-track-qr.png","Ride my Cycle Champs track!")});function _(){const p=vn("my-tracks");p.innerHTML=i.data.tracks.length?"":'<span class="sub small">Tracks you draw or get from friends show up here.</span>';for(const d of i.data.tracks){const y=document.createElement("button");y.className="btn small-btn",y.textContent=`${d.code[0]==="m"?"🌧️":"🌲"} ${d.name}${d.best?` · ${d.best.toFixed(1)}s`:""}`,y.addEventListener("click",()=>i.ride(d.code,d.name)),p.appendChild(y)}}return{show(){m(),h(),u(),_()}}}function Th(i,t){const e=Ts(0,"M");e.addData(t),e.make();const n=e.getModuleCount(),s=(c,l)=>e.isDark(c,l),r=i.getContext("2d"),o=3,a=i.width/(n+o*2);r.fillStyle="#fff",r.fillRect(0,0,i.width,i.height),r.fillStyle="#0f172a";for(let c=0;c<n;c++)for(let l=0;l<n;l++)s(c,l)&&r.fillRect((l+o)*a,(c+o)*a,Math.ceil(a),Math.ceil(a))}var Ah;(function(i){i[i.Flush=0]="Flush",i[i.Add=1]="Add"})(Ah||(Ah={}));const Hv=Di("TextToSpeech",{web:()=>er(()=>import("./web-ClSZmFbX.js"),[],import.meta.url).then(i=>new i.TextToSpeechWeb)}),Vv={lightAhead:{en:"Traffic light ahead. Get ready to stop.",hi:"आगे ट्रैफिक लाइट है, रुकने के लिए तैयार रहो।",es:"Semáforo adelante, prepárate para parar."},redLight:{en:"Red light! Always stop at the line.",hi:"लाल बत्ती! हमेशा लाइन पर रुको।",es:"¡Luz roja! Siempre detente en la línea."},greatStop:{en:"Great stop!",hi:"बहुत बढ़िया, सही रुके!",es:"¡Muy bien, buena parada!"},zebra:{en:"Stop for people crossing.",hi:"रुको, लोग सड़क पार कर रहे हैं।",es:"Para, hay gente cruzando."},keepLeft:{en:"Keep left!",hi:"बाईं ओर चलो!",es:"¡Mantente a la izquierda!"},keepRight:{en:"Keep right!",hi:"दाईं ओर चलो!",es:"¡Mantente a la derecha!"},splash:{en:"Splash!",hi:"छपाक!",es:"¡Chapuzón!"},newBest:{en:"New best lap!",hi:"नया बेस्ट लैप!",es:"¡Nueva mejor vuelta!"},finish:{en:"You finished! Well done!",hi:"शाबाश! तुमने पूरा कर लिया!",es:"¡Terminaste! ¡Bien hecho!"},crash:{en:"Oops! Try again.",hi:"अरे! फिर से कोशिश करो।",es:"¡Uy! Inténtalo otra vez."},mud:{en:"Slippery mud! Go gently.",hi:"फिसलन वाली कीचड़! धीरे चलो।",es:"¡Barro resbaloso! Ve despacio."},trick:{en:"Awesome trick!",hi:"क्या शानदार ट्रिक!",es:"¡Qué truco tan genial!"},flip:{en:"Wow, a flip!",hi:"वाह, फ्लिप!",es:"¡Guau, una voltereta!"},sticker:{en:"You found a sticker!",hi:"तुम्हें एक स्टिकर मिला!",es:"¡Encontraste una calcomanía!"},pump:{en:"Pump on the downhill!",hi:"ढलान पर पंप करो!",es:"¡Bombea en la bajada!"},go:{en:"Ready, steady, go!",hi:"तैयार, चलो!",es:"¡Listos, ya!"}},Wv={en:"en-IN",hi:"hi-IN",es:"es-US"};let Xs="off",Gu="en-IN",ea=0,Rh=null;function Cc(i,t){Xs=i,Gu=t==="left"?"en-IN":"en-US"}function Pc(i){if(Xs==="off")return;const t=performance.now();if(i===Rh&&t-ea<4e3||t-ea<1200)return;ea=t,Rh=i;const e=Vv[i][Xs],n=Xs==="en"?Gu:Wv[Xs];if(Ci.isNativePlatform())Hv.speak({text:e,lang:n,rate:1,pitch:1.1,volume:1}).catch(()=>{});else if("speechSynthesis"in window){const s=new SpeechSynthesisUtterance(e);s.lang=n,s.pitch=1.1,speechSynthesis.cancel(),speechSynthesis.speak(s)}}const vt=i=>document.getElementById(i),tr=vt("game3d"),fo=new yx(vt("controls")),ht=Nx();Uh(ht.muted);Cc(ht.voice,ht.side);const en=[{id:"city",mode:"city",name:"City Ride",emoji:"🏙️",blurb:"Real city streets: traffic lights, zebra crossings and cars."},{id:"mountain",mode:"mountain",name:"Mountain Trail",emoji:"⛰️",blurb:"Forest trail with rock gardens, logs and big jumps."},{id:"mud",mode:"mud",name:"Monsoon Mud",emoji:"🌧️",blurb:"Slippery mud, splashy puddles and a river bridge in the rain!"},{id:"skatepark",mode:"skatepark",name:"Skatepark",emoji:"🛹",blurb:"Drop in, fly off the ramps, flip and pull tricks!"},{id:"pump",mode:"pump",name:"Pump Track",emoji:"〰️",blurb:"No pedalling! PUMP on the downhills to fly round the loop."}],Xv={home:"home",festivals:"festivals",garage:"garage",album:"album",licence:"licence",builder:"builder",family:"family",familyTurn:"family-turn",podium:"podium",paused:"pause",results:"results"};let ui="home",Oe=null,po=en[0],Ri=null,jr=null,Ys=null,so=null,Ch=performance.now();const $v=matchMedia("(pointer: coarse)").matches||"ontouchstart"in window,Ms=()=>({bike:ht.bike,helmet:ht.helmet}),nn=()=>Fx(ht);function oe(i){ui=i;for(const[e,n]of Object.entries(Xv))vt(n).classList.toggle("hidden",e!==i);const t=i==="play"||i==="paused"||i==="results"||i==="replay";!t&&i!=="familyTurn"&&(Oe=null),vt("hud").classList.toggle("hidden",!t||i==="replay"),vt("controls").classList.toggle("hidden",i!=="play"||!$v),vt("replay-bar").classList.toggle("hidden",i!=="replay"),i!=="play"&&vt("btn-replay").classList.add("hidden"),tr.classList.toggle("hidden",!Oe),document.body.classList.toggle("playing",i==="play"||i==="replay"),i==="home"&&Xu(),i==="festivals"&&Yv(),i==="garage"&&ys(),i==="album"&&Jv(),i==="licence"&&Qv(),i==="builder"&&lM.show(),i==="family"&&Ku(),fo.reset()}function Hu(){const i=window.innerWidth,t=window.innerHeight;Ri==null||Ri.setSize(i,t,!1),jr==null||jr.resize(i,t),Ys==null||Ys.resize(i,t)}function Vu(i){return[0,1,2].map(t=>`<span class="${t<i?"star-on":"star-off"}">★</span>`).join("")}function Ph(i,t=!1){const e=document.createElement("button");e.className=`rcard ${i.mode}${t?" big":""}${i.festival?" festival":""}`,e.dataset.ride=i.id;const n=qu(i);return n&&e.style.setProperty("--art",`url("${n}")`),e.innerHTML=`<span class="badge">${i.emoji}</span><span class="title">${i.name}</span><span class="stars">${Vu(ht.stars[i.id]??0)}</span><span class="go">${t?"▶":"›"}</span>`,e.addEventListener("click",()=>qn(i)),e}function Wu(i){const t=Au(i);return{id:`fest-${i}`,mode:t.ride,name:t.name,emoji:t.emoji,blurb:t.blurb,festival:i}}function qv(){const i=xx().map(Wu);return i.length?i.slice(0,2):[en[2],en[3]]}function Xu(){const i=qv(),t=vt("featured");t.innerHTML="";for(const s of i)t.appendChild(Ph(s,!0));const e=vx();vt("festival-next").textContent=i.some(s=>s.festival)?"":`🎉 Next festival ride: ${e.info.emoji} ${e.info.name} in ${e.days} day${e.days===1?"":"s"}`;const n=vt("level-cards");n.innerHTML="";for(const s of en)n.appendChild(Ph(s));vt("btn-album").textContent=`📒 ${ht.stickers.length}/${no.length}`,vt("btn-licence").textContent=ht.licence?"🪪 My licence":"🪪 Licence",vt("btn-mute").textContent=ht.muted?"🔇 Off":"🔊 Sound",Kv([...i,...en])}function Yv(){const i=vt("festival-list");i.innerHTML="";for(const t of vs){const e=Mx(t.id),n=document.createElement("button");n.className=`fest-item${e===0?" on":""}`,n.innerHTML=`<span class="big">${t.emoji}</span><span><b>${t.name}</b><small>${e===0?"On now! Tap to ride 🎉":`Opens in ${e} day${e===1?"":"s"}`} · ${t.blurb}</small></span>`,e===0&&n.addEventListener("click",()=>qn(Wu(t.id))),i.appendChild(n)}}const jv="v1",$u=i=>`cycle-champs:thumb:${jv}:${i.id}${i.mode==="city"?`:${ht.side}`:""}`;function qu(i){try{return localStorage.getItem($u(i))}catch{return null}}let Yu=[],tc=!1;function Kv(i){Yu=i.filter((t,e)=>!qu(t)&&i.findIndex(n=>n.id===t.id)===e),tc||setTimeout(ju,150)}function ju(){const i=Yu.shift();if(!i||ui!=="home"){tc=!1;return}tc=!0;try{const t=Zv(i);try{localStorage.setItem($u(i),t)}catch{}document.querySelectorAll(`[data-ride="${i.id}"]`).forEach(e=>e.style.setProperty("--art",`url("${t}")`))}catch{}setTimeout(ju,60)}function Zv(i){const t=Zu(),e=512,n=288;t.setSize(e,n,!1);const s=Ju(i);s.view.resize(e,n);const r={up:!0,down:!1,left:!1,right:!1};if(s.city)for(let a=0;a<130;a++)s.update(1/30,r);else if(s.trail){const a=s.trail,c=a.layout,l=i.mode==="mountain"?205:i.mode==="mud"?i.festival?c.puddles[0].s-12:c.bridge[0]-10:0;l&&(a.rider.s=l,a.rider.v=9,a.rider.y=pe(c,l,0));const h=i.mode==="mountain"||i.mode==="skatepark";for(let u=0;u<900&&(s.update(1/30,r),!(h&&a.time>(i.mode==="skatepark"?2:.5)&&!a.rider.grounded&&a.rider.airTime>.25||!h&&a.time>(i.mode==="pump"?6:i.mode==="mud"?1.6:3)));u++);}for(let a=0;a<24;a++)s.render(1/10);const o=tr.toDataURL("image/jpeg",.8);return t.setSize(window.innerWidth,window.innerHeight,!1),s.view.resize(window.innerWidth,window.innerHeight),o}function na(i,t,e,n){const s=Iu(ht);i.innerHTML="";for(const r of t){const o=document.createElement("button"),a=s<r.stars;o.className=`part${r.id===e?" on":""}${a?" locked":""}`,o.innerHTML=`<b>${r.emoji} ${r.name}</b><span>${a?`🔒 ${r.stars}★ to unlock`:r.good}</span>`,o.addEventListener("click",()=>{a||(n(r.id),nn(),ys())}),i.appendChild(o)}}function ys(){const i=Iu(ht);vt("garage-stars").textContent=`You have ${i} ★. Earn stars to unlock colours, parts and pets!`;const t=(r,o,a)=>{r.innerHTML="";for(const{color:c,stars:l}of o){const h=document.createElement("button"),u=i<l;h.className=`swatch${ht[a]===c?" on":""}${u?" locked":""}`,h.style.background=c,h.title=u?`Unlock with ${l} stars`:"",h.textContent=u?`${l}★`:"",h.addEventListener("click",()=>{u||(ht[a]=c,nn(),ys())}),r.appendChild(h)}},e=[...Lu];ht.photoColor&&e.unshift({color:ht.photoColor,stars:0}),t(vt("bike-colors"),e,"bike"),ht.photoColor&&(vt("bike-colors").firstElementChild.textContent="📸"),t(vt("helmet-colors"),Du,"helmet"),na(vt("tyre-parts"),xf,ht.tyre,r=>ht.tyre=r),na(vt("frame-parts"),vf,ht.frame,r=>ht.frame=r),na(vt("pet-parts"),Oh,ht.pet,r=>ht.pet=r);const n=[["off","🔇 Off"],["en","English"],["hi","हिंदी"],["es","Español"]],s=vt("voice-langs");s.innerHTML="";for(const[r,o]of n){const a=document.createElement("button");a.className=`btn side${ht.voice===r?" on":""}`,a.textContent=o,a.addEventListener("click",()=>{ht.voice=r,Cc(r,ht.side),nn(),ys(),Pc("go")}),s.appendChild(a)}vt("side-left").classList.toggle("on",ht.side==="left"),vt("side-right").classList.toggle("on",ht.side==="right"),so??(so=new Fu(vt("garage-preview"),Ms())),so.show(Ms())}function Jv(){vt("album-count").textContent=`You found ${ht.stickers.length} of ${no.length} stickers. They're hidden in every ride: look off the main line and up in the air!`;const i=vt("album-grid");i.innerHTML="";for(const t of no){const e=ht.stickers.includes(t.id),n=en.find(r=>r.id===t.ride),s=document.createElement("div");s.className=`sticker${e?"":" missing"}`,s.innerHTML=`<span class="big">${t.emoji}</span><span>${e?t.name:"?"}</span><span class="small">${e?"":`Hidden in ${n.emoji} ${n.name}`}</span>`,i.appendChild(s)}}function Qv(){vt("kid-name").value=ht.kidName,so??(so=new Fu(vt("garage-preview"),Ms())),so.show(Ms()),Ru(vt("licence-card"),ht,vt("garage-preview")),vt("licence-steps").innerHTML=Sx.map(i=>`<li>${ht.licence?"✅":"⬜"} ${i}</li>`).join(""),vt("btn-licence-share").classList.toggle("hidden",!ht.licence)}function tM(i){if(ht.licence||i.violations||i.crashes)return!1;const t=new Date;return ht.licence={date:t.toLocaleDateString(void 0,{day:"numeric",month:"short",year:"numeric"}),side:ht.side,number:`PP-${String(Math.floor(1e5+Math.random()*9e5))}`},nn(),!0}const Lh=["#f97316","#a855f7","#14b8a6","#ec4899"];let Ke=null,ec=en[1];function Ku(){const i=vt("family-rides");i.innerHTML="";for(const e of en.filter(n=>n.mode!=="city")){const n=document.createElement("button");n.className=`btn side${ec.id===e.id?" on":""}`,n.textContent=`${e.emoji} ${e.name}`,n.addEventListener("click",()=>{ec=e,Ku()}),i.appendChild(n)}const t=vt("family-names");if(!t.childElementCount)for(let e=0;e<4;e++){const n=document.createElement("input");n.maxLength=12,n.placeholder=`Rider ${e+1}${e<2?"":" (optional)"}`,n.value=ht.family[e]??(e===0?ht.kidName:""),t.appendChild(n)}}function Lc(){const i=Ke,t=i.players[i.turn];vt("turn-title").textContent=`${t}'s turn! 🚲`,vt("turn-sub").textContent=i.turn===0?`Pass the phone to ${t}.`:`Pass the phone to ${t}. Race the ghost${i.turn>1?"s":""} of ${i.runs.map(e=>e.name).join(" and ")}!`,oe("familyTurn")}function eM(i,t){const e=Ke;if(e.runs.push({name:e.players[e.turn],time:i.time,score:i.score,crashes:i.crashes,samples:t.runSamples}),e.turn++,e.turn<e.players.length)return Lc();const n=e.spec.mode==="skatepark",s=["🥇","🥈","🥉","🏅"];vt("podium-list").innerHTML=[...e.runs].sort((r,o)=>n?o.score-r.score:r.time-o.time).map((r,o)=>`<li>${s[o]} ${r.name}: ${n?`⭐ ${r.score}`:`⏱ ${r.time.toFixed(1)}s`}${r.crashes?` (💥${r.crashes})`:""}</li>`).join(""),oe("podium")}function Zu(){return Ri||(Ri=ax(tr),Ri.setSize(window.innerWidth,window.innerHeight,!1)),Ri}function Ju(i){let t;const e=Zu(),n=window.innerWidth,s=window.innerHeight,r=Mf(ht.tyre,ht.frame,ht.pet),o={pet:ht.pet,festival:i.festival??null};if(vt("hud-level").textContent=`${i.emoji} ${i.name}`,i.mode==="city"){const a=new Of(ht.side,r,ht.stickers),c=jr??(jr=new _x(e));c.resize(n,s),c.build(a,Ms(),o),t={spec:i,view:c,ride:a,city:a,update:(l,h)=>a.update(l,h),render:l=>c.render(a,l)},a.hint=i.festival==="diwali"?"Happy Diwali! Ride safely through the lights. 🪔":i.festival==="christmas"?"Merry Christmas! Ride to the giant tree. 🎄":ht.side==="left"?"▲ pedal, ▼ brake, ◀ ▶ steer. Keep LEFT like on Indian roads!":"▲ pedal, ▼ brake, ◀ ▶ steer. Keep RIGHT like on US roads!",a.hintT=4}else{const a=ht.stickers,c=i.mode==="skatepark"?new zs(Vx(),Qa,r,a):i.mode==="pump"?new zs(Dx(),Ja,r,a):i.mode==="mud"?new zs(Px(),Yr,r,a):i.mode==="custom"?new zs(qx(i.code),Yr,r,a):new zs(Cu(),Yr,r,a);i.festival==="holi"&&(c.splashText="Colour splash! +25 🎨"),Ke&&(c.runGhosts=Ke.runs.map((f,m)=>({name:f.name,color:Lh[m%Lh.length],samples:f.samples})));const l=Ys??(Ys=new Av(e));l.resize(n,s),l.build(c,Ms(),o);const h={spec:i,view:l,ride:c,trail:c,update:(f,m)=>c.update(f,m),render:f=>l.render(c,f)};if(t=h,i.mode==="pump"&&!Ke){const f=ht.ghosts[i.id];f&&(c.bestLap=f),h.update=(m,g)=>{c.update(m,g),c.newBest&&c.bestLap&&(c.newBest=!1,ht.ghosts[i.id]=c.bestLap,nn())}}i.mode==="pump"&&(h.hud=()=>{const f=c.bestLap?` · Best ${c.bestLap.time.toFixed(1)}s`:"";return`Lap ${c.lap}/${c.laps} · ${c.lapTime.toFixed(1)}s${f}`});const u={skatepark:"Drop in with ▲! In the air: tap TRICK, or hold ▼ / ▲ to flip.",pump:"No pedalling! Hold PUMP going downhill, let go going uphill.",mountain:i.festival==="halloween"?"Spooky! Follow the glowing pumpkins. 🎃":"▲ pedal, ◀ ▶ steer. In the air, tap ▲ or ▼ to tilt and land on both wheels!",mud:i.festival==="holi"?"Happy Holi! Splash through the colour puddles! 🎨":"It rained! Mud is slippery, so steer gently. Splash through the puddles!",custom:"Your own track! ▲ pedal, ◀ ▶ steer."};c.hint=Ke?`${Ke.players[Ke.turn]}'s turn: beat the ghosts!`:u[i.mode],c.hintT=4.5}return t}function qn(i){Nh(),po=i,Oe=Ju(i);const t=vt("btn-action");t.classList.toggle("hidden",i.mode!=="skatepark"&&i.mode!=="pump"),t.textContent=i.mode==="pump"?"PUMP":"TRICK",oe("play"),Pc("go")}function Qu(i){const t=Math.floor(i/60),e=(i%60).toFixed(1).padStart(4,"0");return t?`${t}:${e}`:`${e}s`}function nM(i){const t=vt("hud-hint");t.classList.toggle("hidden",!i),i&&t.textContent!==i&&(t.textContent=i)}function iM(i){var r;const t=i.ride;vt("hud-time").textContent=`⏱ ${Qu(t.time)}`,vt("hud-coins").textContent=`🪙 ${t.coinCount}/${t.totalCoins}`;const e=t.violations+t.crashes,n={city:e?`⚠️ ${e} oops`:"🚦 Safe",skatepark:`⭐ ${t.score}`,pump:((r=i.hud)==null?void 0:r.call(i))??"",mountain:t.crashes?`💥 ${t.crashes}`:"🌲 Clean ride",mud:t.crashes?`💥 ${t.crashes}`:`⭐ ${t.score}`,custom:t.crashes?`💥 ${t.crashes}`:"✏️ My track"};vt("hud-extra").textContent=n[i.spec.mode],nM(t.hint);const s=vt("hud-toast");s.classList.toggle("hidden",!t.message),t.message&&(s.textContent=t.message,s.style.color=t.messageColor)}let nc=0;function sM(i){const t=bc(i),e=vt("sticker-pop");e.innerHTML=`<div class="big">${t.emoji}</div>New sticker!<br>${t.name}`,e.classList.remove("hidden"),nc=2.4}function rM(i,t){if(t.stars===3)return"Perfect ride! 🎉";switch(i.mode){case"city":return t.violations||t.crashes?"Stop at red lights, wait for people crossing and stay on your side for all stars.":"Grab every coin for the last star!";case"mountain":case"custom":return t.coins<t.totalCoins?"Some coins are up in the air: hit the jumps fast!":"Ride without crashing for 3 stars.";case"mud":return t.coins<t.totalCoins?"Steer gently through the mud and splash through every puddle to grab all the coins!":"Ride without crashing for 3 stars.";case"skatepark":return`Score ${Qa.scoreTargets[0]} for 2★ and ${Qa.scoreTargets[1]} for 3★. Flips are worth the most!`;case"pump":return`Finish under ${Ja.timeTargets[0]}s for 2★ and ${Ja.timeTargets[1]}s for 3★. Pump only on the downhills!`}}function oM(i){const t=i.ride.result,e=i.spec;if(Ke&&i.trail)return eM(t,i.trail);if(e.mode==="custom"){const o=ht.tracks.find(a=>a.code===e.code);o&&(!o.best||t.time<o.best)&&(o.best=t.time)}else ht.stars[e.id]=Math.max(ht.stars[e.id]??0,t.stars),e.mode==="pump"?ht.best[e.id]=Math.min(ht.best[e.id]??1/0,t.time):ht.best[e.id]=Math.max(ht.best[e.id]??0,t.score);nn(),vt("res-title").textContent=["","Finished!","Great ride!","Awesome!"][t.stars],vt("res-stars").innerHTML=Vu(t.stars);const n=[`⏱ Time: ${Qu(t.time)}`,`🪙 Coins: ${t.coins} / ${t.totalCoins}`];e.mode==="skatepark"&&n.push(`⭐ Score: ${t.score}`),e.mode==="city"&&n.push(t.violations?`🚦 Road safety mistakes: ${t.violations}`:"🚦 Safe rider: no mistakes!"),n.push(`💥 Crashes: ${t.crashes}`),vt("res-stats").innerHTML=n.map(o=>`<li>${o}</li>`).join(""),vt("res-tip").textContent=rM(e,t);const s=vt("res-extra");if(s.innerHTML="",i.city&&tM(i.city)){const o=document.createElement("button");o.className="btn primary",o.textContent="🪪 You earned your Junior Cycling Licence!",o.addEventListener("click",()=>oe("licence")),s.appendChild(o)}const r=en.findIndex(o=>o.id===e.id);vt("btn-next").textContent=r>=0&&r<en.length-1?"Next ▶":"Menu ⌂",oe("results")}let Dc=null,ia=0,is=0,Pn=null,js=null;function aM(){if(!Dc||!(Oe!=null&&Oe.trail))return;oe("replay"),is=0,js=null,vt("btn-replay-save").classList.add("hidden");const i="captureStream"in tr?tr.captureStream(30):null,t=["video/mp4","video/webm;codecs=vp9","video/webm"].find(e=>typeof MediaRecorder<"u"&&MediaRecorder.isTypeSupported(e));if(i&&t){const e=[];Pn=new MediaRecorder(i,{mimeType:t}),Pn.ondataavailable=n=>{n.data.size&&e.push(n.data)},Pn.onstop=()=>{js=new Blob(e,{type:t}),vt("btn-replay-save").classList.remove("hidden")},Pn.start()}}function cM(i){const t=Dc,e=t[0].t,n=t[t.length-1].t-e;is=Math.min(n,is+i*.35);const s=e+is,r=t.find(o=>o.t>=s)??t[t.length-1];Ys.renderReplay(Oe.trail,r,.9+is*.9),is>=n&&Pn&&Pn.state==="recording"&&Pn.stop()}function tf(i){var e;const t=Math.min(.03333333333333333,(i-Ch)/1e3);if(Ch=i,Oe&&ui==="replay")cM(t);else if(Oe){const n=Oe,s=n.ride,r=ui==="play";if(r){n.update(t,fo.poll());for(const o of s.sounds)Fh(o);s.sounds.length=0;for(const o of s.voice)Pc(o);s.voice.length=0;for(const o of s.stickerFinds)ht.stickers.includes(o)||ht.stickers.push(o),nn(),sM(o);s.stickerFinds.length=0,(e=n.trail)!=null&&e.replayReady&&(Dc=n.trail.replayReady,n.trail.replayReady=null,ia=4,vt("btn-replay").classList.remove("hidden")),ia>0&&(ia-=t)<=0&&vt("btn-replay").classList.add("hidden"),nc>0&&(nc-=t)<=0&&vt("sticker-pop").classList.add("hidden"),s.finished&&s.finishedFor>1.5&&s.result&&oM(n)}Oe==null||Oe.render(r?t:0),Oe&&iM(Oe)}requestAnimationFrame(tf)}function sa(i){const t=i.startsWith(io)?i.slice(io.length).replace(/\/$/,""):i;if(!Xx(t))return;let e=ht.tracks.find(n=>n.code===t);e||(e={code:t,name:`Friend's track ${ht.tracks.length+1}`},ht.tracks.unshift(e),nn()),qn({id:`track-${t}`,mode:"custom",name:e.name,emoji:"✏️",code:t})}const lM=Gv({data:ht,save:nn,ride:(i,t)=>qn({id:`track-${i}`,mode:"custom",name:t,emoji:"✏️",code:i})});fo.onBell=()=>{Nh(),ui==="play"&&Oe?Oe.ride.ringBell():Fh("bell")};fo.onPause=()=>{ui==="play"?oe("paused"):ui==="paused"&&oe("play")};const Jt=(i,t)=>vt(i).addEventListener("click",t);Jt("btn-garage",()=>oe("garage"));Jt("btn-view-all",()=>oe("festivals"));Jt("btn-festivals-back",()=>oe("home"));Jt("btn-garage-back",()=>oe("home"));Jt("btn-album",()=>oe("album"));Jt("btn-album-back",()=>oe("home"));Jt("btn-licence",()=>oe("licence"));Jt("btn-licence-back",()=>oe("home"));Jt("btn-licence-ride",()=>qn(en[0]));Jt("btn-licence-share",async()=>{await Rc()&&await Nu(vt("licence-card"),"junior-cycling-licence.png","My Junior Cycling Licence")});vt("kid-name").addEventListener("input",i=>{ht.kidName=i.target.value.trim(),nn(),Ru(vt("licence-card"),ht,vt("garage-preview"))});Jt("btn-builder",()=>oe("builder"));Jt("btn-builder-back",()=>oe("home"));Jt("btn-family",()=>oe("family"));Jt("btn-family-back",()=>oe("home"));Jt("btn-family-start",()=>{const i=[...vt("family-names").querySelectorAll("input")].map(t=>t.value.trim()).filter(Boolean);if(i.length<2){alert("Add at least 2 riders!");return}ht.family=i,nn(),Ke={spec:ec,players:i,turn:0,runs:[]},Lc()});Jt("btn-turn-go",()=>qn(Ke.spec));Jt("btn-podium-again",()=>{Ke={...Ke,turn:0,runs:[]},Lc()});Jt("btn-podium-home",()=>{Ke=null,oe("home")});Jt("btn-replay",()=>aM());Jt("btn-replay-close",()=>{Pn&&Pn.state==="recording"&&Pn.stop(),oe("play")});Jt("btn-replay-save",async()=>{js&&await Rc()&&Uu(js,`cycle-champs-replay.${js.type.includes("mp4")?"mp4":"webm"}`,"My Cycle Champs trick!").catch(()=>{})});Jt("btn-photo",()=>vt("photo-input").click());vt("photo-input").addEventListener("change",async i=>{var n;const t=i.target,e=(n=t.files)==null?void 0:n[0];if(t.value="",!!e)try{const s=await Lx(e);ht.photoColor=s,ht.bike=s,nn(),ys()}catch{alert("Hmm, couldn't spot a colour. Try a photo where the bike fills more of the picture!")}});for(const i of["left","right"])Jt(`side-${i}`,()=>{ht.side=i,Cc(ht.voice,i),nn(),ys()});Jt("btn-mute",()=>{ht.muted=!ht.muted,Uh(ht.muted),nn(),Xu()});Jt("btn-pause",()=>oe("paused"));Jt("btn-resume",()=>oe("play"));Jt("btn-restart",()=>qn(po));Jt("btn-home",()=>{Ke=null,oe("home")});Jt("btn-retry",()=>qn(po));Jt("btn-res-home",()=>oe("home"));Jt("btn-next",()=>{const i=en.findIndex(t=>t.id===po.id);i>=0&&i<en.length-1?qn(en[i+1]):oe("home")});document.addEventListener("visibilitychange",()=>{document.hidden&&ui==="play"&&oe("paused")});window.addEventListener("resize",Hu);Hu();oe("home");requestAnimationFrame(tf);vt("app-version").textContent=Lv;Dv();if(Ci.isNativePlatform())ra.addListener("appUrlOpen",({url:i})=>sa(i)),ra.getLaunchUrl().then(i=>{i!=null&&i.url&&sa(i.url)});else{const i=new URLSearchParams(location.search).get("track");i&&sa(i)}export{yh as A,hh as E,Dh as W,gf as b};
